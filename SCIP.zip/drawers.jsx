/* SCIP — Drawers (Lineage + Workflow) and Quickball */
/* eslint-disable react/prop-types */

// ---------- LINEAGE DRAWER (provenance chain) ----------
function LineageDrawer({ open, lineageKey, title, onClose }) {
  useEffect(() => {
    if (!open) return;
    function onKey(e) { if (e.key === "Escape") onClose(); }
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  const lineage = window.SCIP.LINEAGE[lineageKey] || window.SCIP.LINEAGE.OD_TODAY;

  return (
    <React.Fragment>
      <div className="scrim" onClick={onClose} aria-hidden="true" />
      <aside className="drawer" role="dialog" aria-modal="true" aria-label="Lineage drawer">
        <div className="drawer-head">
          <div>
            <span className="eyebrow">Evidence on request</span>
            <h2 className="display h2 title">{title || "Evidence"}</h2>
            <p className="sub">Source file, sheet, range, validation, confidence and reporting basis. Shown only after explicit ask.</p>
          </div>
          <button className="drawer-close" onClick={onClose} aria-label="Close drawer"><IconClose /></button>
        </div>
        <div className="drawer-body">
          <div className="provenance solid">
            <div className="provenance-metric">
              <span className="dot dot--trust" />
              <span className="name">{lineage.metric}</span>
              <span className="val num">{lineage.value}</span>
            </div>
            <div className="chain">
              {lineage.chain.map((node, i) => (
                <div key={i} className={`chain-node ${node.verified ? "verified" : ""}`}>
                  <div className="chain-bullet">{String(i + 1).padStart(2, "0")}</div>
                  <div className="chain-content">
                    <div className="chain-label">{node.label}</div>
                    <div className="chain-value">{node.value}</div>
                    <div className="chain-note">{node.note}</div>
                    {node.verified && (
                      <div className="chain-status">
                        <span className="dot dot--ok" /> Verified · lineaged
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="provenance solid" style={{ marginTop: 14 }}>
            <span className="eyebrow eyebrow--mute">What you can do from here</span>
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 14 }}>
              <button className="btn btn--ghost" style={{ justifyContent: "space-between" }}>
                <span>Export evidence pack (PDF · CSV)</span><IconChevron />
              </button>
              <button className="btn btn--ghost" style={{ justifyContent: "space-between" }}>
                <span>Attach to a Present-ready output</span><IconChevron />
              </button>
              <button className="btn btn--ghost" style={{ justifyContent: "space-between" }}>
                <span>Ask Quickball to explain the basis</span><IconChevron />
              </button>
            </div>
          </div>
        </div>
      </aside>
    </React.Fragment>
  );
}

// ---------- WORKFLOW DRAWER ----------
function WorkflowDrawer({ open, action, onClose, onOpenLineage }) {
  const [state, setState] = useState("assigned");
  const [confirm, setConfirm] = useState(null);

  useEffect(() => {
    if (!open) return;
    setState("assigned");
    setConfirm(null);
    function onKey(e) { if (e.key === "Escape") onClose(); }
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose, action]);

  if (!open || !action) return null;
  const wf = window.SCIP.WORKFLOWS.q1; // mock — same flow shape

  function act(label) {
    setConfirm(label);
    if (label === "Close") setState("closed");
    else if (label === "Assign") setState("assigned");
    else if (label === "Reassign") setState("assigned");
    else if (label === "Mark in progress") setState("in_progress");
    else if (label === "Disposition") setState("promised");
    else if (label === "Escalate") setState("escalated");
    setTimeout(() => setConfirm(null), 2200);
  }

  return (
    <React.Fragment>
      <div className="scrim" onClick={onClose} aria-hidden="true" />
      <aside className="drawer workflow-drawer" role="dialog" aria-modal="true" aria-label="Workflow drawer">
        <div className="drawer-head">
          <div>
            <span className="eyebrow">L5 action output · Workflow</span>
            <h2 className="display h2 title">{action.title}</h2>
            <p className="sub">{action.entity} · {action.action_type}. State changes are server operations with immutable lineage hash.</p>
          </div>
          <button className="drawer-close" onClick={onClose} aria-label="Close drawer"><IconClose /></button>
        </div>
        <div className="drawer-body">
          <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
            <span className="workflow-pill">
              <span className="dot dot--ok dot--pulse" /> {state.replace("_", " ")}
            </span>
            <span className="chip">Due 23 May 2026</span>
            <span className="chip">SLA in 2 days</span>
            <span className="chip chip--accent"><span className="shield" /> Lineaged</span>
          </div>

          <div className="workflow-fields">
            <div className="workflow-field"><div className="k">Owner</div><div className="v">{action.owner}</div></div>
            <div className="workflow-field"><div className="k">Amount</div><div className="v">{action.amount}</div></div>
            <div className="workflow-field"><div className="k">Accounts</div><div className="v">{action.account}</div></div>
            <div className="workflow-field"><div className="k">Ageing</div><div className="v">{action.ageing}</div></div>
            <div className="workflow-field"><div className="k">Basis</div><div className="v">{action.basis}</div></div>
            <div className="workflow-field"><div className="k">Severity</div><div className="v" style={{ color: action.severity === "risk" ? "var(--status-risk)" : action.severity === "warn" ? "var(--status-warn)" : "var(--status-ok)" }}>{action.severity.toUpperCase()}</div></div>
          </div>

          <div className="workflow-actions">
            <span className="label">Allowed transitions · audit-logged</span>
            <button className="btn btn--sm btn--ghost" onClick={() => act("Reassign")}>Reassign</button>
            <button className="btn btn--sm btn--ghost" onClick={() => act("Mark in progress")}>Mark in progress</button>
            <button className="btn btn--sm btn--ghost" onClick={() => act("Disposition")}>Log PTP</button>
            <button className="btn btn--sm btn--ghost" onClick={() => act("Escalate")}>Escalate</button>
            <button className="btn btn--sm btn--ghost" onClick={() => onOpenLineage("OD_TODAY", action.title)}>Attach evidence</button>
            <button className="btn btn--sm btn--primary" onClick={() => act("Close")}>Close action</button>
          </div>

          {confirm && (
            <div className="provenance solid edge-accent" role="status" style={{ animation: "menu-in 240ms ease-out" }}>
              <div className="eyebrow eyebrow--mute">Audit · just now</div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 8 }}>
                <div>
                  <div className="h4">{confirm} action posted</div>
                  <div className="small" style={{ marginTop: 4 }}>State moved to <span className="mono" style={{ color: "var(--accent)" }}>{state}</span>. Event appended to workflow log.</div>
                </div>
                <span className="mono" style={{ color: "var(--text-mute)", fontSize: 11 }}>hash {Math.random().toString(16).slice(2, 10)}…</span>
              </div>
            </div>
          )}

          <div style={{ marginTop: 20 }}>
            <span className="eyebrow">Workflow timeline · immutable</span>
            <div className="timeline" style={{ marginTop: 14 }}>
              {wf.timeline.map((ev, i) => (
                <div key={i} className={`timeline-event ${ev.done ? "done" : ""}`}>
                  <div className="timeline-time">{ev.time}</div>
                  <div className="timeline-bullet" />
                  <div className="timeline-content">
                    <div className="ttl">{ev.title}</div>
                    <div className="note">{ev.note}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </aside>
    </React.Fragment>
  );
}

// ---------- QUICKBALL (floating draggable disk) ----------
function Quickball({ visible = true }) {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState("");
  const [answer, setAnswer] = useState(null);
  const [pos, setPos] = useState(() => {
    try {
      const raw = localStorage.getItem("scip:qb:pos");
      if (raw) return JSON.parse(raw);
    } catch (_) {}
    return { x: window.innerWidth - 88, y: window.innerHeight - 88 };
  });
  const [dragging, setDragging] = useState(false);
  const dragState = useRef({ active: false, moved: false, dx: 0, dy: 0 });
  const inputRef = useRef(null);
  const diskRef = useRef(null);

  // persist position
  useEffect(() => {
    try { localStorage.setItem("scip:qb:pos", JSON.stringify(pos)); } catch (_) {}
  }, [pos]);

  // clamp on resize
  useEffect(() => {
    function onResize() {
      setPos((p) => ({
        x: Math.min(Math.max(8, p.x), window.innerWidth - 64),
        y: Math.min(Math.max(8, p.y), window.innerHeight - 64),
      }));
    }
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  // keyboard + external ask
  useEffect(() => {
    function onKey(e) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen(true);
        setTimeout(() => inputRef.current?.focus(), 50);
      } else if (e.key === "Escape" && open) {
        setOpen(false);
      }
    }
    function onExternalAsk(e) {
      const q = e.detail;
      if (!q) return;
      setOpen(true);
      setTimeout(() => {
        setValue(q);
        ask(q);
      }, 40);
    }
    document.addEventListener("keydown", onKey);
    window.addEventListener("scip:quickball:ask", onExternalAsk);
    return () => {
      document.removeEventListener("keydown", onKey);
      window.removeEventListener("scip:quickball:ask", onExternalAsk);
    };
  }, [open]);

  // outside-click close
  useEffect(() => {
    if (!open) return;
    function onClickOutside(e) {
      if (diskRef.current && diskRef.current.contains(e.target)) return;
      const panel = document.querySelector(".quickball-panel");
      if (panel && panel.contains(e.target)) return;
      setOpen(false);
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, [open]);

  // ---- navigation intent parsing (unlocked: Quickball can move you, never invent numbers) ----
  const NAV_TARGETS = [
    { match: /\b(risk|act|action|queue)/, nav: { route: "live_pulse", focus: "risk_action" }, label: "Risk & Action" },
    { match: /\b(month|movement|run.?rate|forecast|landing)/, nav: { route: "live_pulse", focus: "month_movement" }, label: "Month Movement" },
    { match: /\b(signal|today|current)/, nav: { route: "live_pulse", focus: "current_signal" }, label: "Current Signal" },
    { match: /\b(story|board.?level)/, nav: { route: "narratives", focus: "story" }, label: "Narratives · Story" },
    { match: /\bportfolio/, nav: { route: "narratives", focus: "portfolio" }, label: "Narratives · Portfolio" },
    { match: /\b(dues?|od|overdue|ageing)/, nav: { route: "narratives", focus: "dues" }, label: "Narratives · Dues" },
    { match: /\b(advance|rebate)/, nav: { route: "narratives", focus: "advance" }, label: "Narratives · Advance" },
    { match: /\broadmap/, nav: { route: "narratives", focus: "roadmap" }, label: "Narratives · Roadmap" },
    { match: /\bnarrative/, nav: { route: "narratives" }, label: "Narratives" },
    { match: /\b(live ?pulse|pulse)/, nav: { route: "live_pulse" }, label: "Live Pulse" },
  ];
  const NAV_ENTITIES = [
    { match: /sobha dubai/, entity: "sobha_dubai", label: "Sobha Dubai" },
    { match: /sobha auh|abu dhabi/, entity: "sobha_auh", label: "Sobha AUH" },
    { match: /downtown/, entity: "downtown_uaq", label: "Downtown UAQ" },
    { match: /siniya/, entity: "siniya", label: "Siniya" },
    { match: /\buaq\b/, entity: "uaq", label: "UAQ" },
    { match: /\bsobha\b/, entity: "sobha", label: "Sobha" },
    { match: /\bgroup\b/, entity: "group", label: "Group" },
  ];

  function parseNavIntent(norm) {
    // present intent
    if (/\b(present|briefing mode|board mode|slideshow)\b/.test(norm)) {
      return { nav: { present: true }, label: "Present mode" };
    }
    const isNavPhrase = /(take me|go to|open|show me|switch to|navigate|jump to|move to)/.test(norm);
    // entity switch — "switch to sobha dubai"
    const ent = NAV_ENTITIES.find((e) => e.match.test(norm));
    if (ent && /switch|scope|entity|change/.test(norm)) {
      return { nav: { entity: ent.entity }, label: `Entity → ${ent.label}` };
    }
    if (!isNavPhrase) return null;
    const target = NAV_TARGETS.find((t) => t.match.test(norm));
    if (target) {
      const nav = { ...target.nav };
      let label = target.label;
      if (ent) { nav.entity = ent.entity; label += ` · ${ent.label}`; }
      return { nav, label };
    }
    if (ent) return { nav: { entity: ent.entity }, label: `Entity → ${ent.label}` };
    return null;
  }

  function ask(q) {
    const norm = (q || "").toLowerCase().trim();
    if (!norm) return;
    setValue(q);

    // 1) navigation intent — move, don't explain
    const intent = parseNavIntent(norm);
    if (intent) {
      window.dispatchEvent(new CustomEvent("scip:nav", { detail: intent.nav }));
      setAnswer({
        metric: "Navigating",
        value: intent.label,
        answer: `Taking you to ${intent.label}. Quickball can move you anywhere — it will still never invent a number.`,
        basis: "Navigation intent · no data asserted",
        blocked: false,
        isNav: true,
      });
      // auto-collapse shortly after navigating
      setTimeout(() => { setOpen(false); setAnswer(null); setValue(""); }, 1600);
      return;
    }

    // 2) lineaged explanations
    const match = Object.entries(window.SCIP.QUICKBALL_ANSWERS).find(([k]) => norm.includes(k.split(" ").slice(0, 3).join(" ")));
    if (match) {
      setAnswer(match[1]);
    } else {
      setAnswer({ ...window.SCIP.BLOCKED_ANSWER, value: "—", answer: `No lineaged answer found for "${q}". Quickball will not invent one.`, blocked: true });
    }
  }

  // pointer-down on disk: arm potential drag; click if no move
  function onPointerDown(e) {
    const rect = diskRef.current.getBoundingClientRect();
    dragState.current = {
      active: true,
      moved: false,
      dx: e.clientX - rect.left,
      dy: e.clientY - rect.top,
      startX: e.clientX,
      startY: e.clientY,
    };
    diskRef.current.setPointerCapture(e.pointerId);
  }
  function onPointerMove(e) {
    const st = dragState.current;
    if (!st.active) return;
    const dxAbs = Math.abs(e.clientX - st.startX);
    const dyAbs = Math.abs(e.clientY - st.startY);
    if (!st.moved && dxAbs + dyAbs > 4) {
      st.moved = true;
      setDragging(true);
    }
    if (st.moved) {
      const nx = Math.min(Math.max(8, e.clientX - st.dx), window.innerWidth - 64);
      const ny = Math.min(Math.max(8, e.clientY - st.dy), window.innerHeight - 64);
      setPos({ x: nx, y: ny });
    }
  }
  function onPointerUp(e) {
    const st = dragState.current;
    const moved = st.moved;
    dragState.current = { active: false, moved: false, dx: 0, dy: 0 };
    setDragging(false);
    try { diskRef.current.releasePointerCapture(e.pointerId); } catch (_) {}
    if (!moved) {
      // tap → toggle open
      setOpen((o) => {
        const next = !o;
        if (next) setTimeout(() => inputRef.current?.focus(), 50);
        return next;
      });
    }
  }

  // Compute panel anchor — open above-left or above-right of disk depending on position
  const panelAnchor = useMemo(() => {
    const right = pos.x > window.innerWidth / 2;
    const bottom = pos.y > window.innerHeight / 2;
    const style = {};
    if (right) style.right = window.innerWidth - pos.x - 56;
    else style.left = pos.x;
    if (bottom) style.bottom = window.innerHeight - pos.y + 14;
    else style.top = pos.y + 70;
    return style;
  }, [pos, open]);

  if (!visible) return null;

  return (
    <React.Fragment>
      <div
        ref={diskRef}
        className={`quickball-disk ${dragging ? "dragging" : ""}`}
        style={{ left: pos.x, top: pos.y }}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        role="button"
        tabIndex={0}
        aria-label="Quickball — drag to move, tap to ask"
      >
        <IconSearch size={18} />
        <span className="kbd-tip">DRAG · TAP · ⌘K</span>
      </div>

      {open && (
        <div className="quickball-panel" style={panelAnchor} role="dialog" aria-label="Quickball">
          <div className="quickball-row">
            <div className="quickball-mark"><IconSearch /></div>
            <input
              ref={inputRef}
              className="quickball-input"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") ask(value); }}
              placeholder="Ask Quickball — explain a number, source, change, action…"
              aria-label="Ask Quickball"
              autoFocus
            />
            <button className="btn btn--sm btn--primary" onClick={() => ask(value)}>Ask</button>
            <button className="btn btn--sm btn--icon btn--ghost" onClick={() => { setOpen(false); setAnswer(null); setValue(""); }} aria-label="Collapse"><IconClose /></button>
          </div>

          {!answer && (
            <div className="quickball-suggest" style={{ marginTop: 0, paddingTop: 0, borderTop: 0 }}>
              <div className="heading">Try one</div>
              <div className="row">
                {window.SCIP.QUICKBALL_SUGGEST.map((s) => (
                  <button key={s} onClick={() => ask(s)}>{s}</button>
                ))}
              </div>
            </div>
          )}

          {answer && (
            <div className={`quickball-answer ${answer.blocked ? "blocked" : ""}`} role="status">
              <div className="label">{answer.blocked ? "Quickball blocked an untrusted answer" : `${answer.metric} · ${answer.value}`}</div>
              <p className="answer">{answer.answer}</p>
              <div className="basis">Basis · {answer.basis}</div>
              {!answer.blocked && (
                <div style={{ marginTop: 12, display: "flex", gap: 6 }}>
                  <button className="btn btn--sm btn--ghost" onClick={() => { setAnswer(null); setValue(""); inputRef.current?.focus(); }}>Ask another</button>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </React.Fragment>
  );
}

Object.assign(window, { LineageDrawer, WorkflowDrawer, Quickball });
