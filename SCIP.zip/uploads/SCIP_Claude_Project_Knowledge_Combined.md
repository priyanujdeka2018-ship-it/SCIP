# SCIP Claude Project Knowledge Pack

This combined Markdown file contains the four project knowledge files converted from the uploaded `.txt` sources and cleaned for Claude Project Knowledge upload.



---

# SCIP Platform Improvement Analysis

_Source converted from `SCIP Platform Improvement Analysis.txt`._

Below is a single copy-paste handoff block for a new conversation.

---

```text
SCIP PROJECT HANDOFF — FULL CONTINUITY BLOCK

Project: SCIP — Sobha Collections Intelligence Platform
Purpose: Build SCIP into a trusted, role-aware, lineage-backed, Liquid Glass intelligence platform for Sobha collections, operating from executive briefing down to account-level action and closure tracking.

Current project status:
- SCIP is NOT yet production-live.
- SCIP is ready as a staging / pilot / UAT release candidate once patches are merged into the actual repo and live environment gates pass.
- A go-live consolidation pack has been produced.
- Production go-live should happen only after real repo merge, builds, migrations, SSO/JWT, source refresh, deployment smoke, role-wise UAT, RBAC, audit, notification, fallback, rollback, and break-glass gates pass.

CORE VISION

SCIP must feel less like a dashboard and more like an intelligent boardroom instrument:
- Calm on arrival.
- Fluid in navigation.
- Precise in evidence.
- Powerful only when the user asks for depth.

The platform must serve internal org users across hierarchy without overwhelming them:
- Board/CXO: board-safe story, risk, decision, confidence.
- CCO/GM/AGM: intervention control, run-rate, action queues, escalations.
- Finance: reconciliation, PR/SOA issues, audit, target basis.
- MIS/QCG/Admin: data health, governance, source refresh, process queues.
- Collector/RM: own action queues, promise follow-up, account drilldowns.

LOCKED LIQUID GLASS STRATEGY

Liquid Glass is not a decorative skin. It is the interaction model.

Locked rules:
1. L0 Arrival has only two doors:
   - Live Pulse
   - Narratives
2. No third Arrival door.
3. No dashboard-first home.
4. No sidebar, filters, KPI grids, Ops/Board toggles, raw section tree, charts, collector names, or definitions at Arrival.
5. Quickball is a quiet contextual command capsule, not a loud chatbot or third navigation path.
6. Glass is used for movement/context/reveal:
   - arrival cards
   - rails
   - chips
   - Quickball capsule
   - drawers
   - context island
7. Solid surfaces are used for financial truth:
   - KPI cards
   - charts
   - dense tables
   - formulas
   - audit trails
   - evidence
   - collector/action lists
8. Live Pulse L1 has only:
   - Current Signal
   - Month Movement
   - Risk & Action
9. Narratives follows:
   - Story
   - Portfolio
   - Dues
   - Advance
   - Roadmap
10. Evidence is shown only on request.
11. Actions are close to context.
12. Present is an output action, not a browsing mode.
13. Primary UI language avoids Ops/Board. Use Summary, Detailed, Executive, Present, Evidence, Source basis, Formula, Ask Quickball.

LOCKED ENTITY HIERARCHY

Group
  Sobha
    Sobha Dubai
    Sobha AUH
  UAQ
    Siniya
    Downtown UAQ

R18 OD mapping:
- Sub Total A-E = Sobha Dubai
- Sub Total H = Sobha AUH
- Sub Total F = Siniya
- Sub Total G = Downtown UAQ
- Sobha = Sobha Dubai + Sobha AUH
- UAQ = Siniya + Downtown UAQ
- Group / OD Today = Sobha + UAQ = Grand Total

TOLERANCE / TRUST RULES

- General reconciliation tolerance: 0.05%.
- No silent fallback in Board/CXO or critical views.
- If source extraction fails or lineage is missing, show blocked/unavailable/fallback-labelled state.
- No critical metric may be displayed as trusted unless it has:
  - source file
  - report code
  - sheet
  - cell/range or extraction rule
  - snapshot date
  - reporting basis
  - validation status
  - confidence state
  - lineage reference/hash
- Quickball must refuse/block critical answers without lineage.
- No frontend business computation.
- Frontend can render only server-provided metrics, labels, assumptions, lineage, and trust state.

LOCKED ROLE MODEL

Keep:
- Board/CXO
- CCO/GM/AGM
- Finance
- MIS/QCG/Admin
- Collector/RM

Remove / block:
- Entity Head

Entity Head was explicitly removed from the role model. Do not reintroduce unless a future formal product decision changes it.

REPORTING BASIS RULES

- R04 = Finance daily actuals.
- R02 = MDO targets / MDO actuals where available.
- R08 = Advance CY/FY/rebate/NPV basis.
- R18 = OD / overdue / ageing source.
- R36 = milestone cohort / forward collectible calendar.
- Finance-vs-MDO labels must remain visible wherever mixed.

CRITICAL R-SERIES SOURCES

Core platform intelligence:
- R01 — Year-end snapshot
- R02 — MDO report
- R04 — Daily collections
- R08 — Advance summary
- R18 — Consolidated and overdue
- R36 — Year-on-year milestone report

Account/action queue layer:
- R09 — Collections / project collection detail
- R10 — Dues coverage / allocation / PTP
- R17 — SPA / pre-registration overdue bifurcation
- R20 — PR-to-SOA TAT
- R30 — Monthly collector feedback / performance
- R31 — PR unit update
- R32 — RM collectors and PR/receipts
- R34 — Termination status
- R38 — Risk analysis

Minimum production go-live source set:
- R02, R04, R08, R18, R36
- R09, R10, R17, R20, R30, R31, R32, R34, R38

ARCHITECTURAL UPGRADE DECISIONS

1. Replace generic Excel ingestion with report-specific adapters.
   Adapters created/planned:
   - R01YearEndSnapshotAdapter
   - R02MDOAdapter
   - R04FinanceDailyAdapter
   - R08AdvanceSummaryAdapter
   - R18OverdueAdapter
   - R36MilestoneCohortAdapter
   - R09ProjectCollectionsAdapter
   - R10DuesCoverageAdapter
   - R17SPALegalAdapter
   - R20PRSOATATAdapter
   - R30CollectorFeedbackAdapter
   - R31PRUnitUpdateAdapter
   - R32RMCollectorsReceiptsAdapter
   - R34TerminationStatusAdapter
   - R38RiskAnalysisAdapter

2. Every adapter must output lineaged facts, not just dashboard values.

3. Semantic model should separate facts/dimensions:
   Facts:
   - fact_collections_daily
   - fact_targets_monthly
   - fact_advance_cyfy
   - fact_overdue_snapshot
   - fact_overdue_ageing
   - fact_milestone_cohort
   - fact_future_collectibles
   - fact_project_collections
   - fact_account_actions
   - fact_workflows
   - fact_notifications
   - fact_audit_exports
   - fact_adoption_events
   - fact_observability_events

   Dimensions:
   - dim_date
   - dim_entity
   - dim_project
   - dim_customer
   - dim_unit
   - dim_collector
   - dim_team
   - dim_source_report
   - dim_metric_definition
   - dim_org_hierarchy
   - dim_role
   - dim_actor
   - dim_workflow_state

4. Quickball is a lineage explainer and curiosity bridge.
   It must answer:
   - “Explain this number”
   - “Where did this come from?”
   - “Why did it change?”
   - “Show source basis”
   - “Show formula”
   - “Prepare board explanation”
   - “Open action list”
   It must not hallucinate.

5. Command centres are role-aware but hidden under Liquid Glass intent:
   - Live Pulse / Risk & Action
   - Narratives / Story or Dues or Advance
   Not exposed as a dashboard homepage.

6. Forecasting is server-side.
   Month-end landing uses:
   - R04 MTD actuals
   - R02 May MDO targets
   - working days
   - remaining working days
   - current run-rate
   - required run-rate
   Forecast must disclose assumptions and basis.

7. Account action queues must be gated.
   No action is shown without:
   - account/unit ID
   - owner/collector/RM
   - entity mapping
   - amount or process status
   - ageing or process status
   - source lineage
   - reporting basis
   - role visibility

8. Workflow tracking states:
   - queued
   - assigned
   - in_progress
   - promised
   - escalated
   - closed
   - stale
   - blocked

9. Workflow events are immutable and carry source lineage hash.

10. Notifications are evidence-driven L5 outputs.
    Notification rules:
    - overdue_due_date
    - stale_workflow
    - broken_ptp_promise
    - termination_risk
    - pr_tat_ageing
    - unassigned_high_risk

11. Durable persistence replaces in-memory stores.
    Tables:
    - source_actions
    - workflow_records
    - workflow_events
    - notification_eligibility
    - notification_emissions
    - suppression_state
    - delivery_status
    - audit_exports

12. RBAC is mandatory.
    Board/CXO cannot access account-level queues.
    Collector/RM sees only own rows.
    Finance sees finance queues and finance audit.
    MIS/QCG/Admin has governance/admin scope.
    CCO/GM/AGM sees management and escalation scope.

13. SSO/JWT replaces trusted X-SCIP headers.
    - Production mode: verified JWT.
    - Local dev bypass only if explicitly enabled.
    - Entity Head claims must be rejected.
    - Denied attempts must be logged with correlation ID and audit lineage.

14. Observability is server-side and redacted.
    Metrics include:
    - ingestion latency
    - adapter success/failure
    - lineage coverage
    - forecast generation
    - Quickball blocked answers
    - action queue generation
    - workflow transitions
    - notification emissions/suppressions
    - RBAC denials
    - audit export volume
    - DB query timings
    - frontend render timing
    - API error rates
    - cache hits/misses/invalidations

15. Caching is allowed only where it cannot break:
    - no-silent-fallback
    - lineage freshness
    - source snapshot date checks
    - RBAC row-level visibility

16. Governance is continuous.
    Every improvement item must map to:
    - evidence
    - owner
    - decision state
    - expected impact
    - rollout gate
    - rollback criteria
    - Liquid Glass guardrail
    - priority score

BATCH HISTORY / OUTPUTS CREATED

Batch 0:
- SystemMap v2
- hierarchy/governance pack
- pipeline_config_v8
- lineage contract
- semantic model v2
- source adapter skeletons
- smoke checkpoints

Batch 1:
- R18 OD adapter
- locked hierarchy
- OD lineage
- R18 smoke test

Batch 2:
- R04 Finance daily adapter
- R02 MDO adapter
- Finance-vs-MDO labelling
- R04/R02 smoke tests

Batch 3:
- R08 Advance adapter
- R36 Milestone adapter
- CY/FY/rebate/forward calendar lineage

Batch 4:
- Quickball lineage explanations
- role-specific command centre contracts
- blocked-answer guard

Batch 5:
- UI cards and forecasting
- trust bar
- lineage drawer
- forecast panel

Batch 5.1:
- Liquid Glass UI alignment
- two-door Arrival
- Live Pulse / Narratives model
- glass tokens
- solid evidence surfaces

Batch 6:
- first action queue layer
- discovered R18 alone could not support true account/collector queues
- project-risk queues only, collector queue blocked until account sources arrived

Batch 7:
- onboarded R09/R10/R17/R20/R30/R31/R32/R34/R38
- account-level action queues unlocked
- collector, management, finance, MIS/QCG queues

Batch 8:
- workflow assignment and closure tracking
- workflow states
- immutable event log

Batch 9:
- notification/escalation automation
- dedupe/suppression
- daily/weekly digest payloads

Batch 10:
- durable database persistence
- audit export
- migration-ready SQL

Batch 11:
- RBAC and deployment hardening
- role policy matrix
- CORS/secrets/backup/migration checks

Batch 12:
- observability and performance
- structured logging
- correlation IDs
- dashboard/alert spec
- cache guards

Batch 13:
- SSO/JWT and user provisioning
- claim-to-role mapping
- entity/collector scope provisioning
- deactivation

Batch 14:
- rollout and UAT signoff
- role-wise UAT scripts
- production readiness, source refresh, identity, RBAC, dashboard/alert checklists
- rollback and break-glass runbook

Batch 15:
- post-launch adoption analytics
- adoption dashboards as L5 governance output
- optimization backlog

Batch 16:
- continuous improvement governance
- monthly review workflow
- change-control board
- metric-definition change log
- source-owner SLA review
- Quickball review
- UX simplification review
- release-note governance

Batch 17:
- long-term roadmap and executive operating rhythm
- 12-month roadmap
- quarterly executive operating rhythm
- monthly review calendar
- KPI/OKR tree
- ownership map
- release train model
- benefits tracking
- executive steering committee pack

Go-Live Readiness Consolidation:
- Merged Batch 13 production code baseline + Batch 14 rollout/UAT governance + Batch 17 roadmap into one release-candidate checklist.
- Staging-ready after applying patches to real repo.
- Production-ready only after live gates pass.

LATEST IMPORTANT ARTIFACT PACKS

Use these as baselines in the new conversation:
- /mnt/data/scip_batch13_sso_jwt_provisioning.zip
- /mnt/data/scip_batch14_rollout_uat_signoff.zip
- /mnt/data/scip_batch17_long_term_roadmap_exec_rhythm.zip
- /mnt/data/scip_go_live_readiness_consolidation.zip

Recommended current release-candidate source of truth:
1. Code/security baseline: Batch 13
2. Rollout/UAT/go-live governance: Batch 14
3. Roadmap/executive rhythm: Batch 17
4. Final go-live control checklist: Go-Live Readiness Consolidation pack

MIGRATION ORDER

Apply in this order:

001_batch10_persistence.sql
002_batch11_rbac_hardening.sql
003_batch12_observability.sql
004_batch13_identity_provisioning.sql
005_batch15_adoption_analytics.sql
006_batch16_continuous_improvement.sql
007_batch17_roadmap_exec_rhythm.sql

PROPOSED FINAL FILE / FOLDER HIERARCHY

repo/
  backend/
    main.py
    constants.py
    file_resolver.py
    data_loader.py
    source_adapters.py

    quickball.py
    command_centres.py
    forecast.py
    account_action_queues.py
    workflow.py
    notifications.py
    persistence.py
    auth.py
    identity.py
    deployment.py
    observability.py
    adoption.py
    governance.py
    roadmap.py
    rollout_uat.py

    migrations/
      001_batch10_persistence.sql
      002_batch11_rbac_hardening.sql
      003_batch12_observability.sql
      004_batch13_identity_provisioning.sql
      005_batch15_adoption_analytics.sql
      006_batch16_continuous_improvement.sql
      007_batch17_roadmap_exec_rhythm.sql

    tests/
      smoke_ingestion/
      smoke_quickball/
      smoke_action_queues/
      smoke_workflow/
      smoke_notifications/
      smoke_persistence_audit/
      smoke_rbac/
      smoke_identity/
      smoke_observability/
      smoke_rollout/
      smoke_adoption/
      smoke_governance/
      smoke_roadmap/

  frontend/
    src/
      App.jsx
      main.jsx
      liquidGlassTokens.css
      frontend_contracts/
        frontend_contracts_batch13.ts
        frontend_contracts_batch14.ts
        frontend_contracts_batch15.ts

  config/
    pipeline_config.json
    lineage_contract_v1.json
    semantic_model_v2.json
    observability_config_batch12.json
    rbac_policy_matrix_batch11.json

  data/
    incoming/
      R01/
      R02/
      R04/
      R08/
      R09/
      R10/
      R17/
      R18/
      R20/
      R30/
      R31/
      R32/
      R34/
      R36/
      R38/
    processed/
    audit_exports/

  docs/
    architecture/
      FINAL_ARCHITECTURE.md
      MASTER_ARCHITECTURE_v9.1.md
      Sobha_Platform_Architecture_Blueprint_v1.md
      Sobha_Platform_Engineering_Structure_v1.md

    liquid_glass/
      SCIP_Liquid_Glass_UI_Strategy_Final_Unified.docx

    rollout/
      SCIP_Batch14_Staged_Rollout_Plan.md
      SCIP_Batch14_Rollback_BreakGlass_Runbook.md

    uat/
      SCIP_Batch14_UAT_Scripts_By_Role.md

    governance/
      SCIP_Batch16_Backlog_Scoring_Model.md
      monthly_review_templates/

    roadmap/
      SCIP_Batch17_12_Month_Roadmap.md
      SCIP_Batch17_Quarterly_Executive_Operating_Rhythm.md
      SCIP_Batch17_Monthly_Review_Calendar.md
      SCIP_Batch17_KPI_OKR_Tree.md
      SCIP_Batch17_Ownership_Map.md
      SCIP_Batch17_Release_Train_Model.md
      SCIP_Batch17_Benefits_Realization_Tracking.md
      SCIP_Batch17_Executive_Steering_Committee_Pack.md

    go_live/
      SCIP_Final_GoLive_Command_Sequence.md
      SCIP_Release_Candidate_Checklist.md
      SCIP_Merge_Order_and_File_Map.md
      SCIP_Migration_Order.md
      SCIP_Blockers_Assumptions_Register.md
      SCIP_Final_Production_Readiness_Checklist.md

  smoke/
    deployment_smoke_runner.py
    final_deployment_smoke_manifest_batch14.json
    go_live_static_validation_results.json

  package.json
  vite.config.js
  netlify.toml
  README.md

REDUNDANCY ELIMINATION STEPS

Eliminate or prevent:
1. Generic Excel flat-header ingestion for complex R-series files.
2. Silent fallback values in critical or executive views.
3. Duplicate health endpoints; keep one canonical health/deployment health structure.
4. Inconsistent pipeline config names; use one production pipeline_config.json.
5. Entity Head role.
6. Top-level Ops/Board language.
7. Third Arrival door.
8. Homepage dashboard/KPI clutter.
9. Persistent sidebar at L0.
10. Quickball as a workaround for unclear UI.
11. Frontend financial/business computation.
12. Trusted X-SCIP headers in production.
13. Unlineaged Quickball answers.
14. Unlineaged action queues.
15. Notifications without dedupe/suppression keys.
16. Workflow events without immutable source lineage.
17. Audit exports without actor/timestamp/role/lineage.
18. Observability logs containing sensitive raw bodies, tokens, account/customer PII, or unredacted claims.
19. Caching that ignores snapshot date, lineage freshness, RBAC, or fallback state.
20. Governance/backlog dashboards as new product surfaces.

SUCCESS METRICS

Data trust:
- 100% critical KPI lineage coverage.
- 0 silent fallback incidents in Board/CXO views.
- 0 unlineaged Quickball critical answers.
- 0 account actions without owner/entity/amount-or-status/ageing-or-process-status/source lineage.
- Source freshness SLA met for all critical R files.
- Reconciliation checks pass within 0.05% tolerance.

Ingestion:
- Adapter success rate ≥ 99% for required R-series files.
- Critical source extraction failure alert within same refresh cycle.
- Smoke tests pass for R02/R04/R08/R18/R36 and R09/R10/R17/R20/R30/R31/R32/R34/R38.

Operational:
- Collector/RM action queue conversion rate improves month-on-month.
- Workflow closure rate increases.
- Stale workflow count decreases.
- Broken PTP follow-ups become visible and decrease over time.
- PR/TAT ageing exceptions reduce.
- Termination-risk actions are assigned and tracked.

Executive:
- Board/CXO can answer:
  - Are we on track?
  - What changed?
  - Why?
  - What is the risk?
  - What action is needed?
- Board narrative generation uses trusted lineage.
- Forecast assumptions are always disclosed.

Security/governance:
- 100% JWT/SSO enforcement in production.
- 0 production use of local-dev header bypass.
- RBAC row-level tests pass by role.
- Denied attempts are logged with correlation ID.
- Audit export passes.
- Backup/restore checks pass.
- Notification dedupe survives restart.
- Migration history recorded.

UX/Liquid Glass:
- Arrival has only Live Pulse and Narratives.
- Live Pulse L1 has only Current Signal, Month Movement, Risk & Action.
- Narratives remains Story → Portfolio → Dues → Advance → Roadmap.
- No dense evidence before explicit depth request.
- Glass only for context/movement/reveal.
- Solid surfaces for truth/evidence.

Adoption:
- Role-level engagement tracked.
- Quickball explanation usage tracked.
- Evidence path opens tracked.
- Forecast review frequency tracked.
- Workflow/action conversion tracked.
- UAT-to-production defect trends tracked.
- Optimization backlog items map to evidence and owner.

GO-LIVE COMMAND SEQUENCE SUMMARY

1. Create release branch.
2. Apply code patches from Batch 13 baseline.
3. Apply rollout/UAT docs from Batch 14.
4. Apply roadmap/governance docs from Batch 17.
5. Ensure final go-live consolidation files are included under docs/go_live.
6. Install backend dependencies.
7. Install frontend dependencies.
8. Run backend compile/tests.
9. Run frontend build:
   - npm install
   - npm run build
   - npm run dev
10. Configure staging env vars:
   - SCIP_ENV=staging
   - SCIP_AUTH_MODE=jwt
   - SCIP_LOCAL_DEV_BYPASS=false
   - SCIP_JWT_ISSUER
   - SCIP_JWT_AUDIENCE
   - SCIP_JWKS_URL or signing key config
   - DATABASE_URL
   - SCIP_ALLOWED_ORIGINS
   - SCIP_BACKUP_TARGET
   - SCIP_OBSERVABILITY_ENABLED=true
   - source directory paths
11. Apply migrations in locked order.
12. Provision users/groups/roles/scopes.
13. Load latest production R-series files into staging.
14. Run ingestion smoke tests.
15. Run deployment smoke runner:
   SCIP_BASE_URL=<staging-url> SCIP_JWT=<role-token> python smoke/deployment_smoke_runner.py
16. Verify:
   - Liquid Glass two-door navigation
   - no-silent-fallback
   - identity enforcement
   - row-level visibility
   - audit export
   - workflow closure
   - notification dedupe
   - observability correlation IDs
17. Complete role-wise UAT.
18. Confirm rollback and break-glass.
19. Approve production signoff.
20. Promote to production with same gates repeated.

CURRENT PRODUCTION BLOCKERS / ASSUMPTIONS

Blockers until resolved:
1. Patches are not yet merged into actual production repo.
2. Full frontend build has not been executed in the real repo.
3. Backend tests have not been run against deployed services.
4. Real SSO/JWT issuer/audience/JWKS/claims are not configured here.
5. Production database URL/secrets/backups are not configured here.
6. Production CORS origin not confirmed.
7. Latest production R-series files must be loaded in target environment.
8. Real base URL and role-specific JWTs are needed for live smoke.
9. Role-wise UAT signoff is pending.
10. Rollback and break-glass owners need final confirmation.

Assumptions:
- Enterprise IdP can provide JWT claims for role, group, entity scope, and collector mapping.
- Production environment supports durable DB migrations.
- R-series source file naming remains sufficiently consistent for resolver/adapters.
- Finance/MDO distinction remains required in UI.
- Sobha AUH child split is not always available in all sources; disclose rather than invent.
- Liquid Glass source document remains locked unless formally superseded.

NEXT BEST ACTION

Apply the Go-Live Readiness Consolidation pack to the actual repo and execute staging deployment.

Recommended prompt to continue:

“Use this handoff block as the project source of truth. Continue from Go-Live Readiness Consolidation. Help me apply the release candidate to the real SCIP repo step by step: first produce the exact repo merge checklist and file replacement order, then the staging environment variable checklist, then the commands for backend tests, frontend build, migrations, source refresh, smoke tests, role-wise UAT, rollback, break-glass, and production signoff. Do not introduce new product scope unless a blocker requires it.”
```



---

# SCIP Frontend Build Fix

_Source converted from `SCIP Frontend Build Fix.txt`._

Below is a **gapless continuation handoff** for the next conversation or for resuming UAT from here.

---

# SCIP UAT Continuation Handoff — Current State

Project: **SCIP — Sobha Collections Intelligence Platform**

Current mode:

```text
SCIP Staging Product UAT
Cloudflare Pages frontend
Render backend
Google Drive R-series live-folder bootstrap
Security/SSO/JWT production validation deferred
NOT production-live
```

This must **not** be called production-live. The source-of-truth says production go-live requires real repo merge, builds, migrations, SSO/JWT, source refresh, deployment smoke, role-wise UAT, RBAC, audit, notifications, fallback, rollback, break-glass, and final signoff gates.

---

# Current URLs

```text
Frontend:
https://scip-1jy.pages.dev/

Backend:
https://scip.onrender.com

GitHub branch currently used:
release

Render runtime working directory:
go-live-rc1/Backend

Backend runtime module:
main:app

Current Render start command:
python -u bootstrap_rseries_google_drive_folder.py && uvicorn main:app --host 0.0.0.0 --port $PORT
```

Important: although earlier docs referenced `release/go-live-rc1`, the actual active GitHub branch used during this deployment is:

```text
release
```

Do not switch Cloudflare/Render to `release/go-live-rc1` unless that branch is actually created.

---

# Current Deployment Status

## Backend

Render backend deploy is successful.

Open checks:

```text
https://scip.onrender.com/health
https://scip.onrender.com/manifest
```

Known backend state from Render logs:

```text
Resolved 13/28 R-series files
Data load complete. Status=partial. Sources: 13 ok / 13 missing
GET /forecast/month-end HTTP/1.1 200 OK
OPTIONS /command-centres HTTP/1.1 200 OK
```

Interpretation:

```text
Backend is alive.
Google Drive bootstrap is working.
R-series files are being downloaded.
data_loader is reading from /tmp/scip/r-series.
Source resolution is partial but successful.
Some noncritical R-series are missing and gracefully degraded.
```

## Frontend

Cloudflare Pages frontend now loads and navigation works.

Observed behavior:

```text
Frontend hard refresh can take several minutes on first load.
After waiting, page loaded.
Navigation works.
```

Interpretation:

```text
Deployment is no longer blocked.
Current issue is UAT performance / data warmup, not static frontend failure.
```

Likely reason for slow first load:

```text
Render Free cold start
+ Google Drive folder download
+ Excel parsing
+ multiple startup API calls
```

This should be documented as a UAT performance issue, not a trust failure.

---

# Locked SCIP Rules Still in Force

SCIP must remain a trusted, role-aware, lineage-backed Liquid Glass intelligence platform. The core rules remain:

```text
No frontend business computation.
No silent fallback figures.
Frontend renders only server-provided metrics, labels, assumptions, lineage, and trust state.
Critical metrics require source file, report code, sheet, cell/range or extraction rule, snapshot date, reporting basis, validation status, confidence state, and lineage reference/hash.
Quickball must block/refuse critical answers without lineage.
```

These are locked in the project source-of-truth.

Liquid Glass rules remain locked:

```text
Arrival has only two doors:
- Live Pulse
- Narratives

No third Arrival door.
No dashboard-first home.
No sidebar at Arrival.
No Ops/Board toggle language.
Quickball is quiet/contextual, not a loud chatbot.
Live Pulse has only:
- Current Signal
- Month Movement
- Risk & Action

Narratives follows:
- Story
- Portfolio
- Dues
- Advance
- Roadmap
```

The Liquid Glass, no-third-door, no-dashboard-first, no-sidebar, and evidence-on-request rules are explicit in the source-of-truth.

Role model remains locked:

```text
Keep:
- Board/CXO
- CCO/GM/AGM
- Finance
- MIS/QCG/Admin
- Collector/RM

Remove/block:
- Entity Head
```

---

# Reporting Basis Rules

Keep these visible wherever relevant:

```text
R04 = Finance daily actuals
R02 = MDO targets / MDO actuals where available
R08 = Advance CY/FY/rebate/NPV basis
R18 = OD / overdue / ageing source
R36 = milestone cohort / forward collectible calendar
```

Finance-vs-MDO labels must remain visible wherever mixed.

Minimum source set:

```text
Core number validation:
R02, R04, R08, R18, R36

Action/account queue validation:
R09, R10, R17, R20, R30, R31, R32, R34, R38
```

These are the documented minimum production/go-live source files, and adapters must output lineaged facts, not dashboard-only values.

---

# Current Google Drive R-Series Setup

Live Google Drive folder:

```text
https://drive.google.com/drive/folders/1ptIW0bTH9QJfsvdV0e62_NN6OU0B7cw7?usp=share_link
```

Folder ID:

```text
1ptIW0bTH9QJfsvdV0e62_NN6OU0B7cw7
```

Render env vars for Google Drive source bootstrap:

```text
SCIP_RSERIES_BOOTSTRAP=true
SCIP_GOOGLE_DRIVE_FOLDER_ID=1ptIW0bTH9QJfsvdV0e62_NN6OU0B7cw7
SCIP_SOURCE_ROOT=/tmp/scip/r-series
```

The R-series files are **not** committed to GitHub. That is correct: source workbooks must stay outside the public repo; GitHub should keep only placeholders such as `data/.gitkeep`.

---

# Google Drive Bootstrap Fixes Already Applied

These issues were found and fixed:

## 1. Bootstrap file was in the wrong path

Render was running from:

```text
/opt/render/project/src/go-live-rc1/Backend
```

So this file had to live here:

```text
go-live-rc1/Backend/bootstrap_rseries_google_drive_folder.py
```

not repo root.

## 2. gdown unsupported flag removed

Failure:

```text
gdown: error: unrecognized arguments: --remaining-ok
```

Fixed by replacing:

```python
["gdown", "--folder", folder_ref, "-O", str(download_dir), "--remaining-ok"]
```

with:

```python
["gdown", "--folder", folder_ref, "-O", str(download_dir)]
```

## 3. `data_loader.py` was hardcoded to repo `/data`

Old behavior:

```python
DATA_DIR = (_HERE.parent / "data").resolve()
```

This ignored:

```text
SCIP_SOURCE_ROOT=/tmp/scip/r-series
```

Fixed by patching `go-live-rc1/Backend/data_loader.py` to use:

```python
DEFAULT_DATA_DIR = (_HERE.parent / "data").resolve()
DATA_DIR = Path(
    os.environ.get("SCIP_SOURCE_ROOT")
    or os.environ.get("DATA_DIR")
    or DEFAULT_DATA_DIR
).resolve()
PIPELINE_CONFIG_PATH = (_HERE / "pipeline_config.json").resolve()

logger.info("SCIP data source directory resolved to: %s", DATA_DIR)
```

After this patch, the loader correctly reads Google Drive-downloaded workbooks from:

```text
/tmp/scip/r-series
```

---

# R-Series Filename Requirement

The active `file_resolver.py` matches files by R-code prefix and expects a filename like:

```text
R04_Some_Name.xlsx
R18_Consolidated_Overdue.xlsx
R36_Milestone_Cohort.xlsx
```

Avoid:

```text
R04 Daily Collections.xlsx
Daily Collections R04.xlsx
R18 latest.xlsx
~$R04_Daily_Collections.xlsx
```

Important regex behavior:

```text
R04_Anything.xlsx  ✅
R04.xlsx           ✅
R04 Anything.xlsx  ❌ likely skipped
Anything_R04.xlsx  ❌ skipped
```

Use `.xlsx` where possible. The resolver supports `.xlsx` and `.xlsb`; do not rely on `.xls` for UAT unless the backend is patched.

---

# Current Render / Cloudflare Env Variables

## Render backend

Keep staging values:

```text
SCIP_ENV=staging
SCIP_LOCAL_DEV_BYPASS=true
SCIP_ALLOWED_ORIGINS=https://scip-1jy.pages.dev,https://scip.netlify.app
CORS_ALLOWED_ORIGINS=https://scip-1jy.pages.dev
FRONTEND_URL=https://scip-1jy.pages.dev
SCIP_SOURCE_ROOT=/tmp/scip/r-series
SCIP_RSERIES_BOOTSTRAP=true
SCIP_GOOGLE_DRIVE_FOLDER_ID=1ptIW0bTH9QJfsvdV0e62_NN6OU0B7cw7
```

Auth mode during UAT has been treated as staging/deferred. If browser CORS/header issues recur, check whether `SCIP_AUTH_MODE` plus CORS header logic allows the `X-SCIP-*` staging headers. For production, this must return to real JWT/SSO validation.

## Cloudflare Pages frontend

Use Production env vars:

```text
NODE_VERSION=22
VITE_BACKEND_URL=https://scip.onrender.com
VITE_SCIP_API_BASE_URL=https://scip.onrender.com
VITE_API_BASE_URL=https://scip.onrender.com
VITE_SCIP_LOCAL_DEV_BYPASS=true
```

Cloudflare env vars are build-time for Vite. After changing them:

```text
Cloudflare Pages → Redeploy
```

---

# Important Frontend Patches Already Applied

Several `src/App.jsx` hardening patches were applied during troubleshooting.

Current intended behavior:

```text
Core product endpoints remain blocking:
- /command-centres
- /forecast/month-end
- /action-queues
- /workflows

UAT-only non-blocking or degraded:
- /notifications
- /persistence/summary
- /security/me
- /identity/me
- /deployment/health
- /observability/*
- /audit/export
```

Reason:

```text
For Product UAT, optional operational/governance surfaces should not block Arrival / Live Pulse / Narratives.
For production, these must be restored and validated as go-live gates.
```

Important previous errors fixed:

```text
SCIP unavailable / Load failed
identityJson is not defined
/security/me blocking entire app
/notifications network/CORS: Load failed
/persistence/summary 500 required_demo_record_not_found
```

Current frontend behavior after patches:

```text
Arrival shell loads after backend warmup.
Navigation works.
Diagnostics show endpoint-specific errors when failures occur.
No fake fallback figures are introduced.
```

---

# Current Known UAT-Only Exceptions

Document these as **UAT-only**, not permanent:

```text
/security/me may be unavailable while SSO/JWT is deferred.
/identity/me may be unavailable while SSO/JWT is deferred.
/deployment/health may remain protected.
/observability/* may be unavailable.
/notifications may be unavailable or non-blocking.
/persistence/summary may return required_demo_record_not_found until Batch 10 persistence seed/migration is fixed.
/audit/export may require protected/download flow later.
```

Production must later restore/validate these gates. Durable persistence, RBAC, SSO/JWT, audit export, notifications, and observability are part of the production command sequence and success metrics.

---

# Performance Observation

Current issue:

```text
Initial frontend load can take a few minutes.
```

Cause:

```text
Render Free cold start
+ Google Drive source download
+ Excel workbook parsing
+ frontend waiting for required product endpoints
```

UAT workaround:

```text
1. Open https://scip.onrender.com/health first.
2. Wait until backend responds.
3. Check Render logs for data load complete.
4. Then open https://scip-1jy.pages.dev/.
5. Wait 1–3 minutes on first load if needed.
```

Permanent fixes later:

```text
Backend:
- Add in-memory source payload cache for staging.
- Cache must not break no-silent-fallback, lineage freshness, source snapshot date, or RBAC visibility.

Frontend:
- Show Arrival shell immediately.
- Load command-centres and forecast in background.
- Lazy-load action queues/workflows only when Risk & Action opens.
```

Caching is allowed only where it does not break no-silent-fallback, lineage freshness, snapshot checks, or RBAC visibility.

---

# Immediate Next Step: Continue Product UAT

Because frontend now loads and navigation works, continue with **number validation and product UAT**.

## Step 1 — Warm backend

Open:

```text
https://scip.onrender.com/health
https://scip.onrender.com/manifest
```

Then check Render logs for:

```text
[SCIP bootstrap] Source root ready: /tmp/scip/r-series
SCIP data source directory resolved to: /tmp/scip/r-series
Resolved 13/28 R-series files
Data load complete. Status=partial
```

## Step 2 — Open frontend

Open:

```text
https://scip-1jy.pages.dev/
```

Wait if needed. Do not repeatedly hard-refresh during cold start.

## Step 3 — Validate numbers

Start with:

```text
Live Pulse → Month Movement
```

Check:

```text
MTD actual
May target
Current run-rate
Required run-rate
Projected landing
Projected achievement
Finance/MDO basis labels
Forecast assumptions
Evidence / lineage drawer
```

Forecast must be server-side and disclose R04/R02 basis, working days, current run-rate, required run-rate, and assumptions.

Then test:

```text
Narratives → Dues
Narratives → Advance
Risk & Action
Evidence / lineage drawer
Quickball explanation
```

## Step 4 — If numbers remain unavailable

If the UI loads but values still show `Unavailable`, the issue is now likely **adapter extraction**, not deployment.

Likely causes:

```text
Workbook found but layout differs from adapter expectation.
Sheet name differs.
Required subtotal labels differ.
Data is in another tab.
File is .xls/.xlsb when adapter expects .xlsx/openpyxl.
Filename is correct but wrong report version was uploaded.
R-code source exists but metric-specific cell/range extraction failed.
Lineage exists but metric value is null.
```

Next diagnostic in that case:

```text
Open evidence drawer for the unavailable card.
Check whether lineage exists.
If lineage missing: adapter did not produce metric lineage.
If lineage exists but value unavailable: extraction/calculation mapping failed.
```

## Step 5 — Validate locked product rules

Check:

```text
Arrival has only Live Pulse and Narratives.
No third Arrival door.
No dashboard-first clutter.
No sidebar at Arrival.
No Ops/Board toggle language.
Quickball is quiet and contextual.
No Entity Head role appears.
```

These are non-negotiable Liquid Glass / role-model rules.

---

# Product UAT Checklist

Use this as the next working checklist.

## Arrival

```text
[ ] Frontend opens at https://scip-1jy.pages.dev/
[ ] Arrival has only Live Pulse and Narratives.
[ ] No third Arrival door.
[ ] No dashboard-first KPI grid.
[ ] No sidebar at Arrival.
[ ] No raw section tree at Arrival.
[ ] No Ops/Board toggle language.
[ ] Quickball appears only as quiet command capsule.
```

## Live Pulse

```text
[ ] Current Signal opens.
[ ] Month Movement opens.
[ ] Risk & Action opens.
[ ] Month Movement shows forecast panel.
[ ] Forecast values are populated or clearly unavailable with no fallback.
[ ] R04 Finance and R02 MDO labels visible.
[ ] Forecast assumptions visible.
[ ] Evidence drawer opens.
[ ] No frontend-computed figures appear.
```

## Narratives

```text
[ ] Story opens.
[ ] Portfolio opens.
[ ] Dues opens.
[ ] Advance opens.
[ ] Roadmap opens.
[ ] Narrative flow feels like guided briefing, not dashboard menu.
[ ] Evidence appears only on request.
[ ] Solid surfaces used for financial truth.
[ ] Glass used for movement/context/reveal.
```

## Roles

```text
[ ] Board/CXO visible.
[ ] CCO/GM/AGM visible.
[ ] Finance visible.
[ ] MIS/QCG/Admin visible.
[ ] Collector/RM visible.
[ ] Entity Head absent.
```

## Actions / Workflows

```text
[ ] Risk & Action loads.
[ ] Action queues show only lineaged/gated actions.
[ ] Collector/account detail does not leak to Board/CXO.
[ ] Workflow drawer opens if action is accessible.
[ ] No unlineaged account action is trusted.
```

## Quickball

```text
[ ] Ask about a number.
[ ] Quickball explains source basis/formula/lineage.
[ ] Quickball blocks if lineage unavailable.
[ ] Quickball does not hallucinate or invent.
```

---

# Defect Logging Format

Use this for every issue:

```text
Area:
Role:
Path:
Expected:
Actual:
Source file/R-code involved:
Lineage present? yes/no:
Screenshot/error:
Severity:
UAT-only acceptable? yes/no:
Production blocker? yes/no:
```

---

# Important Production Blockers Still Open

Do not solve these during Product UAT unless they block product flow:

```text
Real SSO/JWT issuer/audience/JWKS/claims not configured.
Production use of local-dev bypass must be removed.
RBAC row-level tests pending.
Batch 10 persistence migration/seed pending.
persistence/summary required_demo_record_not_found still needs real backend fix.
Notification dedupe must be validated.
Audit export must be validated.
Observability correlation IDs must be validated.
Latest source refresh/smoke tests must pass.
Role-wise UAT signoff pending.
Rollback and break-glass owners pending.
```

The go-live sequence requires migrations, source refresh, smoke tests, identity/RBAC/audit/notification/observability verification, role-wise UAT, rollback/break-glass, and final production signoff.

---

# Continuation Prompt for New Conversation

Use this exact prompt to continue:

```text
Use this handoff as the current SCIP source of truth.

Current state:
- SCIP is staging Product UAT only, not production-live.
- Frontend is Cloudflare Pages: https://scip-1jy.pages.dev/
- Backend is Render: https://scip.onrender.com
- GitHub branch in use is release.
- Render backend runs from go-live-rc1/Backend using:
  python -u bootstrap_rseries_google_drive_folder.py && uvicorn main:app --host 0.0.0.0 --port $PORT
- Google Drive R-series folder bootstrap is working.
- Drive folder ID is 1ptIW0bTH9QJfsvdV0e62_NN6OU0B7cw7.
- SCIP_SOURCE_ROOT is /tmp/scip/r-series.
- data_loader.py has been patched to read SCIP_SOURCE_ROOT.
- Render logs showed Resolved 13/28 R-series files and data load complete with status partial.
- Frontend loads and navigation works after waiting through cold start.
- Current next task is Product UAT and number validation.
- Do not reopen SSO/JWT/JWKS unless product routes are blocked.
- Do not call SCIP production-live.
- Preserve no-silent-fallback, no frontend computation, and lineage trust rules.
- Optional UAT surfaces like notifications, persistence summary, identity/security/deployment/observability may be non-blocking, but production must restore them.

Help continue UAT from Live Pulse → Month Movement number validation, then Narratives, Risk & Action, Evidence/Lineage, role lenses, Quickball, and defect logging. If numbers are unavailable, diagnose adapter extraction/sheet/layout/lineage issues rather than deployment.
```



---

# Go-live Preparation Checklist

_Source converted from `Go-live Preparation Checklist.txt`._

Yes — Batch 0–12 **must be represented**. Use this corrected release-branch structure and upload map.

Branch:

```text
release/go-live-rc1
```

## Final repo folder structure

```text
SCIP/
  Backend/
    main.py
    constants.py
    utils.py
    file_resolver.py
    data_loader.py
    source_adapters.py
    quickball.py
    command_centres.py
    forecast.py
    account_action_queues.py
    workflow.py
    notifications.py
    persistence.py
    auth.py
    deployment.py
    observability.py
    identity.py
    rollout_uat.py
    adoption.py
    governance.py
    roadmap.py

    pipeline_config.json
    rbac_policy_matrix_batch11.json
    observability_config_batch12.json

    migrations/
      001_batch10_persistence.sql
      002_batch11_rbac_hardening.sql
      003_batch12_observability.sql
      004_batch13_identity_provisioning.sql
      005_batch15_adoption_analytics.sql
      006_batch16_continuous_improvement.sql
      007_batch17_roadmap_exec_rhythm.sql

    load_tests/
    audit_exports/

  src/
    App.jsx
    main.jsx
    liquidGlassTokens.css
    frontend_contracts/
      frontend_contracts_batch4.ts
      frontend_contracts_batch5.ts
      frontend_contracts_batch5_1.ts
      frontend_contracts_batch6.ts
      frontend_contracts_batch7.ts
      frontend_contracts_batch8.ts
      frontend_contracts_batch9.ts
      frontend_contracts_batch10.ts
      frontend_contracts_batch11.ts
      frontend_contracts_batch12.ts
      frontend_contracts_batch13.ts
      frontend_contracts_batch15.ts
      frontend_contracts_batch16.ts

  config/
    pipeline_config_v7.json
    pipeline_config_v8.json
    lineage_contract_v1.json
    semantic_model_v2.json
    schema_core.json
    FINAL_schema_core.json
    metrics.json
    FINAL_metrics.json
    section_mapping.json
    FINAL_section_mapping.json
    platform_final_structure.json

  docs/
    architecture/
    batches/
      batch0/
      batch1/
      batch2/
      batch3/
      batch4/
      batch5/
      batch5_1/
      batch6/
      batch7/
      batch8/
      batch9/
      batch10/
      batch11/
      batch12/
      batch13/
      batch14/
      batch15/
      batch16/
      batch17/
    rollout/
    uat/
    governance/
    roadmap/
    go_live/

  smoke/
    deployment_smoke_runner.py
    final_deployment_smoke_manifest_batch14.json
    static_rollout_uat_smoke.py
    static_adoption_smoke.py
    static_batch16_governance_smoke.py
    static_batch17_roadmap_smoke.py

  data/
    .gitkeep

  index.html
  package.json
  vite.config.js
  netlify.toml
  render.yaml
  requirements.txt
  .env.example
  .gitignore
  README.md
```

Do **not** commit the live `.xlsx` R-series files to the public repo. Keep `/data/.gitkeep` only, then upload source files to Render/staging storage.

---

# Upload map by batch pack

## Batch 0 — architecture, lineage, semantic model

From:

```text
scip_upgrade_pack_batch0.zip
```

Upload to:

```text
config/pipeline_config_v8.json
config/lineage_contract_v1.json
config/semantic_model_v2.json
config/smoke_test_checkpoints_v2.json

docs/batches/batch0/SCIP_SystemMap_v2_Hierarchy_Governance.md
docs/batches/batch0/SCIP_Governance_Checkpoints_v1.md
docs/batches/batch0/SCIP_Batch_Wise_Way_Forward_and_Prompts.md
docs/batches/batch0/data_loader_v7_patch_notes.md

docs/batches/batch0/source_adapters_v1.py
docs/batches/batch0/constants_v7_entity_hierarchy_patch.py
docs/batches/batch0/file_resolver_v7_patch.py
docs/batches/batch0/smoke_v2_source_validation.py
docs/batches/batch0/smoke_validation_results_v1.json
```

Do **not** use Batch 0 Python files as final runtime files. Keep them as references/docs because later batches supersede them.

---

## Batch 1 — ingestion foundation / R18

From:

```text
scip_batch1_ingestion_foundation.zip
```

Keep as historical/reference docs and smoke:

```text
docs/batches/batch1/
```

Files to preserve:

```text
SCIP_Batch1_Implementation_Report.md
SCIP_Batch1_Governance_and_Smoke_Checkpoints.md
SCIP_SystemMap_Batch1_Addendum.md
lineage_contract_v1_1_batch1.json
smoke_test_checkpoints_batch1.json
smoke_r18_batch1.py
smoke_data_loader_batch1.py
smoke_r18_batch1_results.json
smoke_data_loader_batch1_results.json
*.patch
```

Do **not** use Batch 1 runtime `data_loader.py`, `constants.py`, etc. as final files. They are superseded.

---

## Batch 2 — R04 / R02

From:

```text
scip_batch2_r04_r02.zip
```

Upload to:

```text
docs/batches/batch2/
```

Preserve:

```text
SCIP_Batch2_Implementation_Report.md
SCIP_Batch2_Governance_and_Smoke_Checkpoints.md
README_Batch2_File_Index.md
smoke_r04_r02_batch2.py
smoke_data_loader_batch2.py
*_results.json
*.patch
```

Runtime files are superseded by later cumulative batches.

---

## Batch 3 — R08 / R36

From:

```text
scip_batch3_r08_r36.zip
```

Upload to:

```text
docs/batches/batch3/
```

Preserve:

```text
SCIP_Batch3_Implementation_Report.md
SCIP_Batch3_Governance_and_Smoke_Checkpoints.md
smoke_batch3_r08_r36.py
smoke_data_loader_batch3.py
*_results.json
```

Runtime files are superseded.

---

## Batch 4 — Quickball / command centres

From:

```text
scip_batch4_quickball_command_centres.zip
```

Upload final/reference artifacts:

```text
docs/batches/batch4/SCIP_Batch4_Implementation_Report.md
docs/batches/batch4/SCIP_Batch4_Backend_Frontend_Contracts.md
docs/batches/batch4/SCIP_Batch4_Governance_and_Smoke_Checkpoints.md
docs/batches/batch4/quickball_metric_catalog_batch4.json
docs/batches/batch4/quickball_sample_answers_batch4.json
docs/batches/batch4/command_centres_sample_payload_batch4.json

src/frontend_contracts/frontend_contracts_batch4.ts
```

Runtime `quickball.py`, `command_centres.py`, and `main.py` are superseded by later cumulative batches, but Batch 4 documents should remain.

---

## Batch 5 — UI / forecasting

From:

```text
scip_batch5_ui_forecasting.zip
```

Upload:

```text
docs/batches/batch5/SCIP_Batch5_Implementation_Report.md
docs/batches/batch5/SCIP_Batch5_Governance_and_Smoke_Checkpoints.md
docs/batches/batch5/forecast_month_end_sample_batch5.json
docs/batches/batch5/command_centres_sample_payload_batch5.json

src/frontend_contracts/frontend_contracts_batch5.ts
```

Runtime `forecast.py` and `App.jsx` are superseded by later batches.

---

## Batch 5.1 — Liquid Glass

From:

```text
scip_batch5_1_liquid_glass.zip
```

Use these:

```text
src/liquidGlassTokens.css
docs/batches/batch5_1/SCIP_Batch5_1_Implementation_Report.md
docs/batches/batch5_1/SCIP_Batch5_1_Liquid_Glass_Visual_System_Notes.md
docs/batches/batch5_1/README_APPLY_PATCH.md
docs/batches/batch5_1/jsx_transpile_check_batch5_1.json
src/frontend_contracts/frontend_contracts_batch5_1.ts
```

Do not let later UI changes break the locked Liquid Glass two-door model from the handoff. The handoff confirms Batch 5.1 is where the Liquid Glass two-door Arrival model was locked.

---

## Batch 6 — initial action queues

From:

```text
scip_batch6_action_queues.zip
```

Upload:

```text
docs/batches/batch6/
src/frontend_contracts/frontend_contracts_batch6.ts
```

Do **not** use Batch 6 `account_action_queues.py` as final. Batch 7 supersedes it.

---

## Batch 7 — account action queues

From:

```text
scip_batch7_account_action_queues.zip
```

Final runtime file:

```text
Backend/account_action_queues.py
```

Also upload:

```text
docs/batches/batch7/
src/frontend_contracts/frontend_contracts_batch7.ts
```

---

## Batch 8 — workflow tracking

From:

```text
scip_batch8_workflow_tracking.zip
```

Final runtime file:

```text
Backend/workflow.py
```

Also upload:

```text
docs/batches/batch8/
src/frontend_contracts/frontend_contracts_batch8.ts
smoke/smoke_batch8_workflow_tracking.py
```

---

## Batch 9 — notifications / escalations

From:

```text
scip_batch9_notifications_escalations.zip
```

Final runtime file:

```text
Backend/notifications.py
```

Also upload:

```text
docs/batches/batch9/
src/frontend_contracts/frontend_contracts_batch9.ts
smoke/smoke_batch9_notifications.py
```

---

## Batch 10 — persistence / audit

From:

```text
scip_batch10_persistence_audit.zip
```

Final runtime file:

```text
Backend/persistence.py
```

Migration:

```text
Backend/migrations/001_batch10_persistence.sql
```

Also upload:

```text
Backend/audit_exports/scip_batch10_audit_export.json
Backend/audit_exports/scip_batch10_audit_export.csv
docs/batches/batch10/
src/frontend_contracts/frontend_contracts_batch10.ts
smoke/smoke_batch10_persistence_audit.py
```

---

## Batch 11 — RBAC / deployment hardening

From:

```text
scip_batch11_rbac_hardening.zip
```

Final runtime files:

```text
Backend/auth.py
Backend/deployment.py
Backend/rbac_policy_matrix_batch11.json
```

Migration:

```text
Backend/migrations/002_batch11_rbac_hardening.sql
```

Also upload:

```text
docs/batches/batch11/
src/frontend_contracts/frontend_contracts_batch11.ts
smoke/smoke_batch11_rbac_hardening.py
```

---

## Batch 12 — observability / performance

From:

```text
scip_batch12_observability_performance.zip
```

Final runtime/config files:

```text
Backend/observability.py
Backend/observability_config_batch12.json
Backend/observability_summary_sample_batch12.json
Backend/observability_dashboard_alert_spec_batch12.json
Backend/observability_alerts_sample_batch12.json
Backend/load_tests/batch12_synthetic_load.py
Backend/load_tests/batch12_synthetic_load_results.json
```

Migration:

```text
Backend/migrations/003_batch12_observability.sql
```

Also upload:

```text
docs/batches/batch12/
src/frontend_contracts/frontend_contracts_batch12.ts
smoke/smoke_batch12_observability_performance.py
```

---

## Batch 13 — production identity / SSO / cumulative code baseline

From:

```text
scip_batch13_sso_jwt_provisioning.zip
```

Use Batch 13 as the **main cumulative runtime baseline** for foundation code:

```text
Backend/main.py
Backend/constants.py
Backend/file_resolver.py
Backend/data_loader.py
Backend/source_adapters.py
Backend/pipeline_config.json
Backend/quickball.py
Backend/command_centres.py
Backend/forecast.py
Backend/account_action_queues.py
Backend/workflow.py
Backend/notifications.py
Backend/persistence.py
Backend/auth.py
Backend/deployment.py
Backend/observability.py
Backend/identity.py
```

Migration:

```text
Backend/migrations/004_batch13_identity_provisioning.sql
```

Also upload:

```text
docs/batches/batch13/
src/frontend_contracts/frontend_contracts_batch13.ts
smoke/smoke_batch13_identity_rbac.py
```

Important: apply the known migration fix to `004_batch13_identity_provisioning.sql` so it does not insert into missing `migration_history.description` / `migration_history.evidence_json` columns unless those columns exist.

---

## Batch 14 — rollout / UAT / rollback / break-glass

From:

```text
scip_batch14_rollout_uat_signoff.zip
```

Final runtime overlay files:

```text
Backend/rollout_uat.py
```

Only overwrite these if they are newer and still compile with the Batch 13 runtime baseline:

```text
Backend/main.py
Backend/auth.py
Backend/identity.py
Backend/observability.py
Backend/deployment.py
Backend/persistence.py
Backend/notifications.py
Backend/workflow.py
Backend/account_action_queues.py
src/App.jsx
src/liquidGlassTokens.css
```

Upload docs/checklists:

```text
docs/rollout/SCIP_Batch14_Staged_Rollout_Plan.md
docs/rollout/SCIP_Batch14_Rollback_BreakGlass_Runbook.md
docs/uat/SCIP_Batch14_UAT_Scripts_By_Role.md
docs/batches/batch14/
smoke/deployment_smoke_runner.py
smoke/final_deployment_smoke_manifest_batch14.json
smoke/static_rollout_uat_smoke.py
```

---

## Batch 15 — adoption analytics

From:

```text
scip_batch15_post_launch_adoption.zip
```

Final runtime file:

```text
Backend/adoption.py
```

Migration:

```text
Backend/migrations/005_batch15_adoption_analytics.sql
```

Upload:

```text
docs/batches/batch15/
docs/governance/SCIP_Batch15_Optimization_Backlog.md
docs/governance/SCIP_Batch15_Sample_Adoption_Dashboards.md
src/frontend_contracts/frontend_contracts_batch15.ts
smoke/static_adoption_smoke.py
```

---

## Batch 16 — continuous improvement governance

From:

```text
scip_batch16_continuous_improvement_governance.zip
```

Final runtime file:

```text
Backend/governance.py
```

Migration:

```text
Backend/migrations/006_batch16_continuous_improvement.sql
```

Upload:

```text
docs/governance/SCIP_Batch16_Change_Control_Board_Charter.md
docs/governance/SCIP_Batch16_Metric_Definition_Change_Log_Template.md
docs/governance/SCIP_Batch16_Monthly_Optimization_Review_Template.md
docs/governance/SCIP_Batch16_Quickball_Answer_Review_Template.md
docs/governance/SCIP_Batch16_Release_Notes_Governance.md
docs/governance/SCIP_Batch16_Source_Owner_SLA_Review_Template.md
docs/governance/SCIP_Batch16_UX_Simplification_Review_Template.md
docs/batches/batch16/
src/frontend_contracts/frontend_contracts_batch16.ts
smoke/static_batch16_governance_smoke.py
```

---

## Batch 17 — roadmap / executive rhythm

From:

```text
scip_batch17_long_term_roadmap_exec_rhythm.zip
```

Final runtime file:

```text
Backend/roadmap.py
```

Migration:

```text
Backend/migrations/007_batch17_roadmap_exec_rhythm.sql
```

Upload:

```text
docs/roadmap/SCIP_Batch17_12_Month_Roadmap.md
docs/roadmap/SCIP_Batch17_Quarterly_Executive_Operating_Rhythm.md
docs/roadmap/SCIP_Batch17_Monthly_Review_Calendar.md
docs/roadmap/SCIP_Batch17_KPI_OKR_Tree.md
docs/roadmap/SCIP_Batch17_Ownership_Map.md
docs/roadmap/SCIP_Batch17_Release_Train_Model.md
docs/roadmap/SCIP_Batch17_Benefits_Realization_Tracking.md
docs/roadmap/SCIP_Batch17_Executive_Steering_Committee_Pack.md
docs/batches/batch17/
smoke/static_batch17_roadmap_smoke.py
```

Only overwrite `Backend/main.py` or `src/App.jsx` from Batch 17 after checking they still include the operational routes from Batches 7–14.

---

## Go-live consolidation pack

From:

```text
scip_go_live_readiness_consolidation.zip
```

Upload all contents under:

```text
docs/go_live/
```

Mapping:

```text
README.md                                      -> docs/go_live/README.md
release/*                                     -> docs/go_live/release/
checklists/*                                  -> docs/go_live/checklists/
uat/*                                         -> docs/go_live/uat/
signoff/*                                     -> docs/go_live/signoff/
smoke/*                                       -> docs/go_live/smoke/
env/SCIP_Environment_Variables_Template.env   -> docs/go_live/env/
source_refresh/*                              -> docs/go_live/source_refresh/
blockers/*                                    -> docs/go_live/blockers/
manifests/*                                   -> docs/go_live/manifests/
references/*                                  -> docs/go_live/references/
```

---

# Non-zip loose files to upload

These are not from the batch zips, but should be included.

## Frontend/build shell

```text
package.json       -> package.json
vite.config.js     -> vite.config.js
netlify.toml       -> netlify.toml
main.jsx           -> src/main.jsx
```

Also create:

```text
index.html
```

## Architecture/config docs

```text
FINAL_ARCHITECTURE.md                         -> docs/architecture/
MASTER_ARCHITECTURE_v9.1.md                   -> docs/architecture/
CORE_CONTEXT_v3.md                            -> docs/architecture/
FINAL_RULES.md                                -> docs/architecture/
Sobha_Platform_Architecture_Blueprint_v1.md   -> docs/architecture/
Sobha_Platform_Engineering_Structure_v1.md    -> docs/architecture/
SCIP Platform Improvement Analysis.txt        -> docs/architecture/
SCIP_Liquid_Glass_UI_Strategy_Final_Unified.docx -> docs/liquid_glass/
SCIP_Break_Glass_Document_v1.docx             -> docs/rollout/
Sobha_Collections_Data_Schema_v1.docx         -> docs/architecture/
Sobha_Platform_SystemMap_v1.docx              -> docs/architecture/
```

## Config JSONs

```text
schema_core.json             -> config/
FINAL_schema_core.json       -> config/
metrics.json                 -> config/
FINAL_metrics.json           -> config/
section_mapping.json         -> config/
FINAL_section_mapping.json   -> config/
pipeline_config_v7.json      -> config/
platform_final_structure.json -> config/
```

---

# Do not upload / exclude

Exclude these from GitHub:

```text
__pycache__/
*.pyc
*.sqlite
.env
*.xlsx source files
node_modules/
dist/
```

Keep source workbooks outside the public repo:

```text
R02, R04, R08, R09, R10, R17, R18, R20, R30, R31, R32, R34, R36, R38
```

They should go to Render/staging data storage, not GitHub.

---

# Recommended upload order

Use this order on `release/go-live-rc1`:

```text
1. Create base folders.
2. Upload Batch 0 docs/config references.
3. Upload Batch 1–5.1 docs/contracts/smoke references.
4. Upload Batch 13 as the main cumulative runtime baseline.
5. Overlay Batch 14 rollout/UAT files.
6. Overlay Batch 15 adoption.
7. Overlay Batch 16 governance.
8. Overlay Batch 17 roadmap.
9. Upload go-live consolidation under docs/go_live.
10. Add loose frontend/build/deployment files.
11. Add .env.example, README.md, requirements.txt, render.yaml, index.html, .gitignore.
12. Run compile/build/smoke before merging.
```

The key rule is:

```text
Batch 0–12 must exist as product history, docs, contracts, smoke, and foundational lineage.
Batch 13 is the safest cumulative runtime baseline for Batches 0–13.
Batch 14–17 are overlays, not replacements for the foundation.
```



---

# Project Source Analysis

_Source converted from `Project Source Analysis.txt`._

Here’s a priority‑wise action plan based on the report’s recommendations, focusing on what you can ask me to do next:

1. **Backend Refactoring & Config Centralization (High Priority)**
   - Ask me to create a `settings.py` module using Pydantic’s `BaseSettings` to centralize and validate environment variables.
   - Request a modular redesign for `data_loader.py` and `quickball.py` by splitting responsibilities (e.g., Excel I/O, column mapping, metric calculation) into separate files. I can scaffold these modules and refactor existing functions accordingly.

2. **Metric Registry & Analytics Integration (High Priority)**
   - Have me extract the hard‑coded `METRIC_CATALOG` into a JSON/YAML configuration file and write a loader so new metrics can be added declaratively.
   - Ask me to draft API endpoints and integration points for the Batch 18 analytics engine, ensuring RBAC and lineage checks are preserved.

3. **Frontend Modularization (High Priority)**
   - Request a refactoring plan for `App.jsx` into smaller React components with separate directories for pages, hooks and services. I can generate starter component files and propose a directory structure.
   - Ask me to prepare a TypeScript configuration and begin migrating key components to TypeScript, including type definitions for API responses and props.

4. **CI/CD Pipeline & Testing Setup (Medium Priority)**
   - Ask me to create a GitHub Actions workflow file that runs Python unit tests, JavaScript/TypeScript tests, linting (Black, Flake8, ESLint, Prettier) and builds the project.
   - Request boilerplate unit test files for core backend functions (e.g., data loading, Quickball answer logic) and React components, plus a basic Cypress test for end‑to‑end flows.

5. **LLM Provider Switch Preparation (Medium Priority)**
   - Have me implement the `llm_providers.py` and `quickball_provider_gate.py` integration into `quickball.py`, controlled via an environment variable. I can add the migration script to extend the interactions table with provider metadata.

6. **Design System & Accessibility Improvements (Lower Immediate Priority)**
   - Ask me to recommend a UI component library (e.g., Material UI or Tailwind) and to create a design system outline. I can provide example component patterns and ARIA label usage to make the Quickball disk accessible.

By addressing these items in order, you’ll lay the groundwork for modularity, maintainability and extensibility before tackling broader improvements such as analytics governance workflows and UI design refinements.
