# SCIP Insights Engine — Wave B (Live Pulse deterministic frames)

**Scope:** the three Live Pulse surfaces only — Current Signal, Month Movement, Risk & Action.
**Status:** built and passing local smoke; ships **cutover-off by default**.
**Nothing renders differently until** `SCIP_INSIGHT_CUTOVER=live_pulse` is set on Render — and that should only happen after the Wave A live shadow-parity run is green.

## What changed
- Live Pulse critical insight headlines are now a **function of current data state** (a deterministic frame), not a hardcoded string. Frames never originate a number; the governed value is bound in.
- On those surfaces, a failed lineage gate now **degrades to blocked/unavailable** (no number, blocked frame, severity `blocked`, lineage still attached to show *why*) — instead of showing an ungated figure.
- The `"risk" if ach < 50` severity ternary is replaced by a registry `threshold_cross` predicate that reproduces the identical result.
- Frontend `FocusScreen` renders backend resolved insights for Live Pulse, removing the client-side `pickCardsForFocus` keyword selection for those surfaces (placement now comes from `surface_placement`). No business number is computed on the client.

## Retirement manifest (Wave B)
Retired as the **live source** for the three Live Pulse surfaces (kept in code as the rollback fallback; full deletion is Wave D):
1. Hardcoded card titles for the 8 Live Pulse critical cards (`board_od_exposure`, `board_mtd_collection_progress`, `ops_mtd_vs_may_target`, `ops_sobha_od`, `ops_uaq_od`, `ops_new_sales_collections`, `collector_od_priority`, `collector_daily_progress_signal`) — now `frame_set` driven.
2. Hardcoded interpretation notes for those cards — now `editorial_frame`.
3. The `"risk" if ach < 50 else "monitor"` inline ternary — now a `threshold_cross` predicate.
4. Frontend `pickCardsForFocus` selection for Live Pulse — now `surface_placement`-driven.

**Not touched in Wave B** (stay static until Wave C/D): all Narratives cards (`board_advance_mix`, `board_pipeline_gross`, `finance_*`), MIS governance cards, and Quickball `_role_interpretation` (that is Wave C).

## Honesty guarantees (verified by smoke)
- Numbers always come from governed `payload["computed"]`; a frame can never introduce one.
- `delta_sign` needs a prior snapshot at `payload["prior"]["computed"][metric]`. With no prior (current reality), the outcome is the neutral **"level"** frame — a direction (rising/falling) is **never fabricated**.
- Blocked cards carry no financial figure (no AED amount, no %), only the trust reason and source code.

## Smoke results (local, synthetic fixtures)
`python smoke_insight_wave_b.py` → all checks pass:
- Shadow mode is byte-parity with the static cards (regression guard).
- Live cutover keeps value + lineage identical to static; only the headline becomes a frame.
- delta directions correct with a prior; neutral "level" without one.
- pacing breach/ok reproduces the old severity exactly.
- failed OD source ⇒ 2 Live Pulse cards render blocked with no number; healthy R04 card still resolves.

`SCIP_INSIGHT_CUTOVER=shadow python smoke_insight_shadow_parity.py` → Wave A parity still green.

## Deploy (reversible)
1. Place into `go-live-rc1/Backend/`: `insight_registry.json` (Wave B), `insight_compiler.py` (Wave B), `command_centres_shadow_patch.py`. Keep the Wave A copies (`insight_registry_wave_a.json`, `insight_compiler_wave_a.py`) for rollback reference.
2. Frontend: apply `scip_focusscreen_wave_b_patch.jsx` (replace `FocusScreen`, pass the two new props) and append `scip_insight_cards_wave_b.css` to `liquidGlassTokens.css`. Keep `pickCardsForFocus`/`getPrimaryCopy` as the fallback.
3. Leave `SCIP_INSIGHT_CUTOVER` unset (defaults to `shadow`) → deploy is a no-op behaviourally.
4. Run `SCIP_USE_REAL_COMMAND_CENTRES=1 python smoke_insight_shadow_parity.py` against the live payload. **Only if green:** set `SCIP_INSIGHT_CUTOVER=live_pulse` and verify Live Pulse renders frames; cards on unresolved/failed sources show blocked, not a number.

## Rollback
Set `SCIP_INSIGHT_CUTOVER=shadow` (instant; no live insight is flagged `render_mode="live"`, so the frontend falls back to the static path). No data migration. To fully revert, remove the two lines added to `build_command_centres()`.

## Note on the 13/28 partial load
Under live cutover, any Live Pulse critical card whose source has not resolved (or failed validation) will render **blocked**, not a stale number. That is the gate working as designed and is consistent with the ongoing number-validation work — Wave B does not depend on all 28 files resolving.
