"""
SCIP insight_compiler.py - Wave A (shadow mode)

Purpose
-------
Read the Insight Definition Registry and the trusted data_loader payload, and
emit a resolved-insight set per role. In Wave A this runs in SHADOW: it does not
render anything to the user and does not modify the existing command_centres
cards. Its only job is to reproduce the current static-card output exactly so
the two can be diffed for parity (see smoke_insight_shadow_parity.py).

Two things are produced per insight:
  1. PARITY FIELDS (title, value, display_value, reporting_basis, severity,
     lineage_refs, trust_state) - mirror command_centres._card byte-for-byte so
     parity can be proven before any cutover.
  2. TARGET ANNOTATION (target_state, blocked_reason) - what the Wave B
     deterministic path WOULD do under the strict lineage gate (the same gate
     quickball already enforces). This previews which cards Wave B will degrade
     to blocked/unavailable instead of showing a number - especially relevant
     while only 13/28 R-series files resolve.

This module never parses Excel and never computes a business number that is not
already present in payload["computed"]. It consumes governed values + lineage.

Dependency rule
  insight_compiler imports: json, pathlib, typing only.
  insight_compiler NEVER imports: main, endpoints, data_loader internals.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Formatting helpers - identical semantics to command_centres._fmt_aed/_fmt_pct
# ---------------------------------------------------------------------------

def _fmt_aed(value: Any) -> str:
    if value is None:
        return "Unavailable"
    try:
        n = float(value)
    except (TypeError, ValueError):
        return str(value)
    if abs(n) >= 1_000_000_000:
        return f"AED {n / 1_000_000_000:,.3f}B"
    if abs(n) >= 1_000_000:
        return f"AED {n / 1_000_000:,.1f}M"
    return f"AED {n:,.0f}"


def _fmt_pct(value: Any) -> str:
    if value is None:
        return "Unavailable"
    try:
        return f"{float(value):.1f}%"
    except (TypeError, ValueError):
        return str(value)


def _fmt(value: Any, fmt: str) -> str:
    return _fmt_aed(value) if fmt == "aed" else _fmt_pct(value) if fmt == "pct" else str(value)


# ---------------------------------------------------------------------------
# Lineage ref - identical shape to command_centres._metric_ref
# ---------------------------------------------------------------------------

def _metric_ref(metric_key: str, bucket: str, key: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    lin = (payload.get("computed", {}).get(bucket, {}) or {}).get(key, {}) or {}
    return {
        "metric_key": metric_key,
        "lineage_bucket": bucket,
        "lineage_key": key,
        "has_lineage": bool(lin),
        "source_file": lin.get("source_file"),
        "sheet": lin.get("sheet"),
        "cell_or_range": lin.get("cell_or_range"),
        "validation_status": lin.get("validation_status"),
        "confidence_state": lin.get("confidence_state"),
        "reporting_basis": lin.get("reporting_basis"),
    }


# ---------------------------------------------------------------------------
# Trust fields - mirror command_centres._build_trust_bar for the two MIS cards
# ---------------------------------------------------------------------------

_CRITICAL_BUCKETS = {
    "R18": "OD_LINEAGE", "R04": "R04_LINEAGE", "R02": "R02_LINEAGE",
    "R08": "R08_LINEAGE", "R36": "R36_LINEAGE",
}


def _trust_field(field: str, payload: Dict[str, Any]) -> Any:
    computed = payload.get("computed", {})
    if field == "critical_lineage_counts":
        return {k: len(computed.get(b, {}) or {}) for k, b in _CRITICAL_BUCKETS.items()}
    if field == "sources_missing":
        meta = payload.get("summary", {}).get("meta", {})
        return meta.get("sources_missing", [])
    return None


# ---------------------------------------------------------------------------
# Value resolution
# ---------------------------------------------------------------------------

def _resolve_value(spec: Dict[str, Any], payload: Dict[str, Any]) -> Any:
    computed = payload.get("computed", {})
    v = spec["value"]
    src = v["source"]
    if src == "metric":
        return computed.get(v["metric"])
    if src == "ratio_pct":
        num = computed.get(v["numerator"]) or 0
        den = computed.get(v["denominator"]) or 0
        return (num / den * 100) if den else None
    if src == "literal_none":
        return None
    if src == "trust_field":
        return _trust_field(v["field"], payload)
    return None


def _resolve_display(spec: Dict[str, Any], value: Any, payload: Dict[str, Any]) -> str:
    computed = payload.get("computed", {})
    d = spec["display"]
    kind = d["kind"]
    if kind == "aed":
        return _fmt_aed(value)
    if kind == "pct":
        return _fmt_pct(value)
    if kind == "literal":
        return d["literal"]
    if kind == "raw_count":
        return str(value)
    if kind == "missing_list":
        return ", ".join(value or []) or d.get("empty_text", "None")
    if kind == "composite":
        parts = [_fmt(computed.get(p["metric"]), p["fmt"]) for p in d["parts"]]
        return d["template"].format(*parts)
    return str(value)


def _resolve_severity(spec: Dict[str, Any], value: Any) -> str:
    s = spec["severity"]
    if s["kind"] == "static":
        return s["value"]
    if s["kind"] == "threshold":
        return s["below"] if (value is not None and value < s["lt"]) else s["else"]
    return "info"


# ---------------------------------------------------------------------------
# Wave B target gate - same gate quickball already enforces on critical metrics
# ---------------------------------------------------------------------------

_REQUIRED_LINEAGE_FIELDS = ["source_file", "sheet", "cell_or_range", "validation_status", "confidence_state"]
_OK_VALIDATION = {"passed", "disclosed", "warning"}
_OK_CONFIDENCE = {"live_validated", "live_warning", "disclosed"}


def _target_state(spec: Dict[str, Any], value: Any, refs: List[Dict[str, Any]]) -> Dict[str, Any]:
    """What the Wave B deterministic path would do. Critical specs degrade to
    blocked/unavailable rather than show a number when the gate fails."""
    if spec.get("criticality") != "critical":
        return {"target_state": "resolved", "blocked_reason": None}
    for ref in refs:
        if not ref.get("has_lineage"):
            return {"target_state": "blocked_untrusted_metric",
                    "blocked_reason": f"Missing lineage for {ref['lineage_bucket']}.{ref['lineage_key']}"}
        for f in _REQUIRED_LINEAGE_FIELDS:
            if ref.get(f) in (None, ""):
                return {"target_state": "blocked_untrusted_metric",
                        "blocked_reason": f"Incomplete lineage field '{f}' for {ref['metric_key']}"}
        if ref.get("validation_status") not in _OK_VALIDATION:
            return {"target_state": "blocked_untrusted_metric",
                    "blocked_reason": f"Validation status is {ref.get('validation_status')} for {ref['metric_key']}"}
        if ref.get("confidence_state") not in _OK_CONFIDENCE:
            return {"target_state": "blocked_untrusted_metric",
                    "blocked_reason": f"Confidence state is {ref.get('confidence_state')} for {ref['metric_key']}"}
    if value is None:
        return {"target_state": "blocked_untrusted_metric",
                "blocked_reason": "Metric value unavailable despite lineage lookup"}
    return {"target_state": "resolved", "blocked_reason": None}


# ---------------------------------------------------------------------------
# Compiler
# ---------------------------------------------------------------------------

def load_registry(registry_path: Optional[str] = None) -> Dict[str, Any]:
    path = Path(registry_path) if registry_path else Path(__file__).resolve().parent / "insight_registry.json"
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _compile_one(spec: Dict[str, Any], payload: Dict[str, Any]) -> Dict[str, Any]:
    refs = [_metric_ref(l["metric_key"], l["bucket"], l["key"], payload) for l in spec.get("lineage", [])]
    value = _resolve_value(spec, payload)
    display_value = _resolve_display(spec, value, payload)
    severity = _resolve_severity(spec, value)
    trust_state = "lineaged" if all(r.get("has_lineage") for r in refs) else "blocked_or_partial_lineage"
    target = _target_state(spec, value, refs)
    return {
        # --- parity fields (must match command_centres._card output) ---
        "card_id": spec["insight_id"],
        "title": spec["headline_frame"]["default"],
        "value": value,
        "display_value": display_value,
        "reporting_basis": spec["reporting_basis"],
        "action": spec["editorial_frame"]["default"],
        "severity": severity,
        "lineage_refs": refs,
        "trust_state": trust_state,
        # --- Wave B preview / registry metadata (shadow only) ---
        "criticality": spec.get("criticality"),
        "governance_state": spec.get("governance_state"),
        "surface_placement": spec.get("surface_binding"),
        "target_state": target["target_state"],
        "blocked_reason": target["blocked_reason"],
    }


def compile_insights(payload: Dict[str, Any], registry: Optional[Dict[str, Any]] = None,
                     registry_path: Optional[str] = None) -> Dict[str, Any]:
    """Compile the registry against the payload, grouped by role. Order within a
    role follows registry priority (desc) then declaration order, matching the
    intent that higher-priority cards lead the surface."""
    reg = registry or load_registry(registry_path)
    specs = reg.get("insights", [])
    by_role: Dict[str, List[Dict[str, Any]]] = {}
    for spec in specs:
        resolved = _compile_one(spec, payload)
        for role in spec.get("role_visibility", []):
            by_role.setdefault(role, []).append((spec.get("surface_binding", {}).get("priority", 0), resolved))
    roles: Dict[str, List[Dict[str, Any]]] = {}
    for role, items in by_role.items():
        items.sort(key=lambda t: -t[0])  # priority desc; stable for equal priority
        roles[role] = [r for _, r in items]
    blocked_preview = [
        {"card_id": r["card_id"], "role": role, "reason": r["blocked_reason"]}
        for role, items in roles.items() for r in items
        if r["target_state"] == "blocked_untrusted_metric"
    ]
    return {
        "status": "ok",
        "mode": "shadow",
        "registry_version": reg.get("registry_version"),
        "roles": roles,
        "guardrails": {
            "no_silent_fallback": True,
            "shadow_does_not_render": True,
            "critical_requires_lineage": True,
        },
        "wave_b_blocked_preview": blocked_preview,
    }


if __name__ == "__main__":
    import sys
    payload = json.loads(Path(sys.argv[1]).read_text()) if len(sys.argv) > 1 else {}
    print(json.dumps(compile_insights(payload), indent=2, default=str))
