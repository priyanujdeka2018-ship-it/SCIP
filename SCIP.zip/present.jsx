/* SCIP — Present mode: board-safe full-screen chapter walk.
 * Output action per locked rules: no chrome, no drawers, no depth.
 * ← → arrows / click to advance · Esc exits.
 */
/* eslint-disable react/prop-types */

function PresentMode({ open, onClose }) {
  const chapters = window.SCIP.NARRATIVES;
  const slideCount = chapters.length + 2; // cover + chapters + close
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    if (!open) return;
    setIdx(0);
    function onKey(e) {
      if (e.key === "Escape") onClose();
      else if (e.key === "ArrowRight" || e.key === " " || e.key === "Enter") setIdx((i) => Math.min(i + 1, slideCount - 1));
      else if (e.key === "ArrowLeft") setIdx((i) => Math.max(i - 1, 0));
    }
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose, slideCount]);

  if (!open) return null;

  const t = window.SCIP.TRUST;
  const isCover = idx === 0;
  const isClose = idx === slideCount - 1;
  const chapter = !isCover && !isClose ? chapters[idx - 1] : null;

  function advance(e) {
    // click left third = back, otherwise forward
    const x = e.clientX / window.innerWidth;
    if (x < 0.3) setIdx((i) => Math.max(i - 1, 0));
    else setIdx((i) => Math.min(i + 1, slideCount - 1));
  }

  return (
    <div className="present" role="dialog" aria-modal="true" aria-label="Present mode" onClick={advance}>
      <div className="present-bg" aria-hidden="true" />

      {/* top hairline: progress */}
      <div className="present-progress" aria-hidden="true">
        {Array.from({ length: slideCount }).map((_, i) => (
          <span key={i} className={i <= idx ? "on" : ""} />
        ))}
      </div>

      {isCover && (
        <section className="present-slide present-cover" key="cover">
          <div className="present-mark">S</div>
          <div className="eyebrow" style={{ marginTop: 26 }}>Sobha Collections Intelligence Platform</div>
          <h1 className="present-title display">May 2026<br />Collections Briefing</h1>
          <p className="present-sub">Board-safe narrative · all figures lineaged · {t.snapshot_date}</p>
          <div className="present-hint">Click or press → to begin</div>
        </section>
      )}

      {chapter && (
        <section className="present-slide" key={chapter.key}>
          <div className="present-chapter-meta">
            <span className="present-chapter-num">{chapter.num}</span>
            <span className="eyebrow">{chapter.label}</span>
          </div>
          <h2 className="present-chapter-title display">{chapter.title}</h2>
          <p className="present-lede">{chapter.lede}</p>
          <div className="present-stats">
            {chapter.stats.map((s) => (
              <div key={s.label} className="present-stat">
                <div className="label">{s.label}</div>
                <div className="val num">{s.val}</div>
                <div className={`delta ${s.tone}`}>{s.delta}</div>
              </div>
            ))}
          </div>
        </section>
      )}

      {isClose && (
        <section className="present-slide present-cover" key="close">
          <div className="eyebrow">End of briefing</div>
          <h2 className="present-title display" style={{ fontSize: "clamp(40px, 6vw, 80px)" }}>Three decisions.<br />One composed close.</h2>
          <p className="present-sub">Clear the 61–120 pocket · approve the rebate push · restore R38 lineage.</p>
          <div className="present-hint">Press Esc to exit</div>
        </section>
      )}

      {/* bottom rail */}
      <div className="present-foot" aria-hidden="true">
        <span>SCIP · Present</span>
        <span>{isCover ? "Cover" : isClose ? "Close" : `Chapter ${chapter.num} of 05`}</span>
        <span>{t.snapshot_date} · lineage verified</span>
      </div>

      <button className="present-exit" onClick={(e) => { e.stopPropagation(); onClose(); }} aria-label="Exit present mode">
        <IconClose size={16} />
      </button>
    </div>
  );
}

Object.assign(window, { PresentMode });
