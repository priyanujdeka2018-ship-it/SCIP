# SCIP Insights Engine — Wave D-2 (placement cutover + migration)

**Status:** built; all D-2 checks pass; Waves A–D-1 still green.
**Posture:** the cutover is env-gated and default OFF (`SCIP_PLACEMENT_RENDER=static`). Dropping the files in changes nothing until the env is flipped on live; the deletion step is separate and gated (see `WAVE_D2_DELETIONS.md`).

## What D-2 does
1. **Crosswalk** (`metric_crosswalk.json`) — links the command-centre runtime keys to M-codes, lineage, and submodules, with a **fabrication guard**: every asserted M-code is validated against `FINAL_metrics.json`. 4 keys map cleanly (`MTD_TOTAL_COLLECTIONS→M009`, `CY_ADV_MIX_YTD→M033`, `FY_ADV_MIX_YTD→M034`, `PIPELINE_GROSS→M005`); 6 stay explicit candidates/constants (OD_TODAY/OD_SOBHA/OD_UAQ are R18 constants, not invented codes).
2. **Migration** (`section_placement.json`) — rewrites all `submodules[].kpis` and `metrics[].used_in` bindings as registry-shaped placement so the binder is the single placement authority. 121 entries, **0 bindings dropped**, dirty targets normalized (`"S02_SM2 (strategic)"` → `S02_SM2`; section-level `S02`/`S04` handled distinctly).
3. **Cutover** (`command_centres_v2.py`) — the Placement Binder becomes the render source for the role cards, replacing `_board_cards`/`_ops_cards`/…; card contract is byte-identical, so the frontend sees no change. Env-gated, default static.

## The real finding D-2 surfaced
The migration **quarantined exactly one stale binding**: `M037 npv_rebate_rate_pct` was bound into `S05_SM4`, which `boundary_rules` explicitly forbid ("NPV lives in S01, not S05 — no re-display of numbers"). It is flagged `rejected_boundary` with the reason, not silently carried. This is precisely the latent inconsistency the registry + binder exist to eliminate — `WAVE_D2_DELETIONS.md` says to fix M037's `used_in` before retiring the field.

## Smoke results (local)
`python smoke_placement_wave_d2.py` → all pass:
- **Render parity** — binder-rendered role cards are identical to the static cards (value, display, basis, action, severity, lineage, trust_state, order) for all five roles → the cutover is safe to flip.
- **Crosswalk integrity** — no fabricated M-codes; all command keys resolve; OD_TODAY correctly flagged as an R18 constant.
- **Completeness** — every normalized kpi (73) and used_in (93) binding is represented; nothing lost.
- **Enforcement** — every submodule-level target exists; the one NPV-in-S05 violation is quarantined with a reason; CIV (M056/M057) stays governed in S01.

Regression: Waves A, B, C, D-1 smokes all still pass.

## Files
- `build_d2_migration.py` — generator (run once; re-runnable). Produces the two JSON artifacts with fabrication + completeness + boundary guards.
- `metric_crosswalk.json`, `section_placement.json` — the generated migration artifacts.
- `command_centres_v2.py` — the binder-as-render-source cutover (env-gated).
- `smoke_placement_wave_d2.py` — the D-2 gate.
- `WAVE_D2_DELETIONS.md` — the gated, irreversible deletion manifest.
- `section_rules.py` — updated (containment now matches by M-code as well as metric key).

## Deploy / cutover (reversible until deletion)
1. Place `build_d2_migration.py`, `command_centres_v2.py`, the two JSON artifacts, and the updated `section_rules.py` into `go-live-rc1/Backend/`. (D-1's binder + shadow hook are prerequisites.)
2. Wire the `roles =` dispatch in `build_command_centres` per the `command_centres_v2.py` header. Leave `SCIP_PLACEMENT_RENDER` unset → legacy static path renders (no change).
3. Run `SCIP_PLACEMENT_RENDER=binder` in staging and compare role cards to the static render (the D-2 render-parity check against the real module). If identical, flip on live.
4. Only after the binder render is stable on live, apply `WAVE_D2_DELETIONS.md` (the irreversible cleanup), then fix M037's `used_in`.

## Rollback
- Cutover: `SCIP_PLACEMENT_RENDER=static` (instant).
- Deletion: `git revert` (the deletion is the only non-env-reversible step in A–D, which is why it is last and gated).

## Programme status (A–D)
- **A** registry + compiler in shadow, parity proven.
- **B** Live Pulse criticals on deterministic frames + blocked degrade.
- **C** Narratives editorial on the constrained-LLM path with the token-whitelist guarantee.
- **D-1** Placement Binder + boundary/containment/single-source enforcement (shadow).
- **D-2** placement cutover + kpis/used_in migration + the gated deletion manifest.

The static authoring the programme set out to replace — hardcoded card lists, role-note branches, the severity ternary, kpis/used_in placement, and the "grew 22×"-style time bombs — is now either retired behind an env flip or structurally impossible. The only remaining manual step is the gated deletion in `WAVE_D2_DELETIONS.md`, to be done after the cutover is confirmed stable on live data.
