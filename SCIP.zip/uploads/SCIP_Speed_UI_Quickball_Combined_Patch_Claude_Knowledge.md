# SCIP Speed UI + Quickball Combined Patch

_Converted from `SCIP_speed_ui_quickball_combined_patch.zip` for Claude Project Knowledge._

## How to use this in Claude

- Upload this Markdown file, not the original zip.

- Use it for understanding contents, patch order, file replacements, and code review.

- Keep executable application of patches in GitHub/local repo; Claude Project Knowledge is reference-only.

- Do not upload `__pycache__`, binary outputs, source workbooks, or generated smoke-result dumps unless specifically needed.

## Package inventory summary

- Source zip: `SCIP_speed_ui_quickball_combined_patch.zip`

- Total files/directories in zip: 23

- Text/code files represented here: 15


## Full manifest

```json
[
  {
    "path": "SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/Backend/account_action_queues.py",
    "size": 62975
  },
  {
    "path": "SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/Backend/data_loader.py",
    "size": 49862
  },
  {
    "path": "SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/Backend/file_resolver.py",
    "size": 4299
  },
  {
    "path": "SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/Backend/forecast.py",
    "size": 12277
  },
  {
    "path": "SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/Backend/main.py",
    "size": 10709
  },
  {
    "path": "SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/Backend/quickball.py",
    "size": 21719
  },
  {
    "path": "SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/src/App.jsx",
    "size": 59395
  },
  {
    "path": "SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/src/scipPowerUatQuickball.css",
    "size": 2837
  },
  {
    "path": "SCIP_speed_ui_quickball_combined_patch/env/render_env_additions.env",
    "size": 145
  },
  {
    "path": "SCIP_speed_ui_quickball_combined_patch/smoke/smoke_cache_speed.sh",
    "size": 705
  },
  {
    "path": "SCIP_speed_ui_quickball_combined_patch/patches/scip_speed_quickball_cache_patch.diff",
    "size": 24194
  },
  {
    "path": "SCIP_speed_ui_quickball_combined_patch/patches/frontend_quickball_ui_safe_merge.diff",
    "size": 7585
  },
  {
    "path": "SCIP_speed_ui_quickball_combined_patch/apply_from_repo_root.sh",
    "size": 1390
  },
  {
    "path": "SCIP_speed_ui_quickball_combined_patch/CONTRADICTIONS_RESOLVED.md",
    "size": 2393
  },
  {
    "path": "SCIP_speed_ui_quickball_combined_patch/README.md",
    "size": 4194
  }
]
```


---

## `SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/Backend/account_action_queues.py`


```python
"""
SCIP Batch 7 - Account-level action queues and collector drilldowns.

This module upgrades the Batch 6 action-queue safety gate by onboarding the
newly attached R-series reports:

  R10  Dues Coverage + Allocation + PTP Data
  R17  SPA / pre-registration overdue bifurcation
  R20  PR-to-SOA TAT process evidence
  R30  Monthly collector feedback/performance
  R31  PR unit update / PR quality
  R32  RM collectors + PR receipts report
  R34  Termination status / account legal escalation
  R38  Risk analysis by CIV and paid-band
  R09  Project collections detail

Guardrail: no account-level action is returned unless it has account/unit,
owner, entity mapping, amount, ageing bucket/status, and source lineage.
"""

from __future__ import annotations

import copy
import os
import threading
import time
from dataclasses import dataclass, asdict
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

try:
    from fastapi import APIRouter, Request
    from fastapi.responses import JSONResponse
except Exception:  # pragma: no cover
    APIRouter = None
    Request = object
    JSONResponse = None

try:
    import auth
except Exception:  # pragma: no cover
    auth = None

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

TOLERANCE_PCT = 0.0005  # 0.05% locked rule.

ROLE_KEYS = ["collector_rm", "cco_gm_agm", "finance", "mis_qcg_admin"]

ENTITY_DISPLAY = {
    "group": "Group",
    "sobha": "Sobha",
    "sobha_dubai": "Sobha Dubai",
    "sobha_auh": "Sobha AUH",
    "uaq": "UAQ",
    "siniya": "Siniya",
    "downtown_uaq": "Downtown UAQ",
    "unknown": "Unknown",
}

PARENT_ENTITY = {
    "sobha_dubai": "sobha",
    "sobha_auh": "sobha",
    "siniya": "uaq",
    "downtown_uaq": "uaq",
    "sobha": "group",
    "uaq": "group",
}

AGEING_PRIORITY = {
    "180+": 6,
    "121-180": 5,
    "91-120": 4,
    "61-90": 3,
    "31-60": 2,
    "0-30": 1,
    "no_overdue": 0,
    "unknown": -1,
}

CRITICAL_REPORTS = ["R10", "R17", "R20", "R30", "R31", "R32", "R34", "R38", "R09"]


def _now() -> str:
    return datetime.utcnow().isoformat() + "Z"


def _norm(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def _to_float(value: Any) -> Optional[float]:
    if value in (None, ""):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).replace(",", "").strip()
    if text in ("", "-", "--", "00:00:00"):
        return None
    try:
        return float(text)
    except ValueError:
        return None


def _to_iso(value: Any) -> Optional[str]:
    if value in (None, "", 0, "0", "00:00:00"):
        return None
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    text = str(value).strip()
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d-%m-%y", "%d/%m/%Y", "%d/%m/%y", "%d %b %Y", "%d-%b-%Y"):
        try:
            return datetime.strptime(text, fmt).date().isoformat()
        except ValueError:
            pass
    return text if text else None


def _cell(row: int, col: int) -> str:
    return f"{get_column_letter(col)}{row}"


def _cell_range(row: int, cols: Iterable[int]) -> str:
    cols = list(cols)
    if not cols:
        return ""
    if len(cols) == 1:
        return _cell(row, cols[0])
    return f"{_cell(row, min(cols))}:{_cell(row, max(cols))}"


def _find_file(data_dir: Path, patterns: Iterable[str]) -> Optional[Path]:
    for pattern in patterns:
        hits = sorted(data_dir.glob(pattern))
        if hits:
            return hits[0]
    return None


def _entity_from_text(*values: Any) -> str:
    text = " ".join(_norm(v).lower() for v in values if _norm(v))
    if "sobha auh" in text or "river cove" in text or "siniya island" in text and "sobha" in text:
        return "sobha_auh"
    if "siniya" in text:
        return "siniya"
    if "downtown" in text or "dt " in text or "uaq" in text:
        return "downtown_uaq"
    if "sobha" in text or "hartland" in text or "creek" in text or "greens" in text or "one park" in text or "riverside" in text:
        return "sobha_dubai"
    if "central" in text:
        return "group"
    return "unknown"


def _display_entity(code: str) -> str:
    return ENTITY_DISPLAY.get(code or "unknown", "Unknown")


def _fmt_aed(value: Optional[float]) -> str:
    if value is None:
        return "Unavailable"
    v = float(value)
    av = abs(v)
    if av >= 1_000_000_000:
        return f"AED {v/1_000_000_000:.3f}B"
    if av >= 1_000_000:
        return f"AED {v/1_000_000:.1f}M"
    return f"AED {v:,.0f}"


def _severity_from(amount: Optional[float], ageing: Optional[str] = None, status: Optional[str] = None) -> str:
    amount = float(amount or 0)
    ageing = ageing or "unknown"
    status_text = (status or "").lower()
    if "eligible" in status_text and "not eligible" not in status_text:
        return "risk"
    if ageing in {"180+", "121-180"} or amount >= 1_000_000:
        return "risk"
    if ageing in {"91-120", "61-90"} or amount >= 250_000:
        return "attention"
    return "watch"


def _lineage(source_code: str, source_file: str, sheet: str, cell_or_range: str, snapshot_date: Optional[str], method: str, basis: str, row_number: Optional[int] = None) -> Dict[str, Any]:
    return {
        "source_code": source_code,
        "source_file": source_file,
        "sheet": sheet,
        "cell_or_range": cell_or_range,
        "row_number": row_number,
        "snapshot_date": snapshot_date,
        "extraction_method": method,
        "reporting_basis": basis,
        "validation_status": "passed",
        "confidence_state": "live_validated",
        "last_loaded_at": _now(),
    }


def _lineage_ref(metric_key: str, metric_label: str, lin: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "metric_key": metric_key,
        "metric_label": metric_label,
        "has_lineage": True,
        "source_code": lin.get("source_code"),
        "source_file": lin.get("source_file"),
        "sheet": lin.get("sheet"),
        "cell_or_range": lin.get("cell_or_range"),
        "snapshot_date": lin.get("snapshot_date"),
        "validation_status": lin.get("validation_status"),
        "confidence_state": lin.get("confidence_state"),
        "reporting_basis": lin.get("reporting_basis"),
    }


def _has_action_lineage(action: Dict[str, Any]) -> bool:
    refs = action.get("lineage_refs") or []
    required = ["source_code", "source_file", "sheet", "cell_or_range", "validation_status", "confidence_state", "reporting_basis"]
    return bool(refs) and all(all(ref.get(k) for k in required) for ref in refs)


def _has_account_action_minimum(action: Dict[str, Any]) -> bool:
    required = ["account_id", "unit", "collector_rm_owner", "entity_code", "amount_aed", "ageing_bucket"]
    return all(action.get(k) not in (None, "", []) for k in required) and _has_action_lineage(action)


@dataclass
class AccountFact:
    source_code: str
    source_file: str
    sheet: str
    row_number: int
    account_id: str
    unit: str
    customer_name: Optional[str]
    project: Optional[str]
    sub_project: Optional[str]
    entity_code: str
    entity_display: str
    parent_entity_code: Optional[str]
    parent_entity_display: Optional[str]
    collector_rm_owner: Optional[str]
    manager_name: Optional[str]
    overdue_amount_aed: Optional[float]
    ageing_bucket: str
    risk_status: Optional[str]
    ptp_date: Optional[str]
    ptp_amount_aed: Optional[float]
    ptp_status: Optional[str]
    pr_status: Optional[str]
    escalation_status: Optional[str]
    validation_status: str
    confidence_state: str
    lineage: Dict[str, Any]


class WorkbookSource:
    source_code = "RXX"
    patterns: Tuple[str, ...] = ()

    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.path = _find_file(data_dir, self.patterns)
        self.errors: List[str] = []
        self.warnings: List[str] = []

    def exists(self) -> bool:
        return self.path is not None and self.path.exists()

    @property
    def source_file(self) -> str:
        return self.path.name if self.path else "missing"


class R10DuesCoverageAdapter(WorkbookSource):
    source_code = "R10"
    patterns = ("R10*.xlsx", "*Dues Coverage*.xlsx")

    def extract(self) -> Dict[str, Any]:
        account_allocations: List[Dict[str, Any]] = []
        ptp_facts: List[Dict[str, Any]] = []
        collector_coverage: List[Dict[str, Any]] = []
        if not self.exists():
            return {"source_code": self.source_code, "status": "missing", "account_allocations": [], "ptp_facts": [], "collector_coverage": [], "errors": ["R10 missing"]}
        wb = load_workbook(self.path, read_only=True, data_only=True)
        # Allocation account facts.
        if "Allocation" in wb.sheetnames:
            ws = wb["Allocation"]
            headers = [_norm(v) for v in next(ws.iter_rows(min_row=1, max_row=1, values_only=True))]
            # Snapshot date appears as last header in col31 in the sample.
            snapshot_date = _to_iso(headers[30] if len(headers) > 30 else None)
            for ridx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
                account_id = _norm(row[4] if len(row) > 4 else None)
                unit = _norm(row[5] if len(row) > 5 else None)
                owner = _norm(row[8] if len(row) > 8 else None)
                entity = _entity_from_text(row[0] if len(row) > 0 else None, row[3] if len(row) > 3 else None)
                overdue_today = _to_float(row[6] if len(row) > 6 else None) or 0.0
                overdue_eom = _to_float(row[7] if len(row) > 7 else None) or 0.0
                overdue_ms = _to_float(row[23] if len(row) > 23 else None) or overdue_eom or overdue_today
                amount_tracker = _to_float(row[20] if len(row) > 20 else None) or 0.0
                communications = _to_float(row[16] if len(row) > 16 else None) or 0.0
                if not (account_id and unit and owner):
                    continue
                if max(overdue_ms, overdue_eom, overdue_today, amount_tracker, communications) <= 0:
                    continue
                lin = _lineage("R10", self.source_file, "Allocation", _cell_range(ridx, [1,5,6,7,8,9,17,21,24,30]), snapshot_date, "R10DuesCoverageAdapter.allocation_account_row", "R10 dues coverage allocation")
                account_allocations.append({
                    "account_id": account_id,
                    "unit": unit,
                    "project": _norm(row[0] if len(row) > 0 else None),
                    "sub_project": _norm(row[1] if len(row) > 1 else None),
                    "tower": _norm(row[3] if len(row) > 3 else None),
                    "collector_rm_owner": owner,
                    "advance_owner": _norm(row[9] if len(row) > 9 else None),
                    "manager_name": _norm(row[19] if len(row) > 19 else None),
                    "entity_code": entity,
                    "entity_display": _display_entity(entity),
                    "overdue_today_aed": round(overdue_today, 2),
                    "overdue_eom_aed": round(overdue_eom, 2),
                    "overdue_eom_ms_aed": round(overdue_ms, 2),
                    "amount_in_tracker_aed": round(amount_tracker, 2),
                    "receipt_generated_aed": round(_to_float(row[21] if len(row) > 21 else None) or 0, 2),
                    "communication_count": int(communications),
                    "last_task_updated_date": _to_iso(row[29] if len(row) > 29 else None),
                    "ageing_bucket": "amount_validated_no_ageing_from_R10",
                    "lineage": lin,
                })
        # PTP facts.
        if "PTP Data" in wb.sheetnames:
            ws = wb["PTP Data"]
            for ridx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
                account_id = _norm(row[4] if len(row) > 4 else None)
                unit = _norm(row[5] if len(row) > 5 else None)
                owner = _norm(row[25] if len(row) > 25 else None) or _norm(row[11] if len(row) > 11 else None)
                amount = _to_float(row[16] if len(row) > 16 else None)
                if not (account_id and unit and owner and amount and amount > 0):
                    continue
                entity = _entity_from_text(row[27] if len(row) > 27 else None, row[6] if len(row) > 6 else None)
                lin = _lineage("R10", self.source_file, "PTP Data", _cell_range(ridx, [4,5,6,12,16,17,25,26,28]), _to_iso(row[7] if len(row) > 7 else None), "R10DuesCoverageAdapter.ptp_account_row", "R10 PTP account promise")
                ptp_facts.append({
                    "account_name": _norm(row[3] if len(row) > 3 else None),
                    "account_id": account_id,
                    "unit": unit,
                    "tower": _norm(row[6] if len(row) > 6 else None),
                    "created_date": _to_iso(row[7] if len(row) > 7 else None),
                    "collector_rm_owner": owner,
                    "owner_full_name": _norm(row[11] if len(row) > 11 else None),
                    "ptp_date": _to_iso(row[15] if len(row) > 15 else None),
                    "ptp_amount_aed": round(amount, 2),
                    "ptp_status": _norm(row[24] if len(row) > 24 else None),
                    "call_status": _norm(row[13] if len(row) > 13 else None),
                    "comments": _norm(row[14] if len(row) > 14 else None),
                    "entity_code": entity,
                    "entity_display": _display_entity(entity),
                    "lineage": lin,
                })
        # Coverage by collector.
        if "Agent - Coverage" in wb.sheetnames:
            ws = wb["Agent - Coverage"]
            for ridx, row in enumerate(ws.iter_rows(min_row=6, values_only=True), start=6):
                collector = _norm(row[1] if len(row) > 1 else None)
                if not collector or collector.lower().startswith("grand"):
                    continue
                lin = _lineage("R10", self.source_file, "Agent - Coverage", _cell_range(ridx, [2,5,6,7,8,9,10]), None, "R10DuesCoverageAdapter.collector_coverage", "R10 dues coverage summary")
                collector_coverage.append({
                    "collector_rm_owner": collector,
                    "total_odeom_amount_aed": round(_to_float(row[4] if len(row) > 4 else None) or 0, 2),
                    "coverage_units": int(_to_float(row[5] if len(row) > 5 else None) or 0),
                    "coverage_pct": _to_float(row[6] if len(row) > 6 else None),
                    "not_worked_units": int(_to_float(row[8] if len(row) > 8 else None) or 0),
                    "not_worked_pct": _to_float(row[9] if len(row) > 9 else None),
                    "lineage": lin,
                })
        wb.close()
        return {"source_code": "R10", "status": "loaded", "account_allocations": account_allocations, "ptp_facts": ptp_facts, "collector_coverage": collector_coverage, "errors": self.errors, "warnings": self.warnings}


class R34TerminationAdapter(WorkbookSource):
    source_code = "R34"
    patterns = ("R34*.xlsx", "*Termination Status*.xlsx")

    def extract(self) -> Dict[str, Any]:
        facts: List[Dict[str, Any]] = []
        if not self.exists():
            return {"source_code": "R34", "status": "missing", "termination_facts": [], "errors": ["R34 missing"]}
        wb = load_workbook(self.path, read_only=True, data_only=True)
        ws = wb["Data"] if "Data" in wb.sheetnames else wb[wb.sheetnames[0]]
        for ridx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            account_id = _norm(row[3] if len(row) > 3 else None)
            unit = _norm(row[4] if len(row) > 4 else None)
            if not (account_id and unit):
                continue
            buckets = {
                "0-30": _to_float(row[40] if len(row) > 40 else None) or 0.0,
                "31-60": _to_float(row[41] if len(row) > 41 else None) or 0.0,
                "61-90": _to_float(row[42] if len(row) > 42 else None) or 0.0,
                "91-120": _to_float(row[43] if len(row) > 43 else None) or 0.0,
                "121-180": _to_float(row[44] if len(row) > 44 else None) or 0.0,
                "180+": _to_float(row[45] if len(row) > 45 else None) or 0.0,
            }
            total_overdue = _to_float(row[52] if len(row) > 52 else None)
            if total_overdue is None:
                total_overdue = sum(buckets.values())
            ageing_bucket = max(buckets.keys(), key=lambda b: (buckets[b] > 0, AGEING_PRIORITY[b])) if any(buckets.values()) else "no_overdue"
            if total_overdue <= 0 and _norm(row[64] if len(row) > 64 else None).lower() not in {"termination", "possible pdn"}:
                continue
            entity = _entity_from_text(row[2] if len(row) > 2 else None, row[0] if len(row) > 0 else None)
            lin = _lineage("R34", self.source_file, ws.title, _cell_range(ridx, [1,4,5,6,41,42,43,44,45,46,53,65,71,72]), None, "R34TerminationAdapter.account_termination_row", "R34 termination status account evidence", ridx)
            facts.append({
                "account_id": account_id,
                "unit": unit,
                "customer_name": _norm(row[5] if len(row) > 5 else None),
                "project": _norm(row[2] if len(row) > 2 else None),
                "sub_project": _norm(row[1] if len(row) > 1 else None),
                "tower": _norm(row[0] if len(row) > 0 else None),
                "entity_code": entity,
                "entity_display": _display_entity(entity),
                "purchase_price_aed": _to_float(row[6] if len(row) > 6 else None),
                "total_overdue_aed": round(total_overdue, 2),
                "ageing_bucket": ageing_bucket,
                "ageing_buckets": {k: round(v, 2) for k, v in buckets.items()},
                "last_action_status": _norm(row[14] if len(row) > 14 else None),
                "last_action_description": _norm(row[15] if len(row) > 15 else None),
                "last_action_by": _norm(row[17] if len(row) > 17 else None),
                "possible_pdn": _norm(row[64] if len(row) > 64 else None),
                "eligible_status": _norm(row[70] if len(row) > 70 else None),
                "in_system_status": _norm(row[71] if len(row) > 71 else None),
                "pre_registration_status": _norm(row[35] if len(row) > 35 else None),
                "lineage": lin,
            })
        wb.close()
        return {"source_code": "R34", "status": "loaded", "termination_facts": facts, "errors": self.errors, "warnings": self.warnings}


class R31PRQualityAdapter(WorkbookSource):
    source_code = "R31"
    patterns = ("R31*.xlsx", "*PR Unit*.xlsx")

    def extract(self) -> Dict[str, Any]:
        pr_issues: List[Dict[str, Any]] = []
        if not self.exists():
            return {"source_code": "R31", "status": "missing", "pr_issues": [], "errors": ["R31 missing"]}
        wb = load_workbook(self.path, read_only=True, data_only=True)
        if "PR Data" in wb.sheetnames:
            ws = wb["PR Data"]
            for ridx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
                pr_no = _norm(row[0] if len(row) > 0 else None)
                status = _norm(row[5] if len(row) > 5 else None)
                receipt_status = _norm(row[22] if len(row) > 22 else None)
                amount = _to_float(row[2] if len(row) > 2 else None) or _to_float(row[15] if len(row) > 15 else None) or 0.0
                if not pr_no or (status.lower() == "approved" and receipt_status.lower() in {"cleared", "pdc"}):
                    continue
                entity = _entity_from_text(row[39] if len(row) > 39 else None, row[20] if len(row) > 20 else None)
                lin = _lineage("R31", self.source_file, "PR Data", _cell_range(ridx, [1,3,4,6,8,17,18,21,22,23,39,40,44]), _to_iso(row[6] if len(row) > 6 else None), "R31PRQualityAdapter.pr_data_issue_row", "R31 PR unit update / PR quality", ridx)
                pr_issues.append({
                    "pr_no": pr_no,
                    "account_id": _norm(row[7] if len(row) > 7 else None) or _norm(row[31] if len(row) > 31 else None),
                    "unit": _norm(row[3] if len(row) > 3 else None) or _norm(row[32] if len(row) > 32 else None),
                    "collector_rm_owner": _norm(row[43] if len(row) > 43 else None) or _norm(row[16] if len(row) > 16 else None) or _norm(row[38] if len(row) > 38 else None),
                    "amount_aed": round(amount, 2),
                    "status": status,
                    "receipt_status": receipt_status,
                    "project": _norm(row[20] if len(row) > 20 else None),
                    "sub_project": _norm(row[37] if len(row) > 37 else None),
                    "entity_code": entity,
                    "entity_display": _display_entity(entity),
                    "remarks": _norm(row[17] if len(row) > 17 else None),
                    "lineage": lin,
                })
        wb.close()
        return {"source_code": "R31", "status": "loaded", "pr_issues": pr_issues, "errors": self.errors, "warnings": self.warnings}


class R32RMCollectorsAdapter(WorkbookSource):
    source_code = "R32"
    patterns = ("R32*.xlsx", "*RM Collectors*.xlsx")

    def extract(self) -> Dict[str, Any]:
        collector_metrics: List[Dict[str, Any]] = []
        receipt_facts: List[Dict[str, Any]] = []
        if not self.exists():
            return {"source_code": "R32", "status": "missing", "collector_metrics": [], "receipt_facts": [], "errors": ["R32 missing"]}
        wb = load_workbook(self.path, read_only=True, data_only=True)
        for sheet in [s for s in wb.sheetnames if s.startswith("RM Collector")]:
            ws = wb[sheet]
            entity_hint = _entity_from_text(sheet)
            for ridx, row in enumerate(ws.iter_rows(min_row=6, values_only=True), start=6):
                collector = _norm(row[2] if len(row) > 2 else None)
                if not collector or collector.lower().startswith("total"):
                    continue
                dues_mtd = _to_float(row[4] if len(row) > 4 else None)
                target = _to_float(row[6] if len(row) > 6 else None)
                if (dues_mtd or 0) == 0 and (target or 0) == 0:
                    continue
                lin = _lineage("R32", self.source_file, sheet, _cell_range(ridx, [3,4,5,6,7,8,9]), None, "R32RMCollectorsAdapter.collector_metric_row", "R32 RM collectors performance")
                collector_metrics.append({
                    "collector_rm_owner": collector,
                    "entity_code": entity_hint,
                    "entity_display": _display_entity(entity_hint),
                    "daily_collection_aed": round(_to_float(row[3] if len(row) > 3 else None) or 0, 2),
                    "dues_mtd_aed": round(dues_mtd or 0, 2),
                    "achieved_pct": _to_float(row[5] if len(row) > 5 else None),
                    "target_net_constraints_aed": round(target or 0, 2),
                    "receipts_dues_aed": round(_to_float(row[7] if len(row) > 7 else None) or 0, 2),
                    "receipts_advance_aed": round(_to_float(row[8] if len(row) > 8 else None) or 0, 2),
                    "lineage": lin,
                })
        if "Daily Collection" in wb.sheetnames:
            ws = wb["Daily Collection"]
            for ridx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
                amount = _to_float(row[4] if len(row) > 4 else None) or 0.0
                pr_no = _norm(row[5] if len(row) > 5 else None)
                if amount <= 0:
                    continue
                entity = _entity_from_text(row[14] if len(row) > 14 else None)
                lin = _lineage("R32", self.source_file, "Daily Collection", _cell_range(ridx, [1,2,3,5,6,8,10,11,13,15]), _to_iso(row[2] if len(row) > 2 else None), "R32RMCollectorsAdapter.daily_collection_row", "R32 RM receipts / daily collection")
                receipt_facts.append({
                    "unit": _norm(row[0] if len(row) > 0 else None),
                    "account_id": _norm(row[7] if len(row) > 7 else None),
                    "collector_rm_owner": _norm(row[1] if len(row) > 1 else None) or _norm(row[12] if len(row) > 12 else None),
                    "date": _to_iso(row[2] if len(row) > 2 else None),
                    "deposit_aed": round(amount, 2),
                    "pr_no": pr_no,
                    "pr_status": _norm(row[9] if len(row) > 9 else None),
                    "installment_type": _norm(row[6] if len(row) > 6 else None),
                    "entity_code": entity,
                    "entity_display": _display_entity(entity),
                    "lineage": lin,
                })
        wb.close()
        return {"source_code": "R32", "status": "loaded", "collector_metrics": collector_metrics, "receipt_facts": receipt_facts, "errors": self.errors, "warnings": self.warnings}


class R30MonthlyFeedbackAdapter(WorkbookSource):
    source_code = "R30"
    patterns = ("R30*.xlsx", "*Monthly Feedback*.xlsx")

    def extract(self) -> Dict[str, Any]:
        facts: List[Dict[str, Any]] = []
        if not self.exists():
            return {"source_code": "R30", "status": "missing", "collector_feedback": [], "errors": ["R30 missing"]}
        wb = load_workbook(self.path, read_only=True, data_only=True)
        ws = wb["Summary"] if "Summary" in wb.sheetnames else wb[wb.sheetnames[0]]
        snapshot_date = None
        for cell in (31, 33):
            snapshot_date = snapshot_date or _to_iso(ws.cell(2, cell).value)
        for ridx, row in enumerate(ws.iter_rows(min_row=4, values_only=True), start=4):
            collector = _norm(row[1] if len(row) > 1 else None)
            if not collector or collector.lower().startswith("total"):
                continue
            lin = _lineage("R30", self.source_file, ws.title, _cell_range(ridx, [2,3,4,5,6,7,8,9,10,17,31,33,39]), snapshot_date, "R30MonthlyFeedbackAdapter.summary_collector_row", "R30 monthly collector feedback")
            facts.append({
                "collector_rm_owner": collector,
                "allocated_units": int(_to_float(row[2] if len(row) > 2 else None) or 0),
                "allocated_od_aed": round(_to_float(row[3] if len(row) > 3 else None) or 0, 2),
                "target_aed": round(_to_float(row[4] if len(row) > 4 else None) or 0, 2),
                "total_attempts": int(_to_float(row[5] if len(row) > 5 else None) or 0),
                "total_contacts": int(_to_float(row[6] if len(row) > 6 else None) or 0),
                "contact_intensity": _to_float(row[8] if len(row) > 8 else None),
                "units_paid": int(_to_float(row[9] if len(row) > 9 else None) or 0),
                "total_payment_aed": round(_to_float(row[16] if len(row) > 16 else None) or 0, 2),
                "lineage": lin,
            })
        wb.close()
        return {"source_code": "R30", "status": "loaded", "collector_feedback": facts, "errors": self.errors, "warnings": self.warnings}


class R17SPALegalAdapter(WorkbookSource):
    source_code = "R17"
    patterns = ("R17*.xlsx", "*SPA*.xlsx", "*registartion*.xlsx")

    def extract(self) -> Dict[str, Any]:
        facts: List[Dict[str, Any]] = []
        if not self.exists():
            return {"source_code": "R17", "status": "missing", "spa_project_facts": [], "errors": ["R17 missing"]}
        wb = load_workbook(self.path, read_only=True, data_only=True)
        ws = wb["Summary"] if "Summary" in wb.sheetnames else wb[wb.sheetnames[0]]
        for ridx, row in enumerate(ws.iter_rows(min_row=4, values_only=True), start=4):
            project = _norm(row[2] if len(row) > 2 else None)
            overdue = _to_float(row[3] if len(row) > 3 else None) or 0.0
            if not project or overdue <= 0:
                continue
            entity = _entity_from_text(project)
            lin = _lineage("R17", self.source_file, ws.title, _cell_range(ridx, [3,4,8,9,12,13,14,16]), None, "R17SPALegalAdapter.project_spa_row", "R17 SPA/pre-registration overdue bifurcation")
            facts.append({
                "project": project,
                "entity_code": entity,
                "entity_display": _display_entity(entity),
                "overdue_aed": round(overdue, 2),
                "spa_not_sent_aed": round(_to_float(row[7] if len(row) > 7 else None) or 0, 2),
                "spa_sent_not_signed_aed": round(_to_float(row[8] if len(row) > 8 else None) or 0, 2),
                "spa_signed_not_executed_aed": round(_to_float(row[11] if len(row) > 11 else None) or 0, 2),
                "spa_executed_not_preregistered_aed": round(_to_float(row[12] if len(row) > 12 else None) or 0, 2),
                "prereg_completed_aed": round(_to_float(row[13] if len(row) > 13 else None) or 0, 2),
                "lineage": lin,
            })
        wb.close()
        return {"source_code": "R17", "status": "loaded", "spa_project_facts": facts, "errors": self.errors, "warnings": self.warnings}


class R09ProjectCollectionsAdapter(WorkbookSource):
    source_code = "R09"
    patterns = ("R09*.xlsx", "*Collections 07*.xlsx")

    def extract(self) -> Dict[str, Any]:
        facts: List[Dict[str, Any]] = []
        if not self.exists():
            return {"source_code": "R09", "status": "missing", "project_collection_facts": [], "errors": ["R09 missing"]}
        wb = load_workbook(self.path, read_only=True, data_only=True)
        sheet = "Daily Collections-0" if "Daily Collections-0" in wb.sheetnames else wb.sheetnames[0]
        ws = wb[sheet]
        snapshot_date = _to_iso(ws.cell(3, 2).value)
        for ridx, row in enumerate(ws.iter_rows(min_row=8, values_only=True), start=8):
            project = _norm(row[3] if len(row) > 3 else None)
            overdue = _to_float(row[11] if len(row) > 11 else None) or 0.0
            sale = _to_float(row[7] if len(row) > 7 else None) or 0.0
            if not project or (overdue <= 0 and sale <= 0):
                continue
            entity = _entity_from_text(project)
            lin = _lineage("R09", self.source_file, sheet, _cell_range(ridx, [4,8,9,10,12,14,15,16,17,18]), snapshot_date, "R09ProjectCollectionsAdapter.project_collection_row", "R09 project collection detail")
            facts.append({
                "project": project,
                "entity_code": entity,
                "entity_display": _display_entity(entity),
                "sale_value_aed": round(sale, 2),
                "milestone_due_aed": round(_to_float(row[8] if len(row) > 8 else None) or 0, 2),
                "collected_to_date_aed": round(_to_float(row[9] if len(row) > 9 else None) or 0, 2),
                "overdue_aed": round(overdue, 2),
                "pro_rata_target_mtd_aed": round(_to_float(row[13] if len(row) > 13 else None) or 0, 2),
                "collected_dues_mtd_aed": round(_to_float(row[14] if len(row) > 14 else None) or 0, 2),
                "lineage": lin,
            })
        wb.close()
        return {"source_code": "R09", "status": "loaded", "project_collection_facts": facts, "errors": self.errors, "warnings": self.warnings}


class R20PRToSOATATAdapter(WorkbookSource):
    source_code = "R20"
    patterns = ("R20*.xlsx", "*PR to SOA*.xlsx")

    def extract(self) -> Dict[str, Any]:
        facts: List[Dict[str, Any]] = []
        if not self.exists():
            return {"source_code": "R20", "status": "missing", "tat_facts": [], "errors": ["R20 missing"]}
        wb = load_workbook(self.path, read_only=True, data_only=True)
        if "Summary 2" in wb.sheetnames:
            ws = wb["Summary 2"]
            months = [_norm(v) for v in next(ws.iter_rows(min_row=3, max_row=3, values_only=True))]
            for ridx, row in enumerate(ws.iter_rows(min_row=4, max_row=8, values_only=True), start=4):
                bucket = _norm(row[1] if len(row) > 1 else None)
                if not bucket:
                    continue
                for cidx in range(2, min(len(row), 14)):
                    count = _to_float(row[cidx]) or 0.0
                    if count <= 0:
                        continue
                    month = months[cidx] if cidx < len(months) else f"M{cidx}"
                    lin = _lineage("R20", self.source_file, "Summary 2", _cell(ridx, cidx + 1), None, "R20PRToSOATATAdapter.month_bucket_count", "R20 PR-to-SOA TAT count")
                    facts.append({"tat_bucket": bucket, "month": month, "count": int(count), "lineage": lin})
        wb.close()
        return {"source_code": "R20", "status": "loaded", "tat_facts": facts, "errors": self.errors, "warnings": self.warnings}


class R38RiskAnalysisAdapter(WorkbookSource):
    source_code = "R38"
    patterns = ("R38*.xlsx", "*Risk Analysis*.xlsx")

    def extract(self) -> Dict[str, Any]:
        facts: List[Dict[str, Any]] = []
        if not self.exists():
            return {"source_code": "R38", "status": "missing", "risk_facts": [], "errors": ["R38 missing"]}
        wb = load_workbook(self.path, read_only=True, data_only=True)
        risk_sheets = [s for s in wb.sheetnames if "mil" in s.lower() or "100" in s]
        paid_bands = [("0-10%", 4, 5), ("10-20%", 6, 7), ("20-30%", 8, 9), ("30-40%", 10, 11), ("40-60%", 12, 13), ("60%+", 14, 15)]
        for sheet in risk_sheets:
            ws = wb[sheet]
            current_project_group = None
            for ridx, row in enumerate(ws.iter_rows(min_row=5, values_only=True), start=5):
                if _norm(row[1] if len(row) > 1 else None):
                    current_project_group = _norm(row[1])
                tower = _norm(row[2] if len(row) > 2 else None)
                if not tower or tower.lower().startswith("grand"):
                    continue
                for band, units_col, value_col in paid_bands:
                    units = _to_float(row[units_col-1] if len(row) >= units_col else None) or 0.0
                    value = _to_float(row[value_col-1] if len(row) >= value_col else None) or 0.0
                    if units <= 0 and value <= 0:
                        continue
                    entity = _entity_from_text(current_project_group, tower)
                    lin = _lineage("R38", self.source_file, sheet, _cell_range(ridx, [2,3,units_col,value_col]), None, "R38RiskAnalysisAdapter.civ_paid_band_row", "R38 CIV/paid-band risk analysis")
                    facts.append({
                        "civ_bucket": sheet,
                        "project_group": current_project_group,
                        "tower": tower,
                        "paid_band": band,
                        "units": int(units),
                        "sale_value_aed": round(value, 2),
                        "entity_code": entity,
                        "entity_display": _display_entity(entity),
                        "lineage": lin,
                    })
        wb.close()
        return {"source_code": "R38", "status": "loaded", "risk_facts": facts, "errors": self.errors, "warnings": self.warnings}


def _extract_all(data_dir: Path) -> Dict[str, Dict[str, Any]]:
    adapters = [
        R10DuesCoverageAdapter(data_dir),
        R34TerminationAdapter(data_dir),
        R31PRQualityAdapter(data_dir),
        R32RMCollectorsAdapter(data_dir),
        R30MonthlyFeedbackAdapter(data_dir),
        R17SPALegalAdapter(data_dir),
        R09ProjectCollectionsAdapter(data_dir),
        R20PRToSOATATAdapter(data_dir),
        R38RiskAnalysisAdapter(data_dir),
    ]
    return {adapter.source_code: adapter.extract() for adapter in adapters}


def _build_lookups(extracted: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    term_by_key = {}
    for fact in extracted.get("R34", {}).get("termination_facts", []):
        term_by_key[(fact.get("account_id"), fact.get("unit"))] = fact
    alloc_by_key = {}
    for fact in extracted.get("R10", {}).get("account_allocations", []):
        alloc_by_key[(fact.get("account_id"), fact.get("unit"))] = fact
    metrics_by_collector = {}
    for fact in extracted.get("R32", {}).get("collector_metrics", []):
        metrics_by_collector.setdefault(fact.get("collector_rm_owner"), []).append(fact)
    for fact in extracted.get("R30", {}).get("collector_feedback", []):
        metrics_by_collector.setdefault(fact.get("collector_rm_owner"), []).append(fact)
    return {"termination": term_by_key, "allocation": alloc_by_key, "metrics_by_collector": metrics_by_collector}


def _make_collector_ptp_action(ptp: Dict[str, Any], term: Dict[str, Any], alloc: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    account_id = ptp.get("account_id")
    unit = ptp.get("unit")
    owner = ptp.get("collector_rm_owner") or (alloc or {}).get("collector_rm_owner") or term.get("last_action_by")
    amount = ptp.get("ptp_amount_aed") or term.get("total_overdue_aed")
    ageing = term.get("ageing_bucket")
    entity = term.get("entity_code") or ptp.get("entity_code") or (alloc or {}).get("entity_code") or "unknown"
    if not (account_id and unit and owner and amount and ageing and entity != "unknown"):
        return None
    ptp_lin = ptp.get("lineage")
    term_lin = term.get("lineage")
    refs = [
        _lineage_ref(f"PTP_{account_id}_{unit}", "Promise-to-pay amount/date", ptp_lin),
        _lineage_ref(f"AGEING_{account_id}_{unit}", "Ageing and overdue validation", term_lin),
    ]
    if alloc and alloc.get("lineage"):
        refs.append(_lineage_ref(f"OWNER_{account_id}_{unit}", "Owner allocation validation", alloc["lineage"]))
    action = {
        "action_id": f"collector_ptp::{account_id}::{unit}",
        "action_type": "collector_ptp_follow_up",
        "grain": "account_unit",
        "role_visibility": ["collector_rm", "cco_gm_agm"],
        "status": "ready",
        "title": f"Follow PTP · {account_id} / {unit}",
        "summary": f"{owner} has a PTP of {_fmt_aed(amount)} for {unit}; ageing bucket {ageing}.",
        "recommended_action": "Call/WhatsApp customer before PTP date, update disposition, and escalate if unpaid after date.",
        "severity": _severity_from(term.get("total_overdue_aed") or amount, ageing, term.get("eligible_status")),
        "account_id": account_id,
        "unit": unit,
        "customer_name": term.get("customer_name") or ptp.get("account_name"),
        "collector_rm_owner": owner,
        "manager_name": (alloc or {}).get("manager_name"),
        "entity_code": entity,
        "entity_display": _display_entity(entity),
        "parent_entity_code": PARENT_ENTITY.get(entity),
        "parent_entity_display": _display_entity(PARENT_ENTITY.get(entity)) if PARENT_ENTITY.get(entity) else None,
        "project": term.get("project") or (alloc or {}).get("project"),
        "sub_project": term.get("sub_project") or (alloc or {}).get("sub_project"),
        "amount_aed": round(float(amount), 2),
        "display_amount": _fmt_aed(amount),
        "overdue_amount_aed": term.get("total_overdue_aed") or (alloc or {}).get("overdue_eom_ms_aed"),
        "ageing_bucket": ageing,
        "ptp_date": ptp.get("ptp_date"),
        "ptp_amount_aed": ptp.get("ptp_amount_aed"),
        "ptp_status": ptp.get("ptp_status"),
        "escalation_status": term.get("possible_pdn") or term.get("eligible_status"),
        "reporting_basis": "R10 PTP + R34 ageing/termination + R10 allocation owner evidence",
        "confidence_state": "live_validated_account_owner_ageing_lineaged",
        "lineage_refs": refs,
    }
    return action if _has_account_action_minimum(action) else None


def _make_termination_action(term: Dict[str, Any], alloc: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    account_id, unit = term.get("account_id"), term.get("unit")
    amount = term.get("total_overdue_aed")
    owner = (alloc or {}).get("collector_rm_owner") or term.get("last_action_by")
    entity = term.get("entity_code") or (alloc or {}).get("entity_code")
    ageing = term.get("ageing_bucket")
    if not (account_id and unit and owner and amount and ageing and entity and entity != "unknown"):
        return None
    refs = [_lineage_ref(f"TERM_{account_id}_{unit}", "Termination / overdue eligibility", term["lineage"])]
    if alloc and alloc.get("lineage"):
        refs.append(_lineage_ref(f"OWNER_{account_id}_{unit}", "Owner allocation validation", alloc["lineage"]))
    action = {
        "action_id": f"termination::{account_id}::{unit}",
        "action_type": "termination_escalation_review",
        "grain": "account_unit",
        "role_visibility": ["cco_gm_agm", "mis_qcg_admin", "collector_rm"],
        "status": "ready",
        "title": f"Termination/PDN review · {account_id} / {unit}",
        "summary": f"{_fmt_aed(amount)} overdue; status {term.get('possible_pdn') or term.get('eligible_status')}; owner {owner}.",
        "recommended_action": "Review eligibility, validate latest contact trail, and decide development notice / termination path.",
        "severity": _severity_from(amount, ageing, term.get("eligible_status") or term.get("possible_pdn")),
        "account_id": account_id,
        "unit": unit,
        "customer_name": term.get("customer_name"),
        "collector_rm_owner": owner,
        "manager_name": (alloc or {}).get("manager_name"),
        "entity_code": entity,
        "entity_display": _display_entity(entity),
        "parent_entity_code": PARENT_ENTITY.get(entity),
        "parent_entity_display": _display_entity(PARENT_ENTITY.get(entity)) if PARENT_ENTITY.get(entity) else None,
        "project": term.get("project"),
        "sub_project": term.get("sub_project"),
        "amount_aed": round(float(amount), 2),
        "display_amount": _fmt_aed(amount),
        "overdue_amount_aed": amount,
        "ageing_bucket": ageing,
        "ptp_date": None,
        "ptp_amount_aed": None,
        "ptp_status": None,
        "escalation_status": term.get("possible_pdn") or term.get("eligible_status"),
        "reporting_basis": "R34 termination status + R10 owner allocation evidence",
        "confidence_state": "live_validated_account_owner_ageing_lineaged",
        "lineage_refs": refs,
    }
    return action if _has_account_action_minimum(action) else None


def _make_pr_action(issue: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    account_id = issue.get("account_id")
    unit = issue.get("unit")
    owner = issue.get("collector_rm_owner")
    amount = issue.get("amount_aed")
    entity = issue.get("entity_code")
    if not (account_id and unit and owner and amount and entity and entity != "unknown"):
        return None
    refs = [_lineage_ref(f"PR_{issue.get('pr_no')}", "Payment request quality issue", issue["lineage"])]
    return {
        "action_id": f"finance_pr::{issue.get('pr_no')}",
        "action_type": "finance_pr_quality_exception",
        "grain": "payment_request_account_unit",
        "role_visibility": ["finance", "mis_qcg_admin"],
        "status": "ready",
        "title": f"PR exception · {issue.get('pr_no')}",
        "summary": f"{issue.get('status') or 'PR issue'} / receipt {issue.get('receipt_status') or 'unknown'} for {_fmt_aed(amount)}.",
        "recommended_action": "Resolve PR status, correct receipt mapping, and confirm SOA impact before customer follow-up.",
        "severity": "attention" if amount < 500_000 else "risk",
        "account_id": account_id,
        "unit": unit,
        "customer_name": None,
        "collector_rm_owner": owner,
        "entity_code": entity,
        "entity_display": _display_entity(entity),
        "amount_aed": round(float(amount), 2),
        "display_amount": _fmt_aed(amount),
        "ageing_bucket": "process_exception",
        "pr_status": issue.get("status"),
        "receipt_status": issue.get("receipt_status"),
        "project": issue.get("project"),
        "reporting_basis": "R31 PR unit update / PR quality evidence",
        "confidence_state": "live_validated_pr_exception_lineaged",
        "lineage_refs": refs,
    }


def _make_coverage_action(coverage: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if (coverage.get("not_worked_units") or 0) <= 0:
        return None
    refs = [_lineage_ref(f"COVERAGE_{coverage.get('collector_rm_owner')}", "Collector not-worked coverage", coverage["lineage"])]
    return {
        "action_id": f"coverage::{coverage.get('collector_rm_owner')}",
        "action_type": "coverage_gap_review",
        "grain": "collector",
        "role_visibility": ["cco_gm_agm", "mis_qcg_admin"],
        "status": "ready",
        "title": f"Coverage gap · {coverage.get('collector_rm_owner')}",
        "summary": f"{coverage.get('not_worked_units')} not-worked units; OD pool {_fmt_aed(coverage.get('total_odeom_amount_aed'))}.",
        "recommended_action": "Ask team lead to clear not-worked queue and validate disposition quality.",
        "severity": "attention" if (coverage.get("not_worked_units") or 0) < 20 else "risk",
        "collector_rm_owner": coverage.get("collector_rm_owner"),
        "amount_aed": coverage.get("total_odeom_amount_aed"),
        "display_amount": _fmt_aed(coverage.get("total_odeom_amount_aed")),
        "ageing_bucket": "coverage_gap",
        "reporting_basis": "R10 Agent Coverage",
        "confidence_state": "live_validated_collector_coverage_lineaged",
        "lineage_refs": refs,
    }


def _make_tat_actions(tat_facts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    actions = []
    for fact in tat_facts:
        if fact.get("tat_bucket") not in {"9-15 days", "15+ days"}:
            continue
        if fact.get("month") != "May":
            continue
        count = fact.get("count") or 0
        if count <= 0:
            continue
        refs = [_lineage_ref(f"TAT_{fact.get('tat_bucket')}_{fact.get('month')}", "PR-to-SOA TAT ageing bucket", fact["lineage"])]
        actions.append({
            "action_id": f"tat::{fact.get('month')}::{fact.get('tat_bucket')}",
            "action_type": "pr_to_soa_tat_backlog",
            "grain": "process_bucket_month",
            "role_visibility": ["finance", "mis_qcg_admin"],
            "status": "ready",
            "title": f"PR-to-SOA TAT · {fact.get('tat_bucket')}",
            "summary": f"{count:,} receipts in {fact.get('tat_bucket')} TAT bucket for {fact.get('month')}.",
            "recommended_action": "Review process backlog, isolate stalled modes, and update finance/QCG closure plan.",
            "severity": "risk" if fact.get("tat_bucket") == "15+ days" else "attention",
            "amount_aed": count,
            "display_amount": f"{count:,} receipts",
            "ageing_bucket": fact.get("tat_bucket"),
            "reporting_basis": "R20 PR-to-SOA TAT Report",
            "confidence_state": "live_validated_process_tat_lineaged",
            "lineage_refs": refs,
        })
    return actions


def _top(items: List[Dict[str, Any]], limit: int) -> List[Dict[str, Any]]:
    return sorted(items, key=lambda x: (x.get("severity") == "risk", float(x.get("amount_aed") or 0)), reverse=True)[:limit]


_ACTION_QUEUE_CACHE_LOCK = threading.RLock()
_ACTION_QUEUE_CACHE: Dict[Tuple[str, str], Tuple[float, Dict[str, Any]]] = {}
_ACTION_QUEUE_CACHE_HITS = 0
_ACTION_QUEUE_CACHE_MISSES = 0


def _action_cache_ttl_seconds() -> int:
    try:
        return int(os.environ.get("SCIP_ACTION_QUEUE_CACHE_TTL_SECONDS", os.environ.get("SCIP_DATA_CACHE_TTL_SECONDS", "900")))
    except ValueError:
        return 900


def _resolve_action_data_dir(data_dir: Optional[Path | str] = None) -> Path:
    base = Path(
        data_dir
        or os.environ.get("SCIP_SOURCE_ROOT")
        or os.environ.get("DATA_DIR")
        or Path(__file__).resolve().parent
    ).resolve()
    if not any(base.glob("R10*.xlsx")) and Path("/mnt/data").exists():
        fallback = Path("/mnt/data").resolve()
        if any(fallback.glob("R10*.xlsx")):
            base = fallback
    return base


def invalidate_action_queue_cache() -> None:
    global _ACTION_QUEUE_CACHE
    with _ACTION_QUEUE_CACHE_LOCK:
        _ACTION_QUEUE_CACHE = {}


def get_action_queue_cache_status() -> Dict[str, Any]:
    now = time.time()
    with _ACTION_QUEUE_CACHE_LOCK:
        entries = []
        for (data_dir, role), (loaded_at, payload) in _ACTION_QUEUE_CACHE.items():
            entries.append({
                "data_dir": data_dir,
                "role": role,
                "age_seconds": round(now - loaded_at, 3),
                "status": payload.get("status"),
            })
        return {
            "status": "warm" if entries else "cold",
            "ttl_seconds": _action_cache_ttl_seconds(),
            "entries": entries,
            "hits": _ACTION_QUEUE_CACHE_HITS,
            "misses": _ACTION_QUEUE_CACHE_MISSES,
            "lineage_preserved": True,
            "no_silent_fallback": True,
        }


def _build_action_queue_payload_uncached(data_dir: Optional[Path | str] = None, role: Optional[str] = None) -> Dict[str, Any]:
    base = _resolve_action_data_dir(data_dir)
    extracted = _extract_all(base)
    lookups = _build_lookups(extracted)
    term_by_key = lookups["termination"]
    alloc_by_key = lookups["allocation"]

    # Build true account-level collector actions from R10 PTP + R34 ageing + R10 owner allocation.
    collector_actions: List[Dict[str, Any]] = []
    for ptp in extracted.get("R10", {}).get("ptp_facts", []):
        key = (ptp.get("account_id"), ptp.get("unit"))
        action = _make_collector_ptp_action(ptp, term_by_key.get(key, {}), alloc_by_key.get(key))
        if action:
            collector_actions.append(action)

    termination_actions: List[Dict[str, Any]] = []
    for term in extracted.get("R34", {}).get("termination_facts", []):
        key = (term.get("account_id"), term.get("unit"))
        if (term.get("possible_pdn") or "").upper() != "TERMINATION" and term.get("ageing_bucket") not in {"180+", "121-180", "91-120"}:
            continue
        action = _make_termination_action(term, alloc_by_key.get(key))
        if action:
            termination_actions.append(action)

    finance_pr_actions = [_make_pr_action(issue) for issue in extracted.get("R31", {}).get("pr_issues", [])]
    finance_pr_actions = [a for a in finance_pr_actions if a]
    coverage_actions = [_make_coverage_action(c) for c in extracted.get("R10", {}).get("collector_coverage", [])]
    coverage_actions = [a for a in coverage_actions if a]
    tat_actions = _make_tat_actions(extracted.get("R20", {}).get("tat_facts", []))

    collector_actions = _top(collector_actions, 40)
    termination_actions = _top(termination_actions, 40)
    finance_pr_actions = _top(finance_pr_actions, 40)
    coverage_actions = _top(coverage_actions, 20)
    tat_actions = _top(tat_actions, 10)

    roles = {
        "collector_rm": {
            "role": "collector_rm",
            "status": "ready" if collector_actions else "blocked_no_ready_actions",
            "headline": "Collector/RM PTP follow-up queue is unlocked with account, owner, amount, ageing and lineage.",
            "disclosure": "Only PTP actions that join R10 PTP, R34 ageing/termination, and R10 owner allocation are shown.",
            "account_actions": collector_actions,
            "process_actions": [],
            "management_actions": [],
            "required_source_fields": ["account_id", "unit", "collector_rm_owner", "entity", "amount", "ageing_bucket", "lineage"],
            "reporting_basis": "R10 PTP + R34 ageing + R10 allocation",
        },
        "cco_gm_agm": {
            "role": "cco_gm_agm",
            "status": "ready",
            "headline": "Management risk queue combines PTP follow-ups, termination reviews and coverage gaps.",
            "disclosure": "Account actions are source-lineaged; project/risk enrichments stay separate from collector ownership.",
            "account_actions": collector_actions[:15] + termination_actions[:15],
            "process_actions": coverage_actions[:8],
            "management_actions": termination_actions[:20],
            "required_source_fields": ["account_id", "unit", "owner", "entity", "amount", "ageing", "lineage"],
            "reporting_basis": "R10/R34/R30/R32 management queue",
        },
        "finance": {
            "role": "finance",
            "status": "ready" if finance_pr_actions or tat_actions else "blocked_no_process_actions",
            "headline": "Finance queue surfaces PR exceptions and PR-to-SOA TAT ageing.",
            "disclosure": "Finance actions come from PR/TAT sources and do not assign collector calls unless owner evidence exists.",
            "account_actions": finance_pr_actions[:25],
            "process_actions": tat_actions,
            "management_actions": [],
            "required_source_fields": ["pr_no/account", "unit", "owner where available", "amount/count", "process ageing/status", "lineage"],
            "reporting_basis": "R31 PR quality + R20 PR-to-SOA TAT",
        },
        "mis_qcg_admin": {
            "role": "mis_qcg_admin",
            "status": "ready",
            "headline": "MIS/QCG queue validates owner mapping, PR exceptions, coverage gaps and process TAT.",
            "disclosure": "Queue emphasizes data/process closure and blocks unlineaged account tasks.",
            "account_actions": finance_pr_actions[:15] + termination_actions[:10],
            "process_actions": coverage_actions[:15] + tat_actions,
            "management_actions": [],
            "required_source_fields": ["source_lineage", "owner/entity mapping", "amount/status validation"],
            "reporting_basis": "R10/R20/R31/R34 governance queue",
        },
    }

    if role and role in roles:
        roles = {role: roles[role]}

    validations = _validate_roles(roles)
    source_status = {code: extracted.get(code, {}).get("status") for code in CRITICAL_REPORTS}
    facts_summary = {
        "r10_allocations": len(extracted.get("R10", {}).get("account_allocations", [])),
        "r10_ptp_facts": len(extracted.get("R10", {}).get("ptp_facts", [])),
        "r34_termination_facts": len(extracted.get("R34", {}).get("termination_facts", [])),
        "r31_pr_issues": len(extracted.get("R31", {}).get("pr_issues", [])),
        "r32_collector_metrics": len(extracted.get("R32", {}).get("collector_metrics", [])),
        "r32_receipt_facts": len(extracted.get("R32", {}).get("receipt_facts", [])),
        "r30_collector_feedback": len(extracted.get("R30", {}).get("collector_feedback", [])),
        "r17_spa_project_facts": len(extracted.get("R17", {}).get("spa_project_facts", [])),
        "r09_project_collection_facts": len(extracted.get("R09", {}).get("project_collection_facts", [])),
        "r20_tat_facts": len(extracted.get("R20", {}).get("tat_facts", [])),
        "r38_risk_facts": len(extracted.get("R38", {}).get("risk_facts", [])),
        "collector_account_actions_ready": len(collector_actions),
        "termination_review_actions_ready": len(termination_actions),
        "finance_pr_actions_ready": len(finance_pr_actions),
        "process_actions_ready": len(coverage_actions) + len(tat_actions),
    }
    return {
        "contract_version": "action_queues.v2.batch7",
        "status": "ready_account_level_guarded" if validations["passed"] else "validation_failed",
        "generated_at": _now(),
        "guardrails": _guardrails(),
        "source_availability": source_status,
        "data_grain_disclosure": {
            "current_grain": "account_unit_with_project_process_enrichment",
            "true_account_level_available": bool(collector_actions),
            "rule": "No account action appears without account ID/unit, owner, entity, amount/status, ageing bucket or process status, and lineage.",
        },
        "facts_summary": facts_summary,
        "roles": roles,
        "validations": validations,
        "lineage_sample": _sample_lineage_refs(roles),
        "source_notes": {
            "R17": "Project/legal SPA enrichment; not owner source.",
            "R38": "Project/CIV risk enrichment; not owner source.",
            "R09": "Project collection enrichment; not owner source.",
            "R30_R32": "Collector performance/receipt context; R10/R34 provide the account-action join gate.",
        },
    }


def build_action_queue_payload(
    data_dir: Optional[Path | str] = None,
    role: Optional[str] = None,
    *,
    force_refresh: bool = False,
) -> Dict[str, Any]:
    """Return role-scoped action queues using a short in-memory cache.

    This keeps role switch and Risk & Action navigation from reparsing the
    account/action workbooks on every click. RBAC filtering still runs after this
    function in the route layer, so a deep copy is returned to avoid mutating the
    shared cached payload.
    """
    global _ACTION_QUEUE_CACHE_HITS, _ACTION_QUEUE_CACHE_MISSES
    base = _resolve_action_data_dir(data_dir)
    role_key = role or "__all__"
    cache_key = (str(base), role_key)
    ttl = _action_cache_ttl_seconds()
    now = time.time()

    if ttl > 0 and not force_refresh:
        with _ACTION_QUEUE_CACHE_LOCK:
            cached = _ACTION_QUEUE_CACHE.get(cache_key)
            if cached and now - cached[0] <= ttl:
                _ACTION_QUEUE_CACHE_HITS += 1
                return copy.deepcopy(cached[1])

    with _ACTION_QUEUE_CACHE_LOCK:
        now = time.time()
        if ttl > 0 and not force_refresh:
            cached = _ACTION_QUEUE_CACHE.get(cache_key)
            if cached and now - cached[0] <= ttl:
                _ACTION_QUEUE_CACHE_HITS += 1
                return copy.deepcopy(cached[1])

        _ACTION_QUEUE_CACHE_MISSES += 1
        payload = _build_action_queue_payload_uncached(data_dir=base, role=role)
        if ttl > 0:
            _ACTION_QUEUE_CACHE[cache_key] = (time.time(), payload)
        return copy.deepcopy(payload)


def _sample_lineage_refs(roles: Dict[str, Any]) -> List[Dict[str, Any]]:
    refs: List[Dict[str, Any]] = []
    for payload in roles.values():
        for section in ("account_actions", "process_actions", "management_actions"):
            for action in payload.get(section, [])[:2]:
                refs.extend(action.get("lineage_refs") or [])
    return refs[:10]


def _guardrails() -> Dict[str, Any]:
    return {
        "tolerance_pct": 0.05,
        "no_silent_fallback": True,
        "locked_hierarchy": "Group > Sobha(Sobha Dubai, Sobha AUH) + UAQ(Siniya, Downtown UAQ)",
        "role_model": ["Board/CXO", "CCO/GM/AGM", "Finance", "MIS/QCG/Admin", "Collector/RM"],
        "removed_role": "Entity Head",
        "account_action_gate": "account actions require account_id + unit + owner + entity + amount/status + ageing/process status + lineage",
        "liquid_glass_gate": "action queues and collector detail remain L4/L5 evidence/action output; dense rows use solid surfaces",
    }


def _validate_roles(roles: Dict[str, Any]) -> Dict[str, Any]:
    checks: Dict[str, bool] = {}
    visible_actions: List[Dict[str, Any]] = []
    for role_payload in roles.values():
        for section in ("account_actions", "process_actions", "management_actions"):
            visible_actions.extend(role_payload.get(section) or [])
    account_level = [a for a in visible_actions if a.get("grain") in {"account_unit", "payment_request_account_unit"}]
    checks["all_visible_actions_have_lineage"] = all(_has_action_lineage(a) for a in visible_actions)
    checks["account_actions_have_owner_entity_amount_ageing_or_process_status"] = all(
        a.get("account_id") and a.get("unit") and a.get("collector_rm_owner") and a.get("entity_code") and a.get("amount_aed") is not None and (a.get("ageing_bucket") or a.get("pr_status"))
        for a in account_level
    )
    checks["collector_role_has_only_collector_visible_account_actions"] = all(
        set(a.get("role_visibility") or []).intersection({"collector_rm"}) and a.get("action_type") in {"collector_ptp_follow_up", "termination_escalation_review"}
        for a in roles.get("collector_rm", {}).get("account_actions", [])
    )
    checks["finance_role_has_no_collector_call_ptp_actions"] = all(
        a.get("action_type") != "collector_ptp_follow_up"
        for a in roles.get("finance", {}).get("account_actions", [])
    )
    checks["entity_head_removed"] = "entity_head" not in roles
    checks["reporting_basis_present"] = all(bool(a.get("reporting_basis")) for a in visible_actions)
    return {"passed": all(checks.values()), "checks": checks, "checked_action_count": len(visible_actions), "checked_account_action_count": len(account_level)}


if APIRouter is not None:
    router = APIRouter(prefix="/action-queues", tags=["action-queues"])

    @router.get("")
    async def get_action_queues(request: Request, role: Optional[str] = None) -> Any:
        actor = auth.get_actor(request) if auth is not None else None
        requested_role = actor.role if actor is not None else role
        payload = build_action_queue_payload(role=requested_role)
        if auth is not None and actor is not None:
            payload = auth.filter_action_queue_payload(payload, actor)
        return JSONResponse(content=payload, status_code=200)

    @router.get("/collector-drilldown")
    async def get_collector_drilldown(request: Request, collector: Optional[str] = None) -> Any:
        actor = auth.get_actor(request) if auth is not None else None
        if actor is not None and actor.role not in {"collector_rm", "cco_gm_agm", "mis_qcg_admin"}:
            auth.log_denied_attempt(actor, "read:collector_drilldown", "role_not_allowed", path="/action-queues/collector-drilldown")
            return JSONResponse(content={"status": "denied", "reason": "role_not_allowed"}, status_code=403)
        payload = build_action_queue_payload(role="collector_rm")
        actions = payload.get("roles", {}).get("collector_rm", {}).get("account_actions", [])
        if collector:
            actions = [a for a in actions if str(a.get("collector_rm_owner", "")).lower() == collector.lower()]
        if auth is not None and actor is not None:
            actions = auth.filter_rows_for_actor(actions, actor, "read:action_queues")
        return JSONResponse(content={
            "contract_version": "collector_drilldown.v3.batch11",
            "status": "ready" if actions else "no_actions_for_filter",
            "collector": collector or "all",
            "account_actions": actions,
            "validations": payload.get("validations"),
            "guardrails": payload.get("guardrails"),
            "rbac": {"actor": actor.to_dict() if actor is not None else None, "filtered": auth is not None},
        }, status_code=200)
```


---

## `SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/Backend/data_loader.py`


```python
"""
SOBHA COLLECTIONS INTELLIGENCE PLATFORM
data_loader.py — R-Series Data Pipeline
Version: v8.3 Batch 3
Authority: FINAL_ARCHITECTURE.md

Responsibilities:
  - Read all active R-series xlsx files from /data directory
  - Apply column mappings from pipeline_config.json
  - Compute all derived constants (OD_TODAY, PIPELINE_GROSS, etc.)
  - Return { "dataframes": dict, "computed": dict }
  - Pre-aggregate lean summary JSON for frontend (~100KB)
  - Graceful degradation on missing or malformed files

Dependency rule:
  data_loader.py  →  imports: constants, utils, pipeline_config.json
  data_loader.py  →  NEVER imports: endpoints, quickball, main
  data_loader.py  →  is stateless. No session state. No globals mutated.

Architecture rules (never violate):
  - OD_TODAY comes from R18. Never hardcoded.
  - PIPELINE_GROSS, PIPELINE_ADV_DENOM come from R36.
  - CY_ADV_MIX_YTD computed ONCE here. Never per-submodule.
  - DAILY_DAYS[] extracted from R04 ONCE. Never per-section.
  - Collector data sorted DESC by achievement_pct on load.
  - Missing file → data_pending payload, not crash.
  - All monetary values stored as AED base units (not millions).
"""

from __future__ import annotations

import copy
import json
import logging
import os
import threading
import time
from datetime import datetime, date
from pathlib import Path
from typing import Any, Optional

import openpyxl

import constants as C
import utils as U
import file_resolver
import source_adapters

# ---------------------------------------------------------------------------
# LOGGING
# ---------------------------------------------------------------------------
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# PATHS
# ---------------------------------------------------------------------------
# Resolve /data directory relative to this file's location.
# In deployment: backend/ sits next to data/ at repo root.
_HERE = Path(__file__).parent
DEFAULT_DATA_DIR = (_HERE.parent / "data").resolve()
DATA_DIR = Path(
    os.environ.get("SCIP_SOURCE_ROOT")
    or os.environ.get("DATA_DIR")
    or DEFAULT_DATA_DIR
).resolve()
PIPELINE_CONFIG_PATH = (_HERE / "pipeline_config.json").resolve()
logger.info("SCIP data source directory resolved to: %s", DATA_DIR)

# ---------------------------------------------------------------------------
# STAGING/UAT CACHE
# ---------------------------------------------------------------------------
# Render Free + Google Drive bootstrap + Excel parsing can make every request
# expensive if endpoints call load_all() directly. The cache below keeps the
# lineage-bearing server payload in memory for a short TTL. It does not compute
# or fabricate business numbers; it only reuses the last trusted loader output.
_DATA_CACHE_LOCK = threading.RLock()
_DATA_CACHE_PAYLOAD: Optional[dict] = None
_DATA_CACHE_LOADED_AT: Optional[float] = None
_DATA_CACHE_DIR: Optional[str] = None
_DATA_CACHE_HITS = 0
_DATA_CACHE_MISSES = 0


def _cache_ttl_seconds() -> int:
    try:
        return int(os.environ.get("SCIP_DATA_CACHE_TTL_SECONDS", "900"))
    except ValueError:
        return 900


def _resolve_active_data_dir(data_dir: Optional[Path | str] = None) -> Path:
    if data_dir:
        return Path(data_dir).resolve()
    return Path(
        os.environ.get("SCIP_SOURCE_ROOT")
        or os.environ.get("DATA_DIR")
        or DATA_DIR
    ).resolve()


# ---------------------------------------------------------------------------
# SECTION 1 — CONFIG LOADER
# ---------------------------------------------------------------------------

def _load_pipeline_config() -> dict:
    """Load pipeline_config.json. Raises on missing file — config is required."""
    with open(PIPELINE_CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def _load_source_with_adapter(source_id: str, file_path: Path, source_cfg: dict) -> dict:
    """
    Load complex R-series sources through source-specific adapters.

    Batch 3 implements R18, R04, R02, R08, and R36 as production adapters because
    they are positional/matrix based and cannot be trusted through the
    generic flat header-reader.
    """
    try:
        adapter_result = source_adapters.run_adapter(source_id, file_path).to_dict()
    except Exception as exc:
        logger.exception("Adapter load failed for %s", source_id)
        return {
            "id": source_id,
            "status": "error",
            "rows": [],
            "aggs": {},
            "lineage": {},
            "validations": {},
            "errors": [str(exc)],
            "data_date": source_cfg.get("data_date"),
        }

    status_map = {"ok": "ok", "warning": "ok", "unavailable": "missing", "error": "error"}
    metrics = adapter_result.get("metrics", {}) or {}
    return {
        "id": source_id,
        "status": status_map.get(adapter_result.get("status"), "error"),
        "adapter_status": adapter_result.get("status"),
        "rows": adapter_result.get("rows", []),
        "aggs": metrics,
        "lineage": adapter_result.get("lineage", {}),
        "validations": adapter_result.get("validations", {}),
        "warnings": adapter_result.get("warnings", []),
        "errors": adapter_result.get("errors", []),
        "data_date": metrics.get("SNAPSHOT_DATE") or source_cfg.get("data_date"),
    }


# ---------------------------------------------------------------------------
# SECTION 2 — OPENPYXL SHEET READER
# ---------------------------------------------------------------------------

def _read_sheet(file_path: Path, sheet_name: Any) -> Optional[list[dict]]:
    """
    Read a single xlsx sheet into a list of row dicts.
    Uses openpyxl read_only mode for performance.

    Returns:
        List of dicts (header → value) or None on failure.
    """
    try:
        wb = openpyxl.load_workbook(str(file_path), read_only=True, data_only=True)

        # Resolve sheet name
        if isinstance(sheet_name, int):
            ws = wb.worksheets[sheet_name]
        elif isinstance(sheet_name, str):
            if sheet_name not in wb.sheetnames:
                logger.warning("Sheet '%s' not found in %s. Available: %s",
                               sheet_name, file_path.name, wb.sheetnames)
                wb.close()
                return None
            ws = wb[sheet_name]
        else:
            ws = wb.active

        rows = list(ws.iter_rows(values_only=True))
        wb.close()

        if not rows:
            return []

        headers = [str(h).strip() if h is not None else f"col_{i}"
                   for i, h in enumerate(rows[0])]
        result = []
        for row in rows[1:]:
            if all(v is None for v in row):
                continue  # skip blank rows
            result.append(dict(zip(headers, row)))
        return result

    except FileNotFoundError:
        logger.info("File not found (graceful skip): %s", file_path.name)
        return None
    except Exception as exc:
        logger.warning("Failed to read %s sheet=%s: %s", file_path.name, sheet_name, exc)
        return None


# ---------------------------------------------------------------------------
# SECTION 3 — COLUMN MAPPER & TYPE COERCER
# ---------------------------------------------------------------------------

def _apply_column_map(rows: list[dict], col_map: dict, col_types: dict) -> list[dict]:
    """
    Rename columns per pipeline_config column_map and coerce types.
    Rows that don't have any mapped column are skipped.
    """
    mapped = []
    for row in rows:
        new_row: dict = {}
        for src_col, dest_col in col_map.items():
            raw = row.get(src_col)
            coerced = _coerce(raw, col_types.get(dest_col, "str"))
            new_row[dest_col] = coerced
        if any(v is not None for v in new_row.values()):
            mapped.append(new_row)
    return mapped


def _coerce(value: Any, type_str: str) -> Any:
    """
    Coerce a raw openpyxl cell value to the declared type.
    Returns None on conversion failure — never raises.
    """
    if value is None:
        return None
    try:
        if type_str == "int":
            return int(float(value))
        if type_str == "float":
            return float(value)
        if type_str == "bool":
            if isinstance(value, bool):
                return value
            return str(value).strip().lower() in ("true", "yes", "1")
        if type_str == "datetime":
            if isinstance(value, (datetime, date)):
                return value
            # Try parsing common string formats
            for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y/%m/%d", "%d %b %Y"):
                try:
                    return datetime.strptime(str(value).strip(), fmt)
                except ValueError:
                    continue
            return None
        # Default: str
        return str(value).strip() if value is not None else None
    except (ValueError, TypeError):
        return None


# ---------------------------------------------------------------------------
# SECTION 4 — AGGREGATION ENGINE
# ---------------------------------------------------------------------------

def _run_aggregations(rows: list[dict], agg_cfg: dict) -> dict:
    """
    Execute the aggregation operations declared in pipeline_config for a source.

    Supported ops:
      sum            → sum a column
      mean           → mean of a column
      filter_sum     → sum after filtering
      filter_mean    → mean after filtering
      filter_count   → count rows after filtering
      count_filter   → same as filter_count (alias)
      last           → last non-null value
      extract_list   → extract column as list
      weighted_avg   → sum(numerator) / sum(denominator) * 100
      derived        → computed from other aggregation results (deferred)
    """
    results: dict = {}

    for agg_name, agg_def in agg_cfg.items():
        op = agg_def.get("op")
        col = agg_def.get("col")
        filt = agg_def.get("filter", {})

        try:
            filtered = _filter_rows(rows, filt) if filt else rows

            if op == "sum":
                results[agg_name] = _safe_sum(filtered, col)

            elif op == "filter_sum":
                results[agg_name] = _safe_sum(filtered, col)

            elif op == "mean":
                vals = [r[col] for r in filtered if r.get(col) is not None]
                results[agg_name] = sum(vals) / len(vals) if vals else None

            elif op == "filter_mean":
                vals = [r[col] for r in filtered if r.get(col) is not None]
                results[agg_name] = sum(vals) / len(vals) if vals else None

            elif op in ("filter_count", "count_filter"):
                results[agg_name] = sum(
                    1 for r in filtered if r.get(col) is not None
                )

            elif op == "last":
                vals = [r[col] for r in filtered if r.get(col) is not None]
                results[agg_name] = vals[-1] if vals else None

            elif op == "extract_list":
                fmt = agg_def.get("format", "raw")
                vals = []
                for r in filtered:
                    v = r.get(col)
                    if v is None:
                        continue
                    if fmt == "DD MMM" and isinstance(v, (datetime, date)):
                        vals.append(v.strftime("%d %b"))
                    else:
                        vals.append(v)
                results[agg_name] = vals

            elif op == "weighted_avg":
                num_col = agg_def.get("numerator")
                den_col = agg_def.get("denominator")
                multiply = agg_def.get("multiply_100", False)
                total_num = _safe_sum(filtered, num_col)
                total_den = _safe_sum(filtered, den_col)
                if total_den and total_den > 0:
                    ratio = total_num / total_den
                    results[agg_name] = ratio * 100 if multiply else ratio
                else:
                    results[agg_name] = None

            elif op == "derived":
                # Deferred — resolved after all sources loaded
                results[agg_name] = {"__deferred__": agg_def.get("formula")}

            elif op == "read_metadata":
                # SNAPSHOT_DATE — resolved from source cfg data_date field
                results[agg_name] = {"__metadata__": agg_def.get("field")}

        except Exception as exc:
            logger.warning("Aggregation '%s' failed: %s", agg_name, exc)
            results[agg_name] = None

    return results


def _filter_rows(rows: list[dict], filt: dict) -> list[dict]:
    """
    Apply filter conditions to rows.
    Supported filter keys:
      col_name: value          → exact match (str comparison lowercase)
      col_name_in: [v1, v2]   → membership test
      col_name_ne: value       → not-equal
      entity_section: "A-E"   → special: maps Sobha section codes
      year: int                → filter numeric year column
      month_in: [str, ...]     → filter datetime month strings
    """
    result = []
    for row in rows:
        match = True
        for key, val in filt.items():
            if key == "entity_section":
                # R18 special: sections A-E = Sobha, F = Siniya, G = DT
                entity = row.get("entity", "")
                section_map = {
                    "A-E": lambda e: str(e).strip().upper() in ("A","B","C","D","E","SOBHA"),
                    "F":   lambda e: str(e).strip().upper() in ("F","SINIYA"),
                    "G":   lambda e: str(e).strip().upper() in ("G","DT","DOWNTOWN"),
                }
                checker = section_map.get(val)
                if checker and not checker(entity):
                    match = False
            elif key.endswith("_in"):
                col = key[:-3]
                cell = row.get(col)
                if cell is None:
                    match = False
                else:
                    cell_str = str(cell)[:7]  # "2026-01" prefix
                    if cell_str not in [str(v)[:7] for v in val]:
                        match = False
            elif key.endswith("_ne"):
                col = key[:-3]
                cell = row.get(col)
                if cell is not None and str(cell).strip().lower() == str(val).lower():
                    match = False
            elif key == "year":
                # Filter by year extracted from datetime or int column
                for yr_col in ("year", "month", "collection_date", "acd_year"):
                    cell = row.get(yr_col)
                    if cell is not None:
                        extracted = _extract_year(cell)
                        if extracted is not None and extracted != int(val):
                            match = False
                        break
            else:
                # Exact match
                cell = row.get(key)
                if cell is None:
                    match = False
                elif str(cell).strip().lower() != str(val).strip().lower():
                    match = False

        if match:
            result.append(row)
    return result


def _extract_year(value: Any) -> Optional[int]:
    """Extract 4-digit year from datetime, int, or string."""
    if isinstance(value, (datetime, date)):
        return value.year
    if isinstance(value, int):
        return value if 2000 <= value <= 2100 else None
    try:
        s = str(value)
        if len(s) >= 4:
            yr = int(s[:4])
            if 2000 <= yr <= 2100:
                return yr
    except (ValueError, TypeError):
        pass
    return None


def _safe_sum(rows: list[dict], col: str) -> float:
    """Sum a numeric column, skipping None values."""
    return sum(r[col] for r in rows if r.get(col) is not None)


# ---------------------------------------------------------------------------
# SECTION 5 — SINGLE SOURCE LOADER
# ---------------------------------------------------------------------------

def _load_source(source_id: str, source_cfg: dict, data_dir: Path, resolved_files: dict = None) -> dict:
    """
    Load one R-series source: read → map → aggregate.

    Returns:
        {
            "id":      "R18",
            "status":  "ok" | "missing" | "error",
            "rows":    [...],          # mapped rows
            "aggs":    {...},          # aggregation results
            "data_date": "2026-03-15"
        }
    """
    # Use file_resolver prefix matching (preferred) or fall back to config filename
    if resolved_files and source_id in resolved_files:
        file_path = Path(resolved_files[source_id])
    else:
        fname = source_cfg["file"]
        candidates = [data_dir / fname, data_dir / fname.lower(), data_dir / fname.upper()]
        file_path = next((p for p in candidates if p.exists()), data_dir / fname)
    adapter_name = source_cfg.get("adapter_class")
    if source_id.upper() in getattr(source_adapters, "ADAPTERS", {}) or adapter_name in {
        "R18OverdueAdapter",
        "R04FinanceDailyAdapter",
        "R02MDOAdapter",
        "R08AdvanceAdapter",
        "R36MilestoneCohortAdapter",
    }:
        return _load_source_with_adapter(source_id.upper(), file_path, source_cfg)

    sheet_name = source_cfg.get("sheet_name", 0)
    col_map = source_cfg.get("column_map", {})
    col_types = source_cfg.get("column_types", {})
    agg_cfg = source_cfg.get("aggregations", {})

    raw_rows = _read_sheet(file_path, sheet_name)

    if raw_rows is None:
        logger.info("Source %s not available — graceful degradation", source_id)
        return {
            "id": source_id,
            "status": "missing",
            "rows": [],
            "aggs": {},
            "data_date": source_cfg.get("data_date", None),
        }

    # Apply column map + type coercion
    mapped_rows = _apply_column_map(raw_rows, col_map, col_types) if col_map else []

    # Inject fixed entity if declared
    fixed_entity = source_cfg.get("fixed_entity")
    if fixed_entity:
        for row in mapped_rows:
            row["entity"] = fixed_entity

    # Apply post_load sort (R30 collector chart)
    post_load = source_cfg.get("post_load", {})
    if "sort" in post_load:
        sort_col = post_load["sort"]["col"]
        sort_desc = post_load["sort"]["order"] == "desc"
        mapped_rows.sort(
            key=lambda r: r.get(sort_col) if r.get(sort_col) is not None else -999,
            reverse=sort_desc,
        )

    # Run aggregations
    aggs = _run_aggregations(mapped_rows, agg_cfg)

    # Read data_date from config (SNAPSHOT_DATE resolution)
    data_date = source_cfg.get("data_date")

    return {
        "id": source_id,
        "status": "ok",
        "rows": mapped_rows,
        "aggs": aggs,
        "data_date": data_date,
    }


# ---------------------------------------------------------------------------
# SECTION 6 — DERIVED CONSTANT RESOLVER
# ---------------------------------------------------------------------------

def _resolve_derived_constants(computed: dict) -> dict:
    """
    Resolve constants that depend on other already-computed values.
    Currently: PIPELINE_ADV_DENOM = PIPELINE_GROSS - 5.7B offset.
    """
    pg = computed.get("PIPELINE_GROSS")
    if pg is not None:
        computed["PIPELINE_ADV_DENOM"] = pg - C.PIPELINE_ADV_DENOM_OFFSET_AED

    # PIPELINE_FORWARD_BOOK is a narrative constant — always use structural value
    computed["PIPELINE_FORWARD_BOOK"] = C.GROUP_SALE_VALUE_ITD_AED - C.GROUP_COLLECTED_ITD_AED
    # Override with known approximate: ~40B as per architecture
    computed["PIPELINE_FORWARD_BOOK"] = 40_000_000_000

    return computed


# ---------------------------------------------------------------------------
# SECTION 7 — COMPUTED DICT BUILDER
# ---------------------------------------------------------------------------

def _build_computed(sources: dict) -> dict:
    """
    Build the platform-wide computed dict from all loaded source aggregations.
    This is the authoritative set of derived constants consumed by all endpoints.

    Order follows pipeline_config computed_constants_order:
      1.  OD_TODAY       ← R18
      2.  OD_SOBHA       ← R18
      3.  OD_SINIYA      ← R18
      4.  OD_DT          ← R18
      5.  SNAPSHOT_DATE  ← R18 metadata
      6.  PIPELINE_GROSS ← R36
      7.  PIPELINE_ADV_DENOM ← R36 derived
      8.  CY_ADV_MIX_YTD ← R08 (computed ONCE — never per-submodule)
      9.  AVG_ADVANCE_LEAD_DAYS ← R08
      10. DAILY_DAYS     ← R04
    """
    computed: dict = {}

    # ── R18: OD constants ──────────────────────────────────────────────────
    r18 = sources.get("R18", {})
    r18_aggs = r18.get("aggs", {})

    # Batch 1 hierarchy: Group -> Sobha(Sobha Dubai, Sobha AUH) + UAQ(Siniya, Downtown UAQ)
    computed["OD_SOBHA_DUBAI"] = r18_aggs.get("OD_SOBHA_DUBAI")
    computed["OD_SOBHA_AUH"] = r18_aggs.get("OD_SOBHA_AUH")
    computed["OD_SOBHA"] = r18_aggs.get("OD_SOBHA")
    computed["OD_SINIYA"] = r18_aggs.get("OD_SINIYA")
    computed["OD_DOWNTOWN_UAQ"] = r18_aggs.get("OD_DOWNTOWN_UAQ")
    computed["OD_DT"] = r18_aggs.get("OD_DT") or computed.get("OD_DOWNTOWN_UAQ")  # backward-compatible alias
    computed["OD_UAQ"] = r18_aggs.get("OD_UAQ")
    computed["OD_GROUP"] = r18_aggs.get("OD_GROUP")
    computed["OD_TODAY"] = r18_aggs.get("OD_TODAY")

    # No silent fallback for Board/CXO trust layer. If R18 is missing, expose unavailable state.
    if computed["OD_TODAY"] is None:
        computed["OD_SOURCE"] = "unavailable"
        computed["OD_CONFIDENCE"] = "unavailable"
        computed["OD_FALLBACK_POLICY"] = "no_silent_fallback"
        logger.warning("R18 unavailable — OD metrics marked unavailable; no silent fallback applied")
    else:
        computed["OD_SOURCE"] = "R18_live"
        adapter_status = r18.get("adapter_status")
        computed["OD_CONFIDENCE"] = "live_validated" if adapter_status == "ok" else "live_warning"
        computed["OD_FALLBACK_POLICY"] = "live_or_labelled_unavailable"

    computed["OD_LINEAGE"] = r18.get("lineage", {})
    computed["OD_VALIDATIONS"] = r18.get("validations", {})

    # SNAPSHOT_DATE
    computed["SNAPSHOT_DATE"] = r18_aggs.get("SNAPSHOT_DATE") or r18.get("data_date")

    # OD ageing buckets
    computed["OD_AGEING"] = {
        "0-30d":    r18_aggs.get("ageing_0_30"),
        "31-60d":   r18_aggs.get("ageing_31_60"),
        "61-90d":   r18_aggs.get("ageing_61_90"),
        "91-120d":  r18_aggs.get("ageing_91_120"),
        "121-180d": r18_aggs.get("ageing_121_180"),
        "180+d":    r18_aggs.get("ageing_180plus"),
    }
    # No silent ageing fallback in Batch 1. Missing ageing buckets remain None and are
    # explained through OD_VALIDATIONS / OD_LINEAGE in the trust layer.

    # ── R36: Pipeline constants ────────────────────────────────────────────
    r36 = sources.get("R36", {})
    r36_aggs = r36.get("aggs", {})

    computed["PIPELINE_GROSS"] = r36_aggs.get("PIPELINE_GROSS")
    computed["PIPELINE_TOTAL_FORWARD_CALENDAR"] = r36_aggs.get("PIPELINE_TOTAL_FORWARD_CALENDAR")
    computed["PIPELINE_ACTIVE_TOTAL_PURCHASE_PRICE"] = r36_aggs.get("PIPELINE_ACTIVE_TOTAL_PURCHASE_PRICE")
    computed["PIPELINE_TOTAL_PURCHASE_PRICE"] = r36_aggs.get("PIPELINE_TOTAL_PURCHASE_PRICE")
    computed["FORWARD_COLLECTIBLE_CALENDAR"] = r36_aggs.get("FORWARD_COLLECTIBLE_CALENDAR") or {}
    computed["TOTAL_FORWARD_COLLECTIBLE_CALENDAR"] = r36_aggs.get("TOTAL_FORWARD_COLLECTIBLE_CALENDAR") or {}
    computed["R36_ENTITY_TOTALS"] = r36_aggs.get("R36_ENTITY_TOTALS") or {}
    computed["R36_LINEAGE"] = r36.get("lineage", {})
    computed["R36_VALIDATIONS"] = r36.get("validations", {})
    if computed["PIPELINE_GROSS"] is None:
        computed["PIPELINE_SOURCE"] = "unavailable_no_silent_fallback"
        computed["PIPELINE_CONFIDENCE"] = "unavailable"
        logger.warning("R36 unavailable — pipeline metrics marked unavailable; no silent fallback applied")
    else:
        computed["PIPELINE_SOURCE"] = "R36_live"
        computed["PIPELINE_CONFIDENCE"] = "live_validated" if r36.get("adapter_status") == "ok" else "live_warning"

    # Labels — always attached, never display pipeline figure without label
    computed["PIPELINE_GROSS_LABEL"]        = r36_aggs.get("PIPELINE_GROSS_LABEL") or C.PIPELINE_GROSS_LABEL
    computed["PIPELINE_ADV_DENOM_LABEL"]    = C.PIPELINE_ADV_DENOM_LABEL
    computed["PIPELINE_FORWARD_BOOK_LABEL"] = C.PIPELINE_FORWARD_BOOK_LABEL

    # ── R08: Advance constants ─────────────────────────────────────────────
    r08 = sources.get("R08", {})
    r08_aggs = r08.get("aggs", {})

    # CY_ADV_MIX_YTD — computed ONCE here, NEVER per-submodule.
    # Batch 3: no silent fallback for Board/CXO trust layer.
    computed["CY_ADV_MIX_YTD"] = r08_aggs.get("CY_ADV_MIX_YTD")
    computed["FY_ADV_MIX_YTD"] = r08_aggs.get("FY_ADV_MIX_YTD")
    computed["ADVANCE_2026_TOTAL"] = r08_aggs.get("ADVANCE_2026_TOTAL")
    computed["ADVANCE_2026_CY"] = r08_aggs.get("ADVANCE_2026_CY")
    computed["ADVANCE_2026_FY"] = r08_aggs.get("ADVANCE_2026_FY")
    if computed["CY_ADV_MIX_YTD"] is None:
        computed["R08_SOURCE"] = "unavailable_no_silent_fallback"
        computed["R08_CONFIDENCE"] = "unavailable"
        logger.warning("R08 unavailable — CY/FY advance mix marked unavailable; no silent fallback applied")
    else:
        computed["R08_SOURCE"] = "R08_live"
        computed["R08_CONFIDENCE"] = "live_validated" if r08.get("adapter_status") == "ok" else "live_warning"

    computed["AVG_ADVANCE_LEAD_DAYS"] = r08_aggs.get("AVG_ADVANCE_LEAD_DAYS")
    computed["AVG_ADVANCE_LEAD_DAYS_STATUS"] = "live" if computed["AVG_ADVANCE_LEAD_DAYS"] is not None else "unavailable_in_batch3_no_silent_fallback"
    computed["ADVANCE_2025_TOTAL"]    = r08_aggs.get("advance_2025_total")
    computed["YTD_2026_REBATE"]       = r08_aggs.get("ytd_2026_rebate")
    computed["YTD_2026_REBATE_ESTIMATED"] = r08_aggs.get("ytd_2026_rebate_estimated")
    computed["YTD_2026_ADVANCE_WITH_REBATES"] = r08_aggs.get("ytd_2026_advance_with_rebates")
    computed["YTD_2026_ADVANCE"]      = r08_aggs.get("ytd_2026_advance")
    computed["ADVANCE_2026_SOBHA_PARENT_TOTAL"] = r08_aggs.get("advance_2026_sobha_parent_total")
    computed["ADVANCE_2026_SINIYA_TOTAL"] = r08_aggs.get("advance_2026_siniya_total")
    computed["ADVANCE_2026_DOWNTOWN_UAQ_TOTAL"] = r08_aggs.get("advance_2026_downtown_uaq_total")
    computed["ADVANCE_2026_UAQ_TOTAL"] = r08_aggs.get("advance_2026_uaq_total")
    computed["R08_LINEAGE"] = r08.get("lineage", {})
    computed["R08_VALIDATIONS"] = r08.get("validations", {})

    # ── R04: Daily arrays ─────────────────────────────────────────────────
    r04 = sources.get("R04", {})
    r04_aggs = r04.get("aggs", {})

    # DAILY_DAYS — single shared array, replaces 4 v5 duplicate declarations
    # Batch 2: R04 is Finance basis. "Collection Due" is treated as Finance D+A / collection-due.
    computed["DAILY_DAYS"] = r04_aggs.get("DAILY_DAYS") or []
    computed["DAILY_FINANCE_DA_SERIES"] = r04_aggs.get("DAILY_FINANCE_DA_SERIES") or []
    computed["DAILY_NEW_SALES_SERIES"] = r04_aggs.get("DAILY_NEW_SALES_SERIES") or []
    computed["DAILY_TOTAL_COLLECTIONS_SERIES"] = r04_aggs.get("DAILY_TOTAL_COLLECTIONS_SERIES") or []
    computed["MTD_DA_TOTAL"]    = r04_aggs.get("mtd_da_total")
    computed["MTD_DUES_TOTAL"]  = r04_aggs.get("mtd_dues_total")  # compatibility alias for Finance D+A/collection-due
    computed["MTD_ADV_TOTAL"]   = r04_aggs.get("mtd_advance_total")
    computed["MTD_ADV_STATUS"]  = r04_aggs.get("mtd_advance_status")
    computed["MTD_NS_TOTAL"]    = r04_aggs.get("mtd_ns_total")
    computed["MTD_TOTAL_COLLECTIONS"] = r04_aggs.get("mtd_total_collections")
    computed["MTD_DLD_OQOOD_TOTAL"] = r04_aggs.get("mtd_dld_oqood_total")
    computed["R04_LINEAGE"] = r04.get("lineage", {})
    computed["R04_VALIDATIONS"] = r04.get("validations", {})
    computed["R04_REPORTING_BASIS"] = "Finance"

    # ── R02: MDO targets ──────────────────────────────────────────────────
    r02 = sources.get("R02", {})
    r02_aggs = r02.get("aggs", {})

    computed["FY_DUES_TARGET"]    = r02_aggs.get("fy_dues_target_group") or C.MDO_DUES_FY_2026_AED
    computed["FY_ADV_TARGET"]     = r02_aggs.get("fy_advance_target_group") or C.MDO_ADV_FY_2026_AED
    computed["FY_DA_TARGET"]      = r02_aggs.get("fy_da_target_group")
    computed["FY_NEW_SALES_TARGET"] = r02_aggs.get("fy_new_sales_target_group")
    computed["FY_TOTAL_COLLECTIONS_TARGET"] = r02_aggs.get("fy_total_collections_target_group")
    computed["MAY_DUES_TARGET"]   = r02_aggs.get("may_dues_target_group")
    computed["MAY_ADV_TARGET"]    = r02_aggs.get("may_advance_target_group")
    computed["MAY_DA_TARGET"]     = r02_aggs.get("may_da_target_group")
    computed["MAY_NEW_SALES_TARGET"] = r02_aggs.get("may_new_sales_target_group")
    computed["MAY_TOTAL_COLLECTIONS_TARGET"] = r02_aggs.get("may_total_collections_target_group")
    computed["MAY_DUES_ACTUAL_MDO"] = r02_aggs.get("may_dues_actual_group")
    computed["MAY_ADV_ACTUAL_MDO"] = r02_aggs.get("may_advance_actual_group")
    computed["MAY_DA_ACTUAL_MDO"] = r02_aggs.get("may_da_actual_group")
    computed["MAY_NEW_SALES_ACTUAL_MDO"] = r02_aggs.get("may_new_sales_actual_group")
    computed["MAY_TOTAL_COLLECTIONS_ACTUAL_MDO"] = r02_aggs.get("may_total_collections_actual_group")
    computed["Q1_DUES_ACTUAL"]    = r02_aggs.get("q1_dues_actual_group")
    computed["Q1_ADV_ACTUAL"]     = r02_aggs.get("q1_advance_actual_group")
    computed["R02_LINEAGE"] = r02.get("lineage", {})
    computed["R02_VALIDATIONS"] = r02.get("validations", {})
    computed["R02_REPORTING_BASIS"] = "MDO"

    # ── R13: ITD portfolio ────────────────────────────────────────────────
    r13 = sources.get("R13", {})
    r13_aggs = r13.get("aggs", {})

    computed["GROUP_SALE_VALUE_ITD"] = (
        r13_aggs.get("group_sale_value_itd") or C.GROUP_SALE_VALUE_ITD_AED
    )
    computed["GROUP_COLLECTED_ITD"] = (
        r13_aggs.get("group_collected_itd") or C.GROUP_COLLECTED_ITD_AED
    )

    # ── R10: Coverage ─────────────────────────────────────────────────────
    r10 = sources.get("R10", {})
    r10_aggs = r10.get("aggs", {})

    computed["SINIYA_UNWORKED_POOL"] = (
        r10_aggs.get("siniya_unworked_pool_aed") or C.SINIYA_UNWORKED_POOL_AED
    )

    # ── R30: Collector metrics ────────────────────────────────────────────
    r30 = sources.get("R30", {})
    r30_aggs = r30.get("aggs", {})

    computed["COLLECTOR_TEAM_AVG_ACH"] = r30_aggs.get("team_avg_achievement")
    computed["COLLECTOR_TOTAL_ACTUAL"] = r30_aggs.get("total_actual")
    computed["COLLECTOR_TOTAL_TARGET"] = r30_aggs.get("total_target")

    # ── R26: LP / charges ─────────────────────────────────────────────────
    r26 = sources.get("R26", {})
    r26_aggs = r26.get("aggs", {})

    computed["LP_2021"] = r26_aggs.get("lp_2021")
    computed["LP_2025"] = r26_aggs.get("lp_2025")
    computed["DLD_2026_YTD"] = r26_aggs.get("dld_2026_ytd")

    # ── R34: Termination gap ──────────────────────────────────────────────
    r34 = sources.get("R34", {})
    r34_aggs = r34.get("aggs", {})

    computed["TERM_NOT_IN_SYSTEM"]  = (
        r34_aggs.get("latest_not_in_system") or C.TERMINATION_GAP_UNITS
    )
    computed["TERM_GAP_EXPOSURE"]   = (
        r34_aggs.get("latest_gap_exposure") or C.TERMINATION_GAP_EXPOSURE_AED
    )

    # ── R38: Risk / IC threshold ──────────────────────────────────────────
    r38 = sources.get("R38", {})
    r38_aggs = r38.get("aggs", {})

    computed["IC_BAND_0_10_UNITS"]    = (
        r38_aggs.get("ic_band_0_10_units") or C.IC_THRESHOLD_UNITS
    )
    computed["IC_BAND_0_10_EXPOSURE"] = (
        r38_aggs.get("ic_band_0_10_exposure") or C.IC_THRESHOLD_EXPOSURE_AED
    )

    # ── Resolve derived constants ──────────────────────────────────────────
    computed = _resolve_derived_constants(computed)

    # ── Data currency metadata ─────────────────────────────────────────────
    computed["LOAD_TIMESTAMP"] = datetime.utcnow().isoformat()
    computed["PLATFORM_VERSION"] = C.PLATFORM_VERSION

    return computed


# ---------------------------------------------------------------------------
# SECTION 8 — LEAN SUMMARY BUILDER (~100KB target)
# ---------------------------------------------------------------------------

def _build_summary(sources: dict, computed: dict) -> dict:
    """
    Build the pre-aggregated lean summary JSON for frontend consumption.
    Target: ~100KB total. Contains formatted display values + chart arrays.
    Raw rows are NOT included here — endpoints access them via `dataframes`.
    """
    summary: dict = {
        "meta": {
            "snapshot_date": computed.get("SNAPSHOT_DATE"),
            "load_timestamp": computed.get("LOAD_TIMESTAMP"),
            "platform_version": computed.get("PLATFORM_VERSION"),
            "sources_loaded": [
                rid for rid, s in sources.items() if s.get("status") == "ok"
            ],
            "sources_missing": [
                rid for rid, s in sources.items() if s.get("status") == "missing"
            ],
        },

        # ── Portfolio headline KPIs ──
        "portfolio": {
            "group_sale_value_itd":    computed.get("GROUP_SALE_VALUE_ITD"),
            "group_collected_itd":     computed.get("GROUP_COLLECTED_ITD"),
            "group_collected_itd_pct": U.safe_divide(
                computed.get("GROUP_COLLECTED_ITD") or 0,
                computed.get("GROUP_SALE_VALUE_ITD") or 1
            ) * 100,
            "od_today":  computed.get("OD_TODAY"),
            "od_group":  computed.get("OD_GROUP"),
            "od_sobha":  computed.get("OD_SOBHA"),
            "od_sobha_dubai": computed.get("OD_SOBHA_DUBAI"),
            "od_sobha_auh":   computed.get("OD_SOBHA_AUH"),
            "od_uaq":    computed.get("OD_UAQ"),
            "od_siniya": computed.get("OD_SINIYA"),
            "od_downtown_uaq": computed.get("OD_DOWNTOWN_UAQ"),
            "od_dt":     computed.get("OD_DT"),
            "od_source": computed.get("OD_SOURCE"),
            "od_confidence": computed.get("OD_CONFIDENCE"),
            "od_fallback_policy": computed.get("OD_FALLBACK_POLICY"),
            "od_ageing": computed.get("OD_AGEING"),
            "od_validations": computed.get("OD_VALIDATIONS"),
            "od_lineage": computed.get("OD_LINEAGE"),
            "pipeline_gross":      computed.get("PIPELINE_GROSS"),
            "pipeline_gross_label": computed.get("PIPELINE_GROSS_LABEL"),
            "pipeline_adv_denom":      computed.get("PIPELINE_ADV_DENOM"),
            "pipeline_adv_denom_label": computed.get("PIPELINE_ADV_DENOM_LABEL"),
            "pipeline_forward_book":      computed.get("PIPELINE_FORWARD_BOOK"),
            "pipeline_forward_book_label": computed.get("PIPELINE_FORWARD_BOOK_LABEL"),
            "pipeline_source": computed.get("PIPELINE_SOURCE"),
            "pipeline_confidence": computed.get("PIPELINE_CONFIDENCE"),
            "pipeline_total_forward_calendar": computed.get("PIPELINE_TOTAL_FORWARD_CALENDAR"),
            "pipeline_active_total_purchase_price": computed.get("PIPELINE_ACTIVE_TOTAL_PURCHASE_PRICE"),
            "pipeline_total_purchase_price": computed.get("PIPELINE_TOTAL_PURCHASE_PRICE"),
            "forward_collectible_calendar": computed.get("FORWARD_COLLECTIBLE_CALENDAR"),
            "r36_entity_totals": computed.get("R36_ENTITY_TOTALS"),
            "r36_lineage": computed.get("R36_LINEAGE"),
            "r36_validations": computed.get("R36_VALIDATIONS"),
        },

        # ── Advance KPIs ──
        "advance": {
            "source": computed.get("R08_SOURCE"),
            "confidence": computed.get("R08_CONFIDENCE"),
            "cy_adv_mix_ytd":        computed.get("CY_ADV_MIX_YTD"),
            "fy_adv_mix_ytd":        computed.get("FY_ADV_MIX_YTD"),
            "avg_advance_lead_days": computed.get("AVG_ADVANCE_LEAD_DAYS"),
            "avg_advance_lead_days_status": computed.get("AVG_ADVANCE_LEAD_DAYS_STATUS"),
            "advance_2025_total":    computed.get("ADVANCE_2025_TOTAL"),
            "advance_2026_total":    computed.get("ADVANCE_2026_TOTAL"),
            "advance_2026_cy":       computed.get("ADVANCE_2026_CY"),
            "advance_2026_fy":       computed.get("ADVANCE_2026_FY"),
            "advance_2026_sobha_parent_total": computed.get("ADVANCE_2026_SOBHA_PARENT_TOTAL"),
            "advance_2026_siniya_total": computed.get("ADVANCE_2026_SINIYA_TOTAL"),
            "advance_2026_downtown_uaq_total": computed.get("ADVANCE_2026_DOWNTOWN_UAQ_TOTAL"),
            "advance_2026_uaq_total": computed.get("ADVANCE_2026_UAQ_TOTAL"),
            "ytd_2026_rebate":       computed.get("YTD_2026_REBATE"),
            "ytd_2026_rebate_estimated": computed.get("YTD_2026_REBATE_ESTIMATED"),
            "ytd_2026_advance_with_rebates": computed.get("YTD_2026_ADVANCE_WITH_REBATES"),
            "ytd_2026_advance":      computed.get("YTD_2026_ADVANCE"),
            "lineage": computed.get("R08_LINEAGE"),
            "validations": computed.get("R08_VALIDATIONS"),
        },

        # ── MDO targets ──
        "targets": {
            "reporting_basis": computed.get("R02_REPORTING_BASIS"),
            "fy_dues_target":  computed.get("FY_DUES_TARGET"),
            "fy_adv_target":   computed.get("FY_ADV_TARGET"),
            "fy_da_target":    computed.get("FY_DA_TARGET"),
            "fy_new_sales_target": computed.get("FY_NEW_SALES_TARGET"),
            "fy_total_collections_target": computed.get("FY_TOTAL_COLLECTIONS_TARGET"),
            "may_dues_target": computed.get("MAY_DUES_TARGET"),
            "may_adv_target":  computed.get("MAY_ADV_TARGET"),
            "may_da_target":   computed.get("MAY_DA_TARGET"),
            "may_new_sales_target": computed.get("MAY_NEW_SALES_TARGET"),
            "may_total_collections_target": computed.get("MAY_TOTAL_COLLECTIONS_TARGET"),
            "may_dues_actual_mdo": computed.get("MAY_DUES_ACTUAL_MDO"),
            "may_adv_actual_mdo": computed.get("MAY_ADV_ACTUAL_MDO"),
            "may_da_actual_mdo": computed.get("MAY_DA_ACTUAL_MDO"),
            "may_new_sales_actual_mdo": computed.get("MAY_NEW_SALES_ACTUAL_MDO"),
            "may_total_collections_actual_mdo": computed.get("MAY_TOTAL_COLLECTIONS_ACTUAL_MDO"),
            "q1_dues_actual":  computed.get("Q1_DUES_ACTUAL"),
            "q1_adv_actual":   computed.get("Q1_ADV_ACTUAL"),
            "lineage": computed.get("R02_LINEAGE"),
            "validations": computed.get("R02_VALIDATIONS"),
        },

        # ── Daily arrays (S03 MTD charts) ──
        "daily": {
            "reporting_basis": computed.get("R04_REPORTING_BASIS"),
            "days":         computed.get("DAILY_DAYS"),
            "finance_da_series": computed.get("DAILY_FINANCE_DA_SERIES"),
            "new_sales_series": computed.get("DAILY_NEW_SALES_SERIES"),
            "total_collections_series": computed.get("DAILY_TOTAL_COLLECTIONS_SERIES"),
            "mtd_da":       computed.get("MTD_DA_TOTAL"),
            "mtd_dues":     computed.get("MTD_DUES_TOTAL"),
            "mtd_advance":  computed.get("MTD_ADV_TOTAL"),
            "mtd_advance_status": computed.get("MTD_ADV_STATUS"),
            "mtd_ns":       computed.get("MTD_NS_TOTAL"),
            "mtd_total_collections": computed.get("MTD_TOTAL_COLLECTIONS"),
            "mtd_dld_oqood": computed.get("MTD_DLD_OQOOD_TOTAL"),
            "lineage": computed.get("R04_LINEAGE"),
            "validations": computed.get("R04_VALIDATIONS"),
        },

        # ── Operational KPIs ──
        "ops": {
            "collector_team_avg_ach": computed.get("COLLECTOR_TEAM_AVG_ACH"),
            "siniya_unworked_pool":   computed.get("SINIYA_UNWORKED_POOL"),
            "term_not_in_system":     computed.get("TERM_NOT_IN_SYSTEM"),
            "term_gap_exposure":      computed.get("TERM_GAP_EXPOSURE"),
            "ic_band_0_10_units":     computed.get("IC_BAND_0_10_UNITS"),
            "ic_band_0_10_exposure":  computed.get("IC_BAND_0_10_EXPOSURE"),
        },

        # ── Charges signals ──
        "charges": {
            "lp_2021":     computed.get("LP_2021"),
            "lp_2025":     computed.get("LP_2025"),
            "dld_2026_ytd": computed.get("DLD_2026_YTD"),
        },

        # ── Collector snapshot top/bottom (from R30) ──
        "collectors": _build_collector_summary(sources),
    }

    return summary


def _build_collector_summary(sources: dict) -> dict:
    """Extract top 3 / bottom 3 collectors from R30 rows for KPI_STRIP."""
    r30 = sources.get("R30", {})
    rows = r30.get("rows", [])
    if not rows:
        return {"top": [], "bottom": [], "count": C.COLLECTOR_COUNT}

    # Already sorted DESC by achievement_pct in _load_source post_load
    formatted = [
        {
            "name":           r.get("collector_name"),
            "achievement_pct": r.get("achievement_pct"),
            "actual_aed":     r.get("actual_aed"),
            "target_aed":     r.get("target_aed"),
        }
        for r in rows if r.get("collector_name")
    ]

    return {
        "top":    formatted[:3],
        "bottom": formatted[-3:] if len(formatted) >= 3 else formatted,
        "count":  len(formatted),
        "data_currency": C.SNAPSHOT_LABEL,
    }


# ---------------------------------------------------------------------------
# SECTION 9 — MAIN ENTRY POINT
# ---------------------------------------------------------------------------

def load_all(data_dir: Optional[Path] = None) -> dict:
    """
    Main entry point. Load all active R-series sources, build computed dict,
    build lean summary. Called by FastAPI on startup and on health-check refresh.

    Args:
        data_dir: Override /data directory path (used in testing).

    Returns:
        {
            "dataframes": { "R18": {"rows": [...], "aggs": {...}}, ... },
            "computed":   { "OD_TODAY": 1650100000, ... },
            "summary":    { "portfolio": {...}, "advance": {...}, ... },
            "status":     "ok" | "partial" | "degraded"
        }
    """
    global DATA_DIR
    if data_dir:
        DATA_DIR = data_dir

    active_data_dir = data_dir if data_dir else DATA_DIR
    cfg = _load_pipeline_config()
    sources_cfg = cfg.get("sources", {})
    load_priority = cfg.get("load_priority", {})

    # Build ordered load sequence from priority tiers
    ordered_ids: list[str] = []
    for tier in ("1_critical", "2_high", "3_standard", "4_advisory"):
        ordered_ids.extend(load_priority.get(tier, []))
    # Add any not covered by priority list
    for rid in sources_cfg:
        if rid not in ordered_ids:
            ordered_ids.append(rid)

    # Resolve R-series files by prefix matching
    resolved_files = file_resolver.resolve_r_series(str(active_data_dir))

    # Load sources
    sources: dict = {}
    for rid in ordered_ids:
        if rid not in sources_cfg:
            continue
        logger.debug("Loading %s ...", rid)
        sources[rid] = _load_source(rid, sources_cfg[rid], data_dir=active_data_dir, resolved_files=resolved_files)

    # Build computed dict
    computed = _build_computed(sources)

    # Build lean summary
    summary = _build_summary(sources, computed)

    # Determine overall status
    missing = [rid for rid, s in sources.items() if s.get("status") == "missing"]
    critical = set(load_priority.get("1_critical", []))
    critical_missing = [rid for rid in missing if rid in critical]

    if critical_missing:
        status = "degraded"
        logger.warning("Critical sources missing: %s — platform in degraded mode", critical_missing)
    elif missing:
        status = "partial"
        logger.info("Non-critical sources missing: %s — platform operating normally", missing)
    else:
        status = "ok"

    logger.info(
        "Data load complete. Status=%s. Sources: %d ok / %d missing.",
        status, len(sources) - len(missing), len(missing)
    )

    return {
        "dataframes": sources,
        "computed":   computed,
        "summary":    summary,
        "status":     status,
        "missing_sources": missing,
    }


def get_cached_payload(
    data_dir: Optional[Path | str] = None,
    *,
    force_refresh: bool = False,
    ttl_seconds: Optional[int] = None,
    copy_payload: bool = False,
) -> dict:
    """Return the trusted data loader payload using a short in-memory cache.

    This is the performance-critical entry point for FastAPI endpoints. It keeps
    Quickball, command centres, and forecast from reparsing every Excel workbook
    on each click or role change. The payload still contains the original
    lineage, validation status, confidence state and missing-source disclosure.

    Set SCIP_DATA_CACHE_TTL_SECONDS=0 to disable caching. Use force_refresh=True
    only for an explicit source-refresh action, not for role switch or Quickball.
    """
    global _DATA_CACHE_PAYLOAD, _DATA_CACHE_LOADED_AT, _DATA_CACHE_DIR
    global _DATA_CACHE_HITS, _DATA_CACHE_MISSES

    active_dir = _resolve_active_data_dir(data_dir)
    cache_dir = str(active_dir)
    ttl = _cache_ttl_seconds() if ttl_seconds is None else int(ttl_seconds)
    now = time.time()

    if ttl > 0 and not force_refresh:
        with _DATA_CACHE_LOCK:
            is_valid = (
                _DATA_CACHE_PAYLOAD is not None
                and _DATA_CACHE_LOADED_AT is not None
                and _DATA_CACHE_DIR == cache_dir
                and now - _DATA_CACHE_LOADED_AT <= ttl
            )
            if is_valid:
                _DATA_CACHE_HITS += 1
                logger.debug("SCIP data cache hit: dir=%s age=%.2fs", cache_dir, now - _DATA_CACHE_LOADED_AT)
                return copy.deepcopy(_DATA_CACHE_PAYLOAD) if copy_payload else _DATA_CACHE_PAYLOAD

    with _DATA_CACHE_LOCK:
        now = time.time()
        if ttl > 0 and not force_refresh:
            is_valid = (
                _DATA_CACHE_PAYLOAD is not None
                and _DATA_CACHE_LOADED_AT is not None
                and _DATA_CACHE_DIR == cache_dir
                and now - _DATA_CACHE_LOADED_AT <= ttl
            )
            if is_valid:
                _DATA_CACHE_HITS += 1
                logger.debug("SCIP data cache hit after lock: dir=%s", cache_dir)
                return copy.deepcopy(_DATA_CACHE_PAYLOAD) if copy_payload else _DATA_CACHE_PAYLOAD

        _DATA_CACHE_MISSES += 1
        logger.info("SCIP data cache miss; loading source payload: dir=%s force_refresh=%s", cache_dir, force_refresh)
        payload = load_all(data_dir=active_dir)
        if ttl > 0:
            _DATA_CACHE_PAYLOAD = payload
            _DATA_CACHE_LOADED_AT = time.time()
            _DATA_CACHE_DIR = cache_dir
        return copy.deepcopy(payload) if copy_payload else payload


def invalidate_cache() -> None:
    """Clear the in-memory data payload cache."""
    global _DATA_CACHE_PAYLOAD, _DATA_CACHE_LOADED_AT, _DATA_CACHE_DIR
    with _DATA_CACHE_LOCK:
        _DATA_CACHE_PAYLOAD = None
        _DATA_CACHE_LOADED_AT = None
        _DATA_CACHE_DIR = None


def get_cache_status() -> dict:
    now = time.time()
    age = None if _DATA_CACHE_LOADED_AT is None else round(now - _DATA_CACHE_LOADED_AT, 3)
    return {
        "status": "warm" if _DATA_CACHE_PAYLOAD is not None else "cold",
        "data_dir": _DATA_CACHE_DIR,
        "loaded_at_epoch": _DATA_CACHE_LOADED_AT,
        "age_seconds": age,
        "ttl_seconds": _cache_ttl_seconds(),
        "hits": _DATA_CACHE_HITS,
        "misses": _DATA_CACHE_MISSES,
        "lineage_preserved": True,
        "no_silent_fallback": True,
    }


def get_source_rows(payload: dict, source_id: str) -> list[dict]:
    """
    Helper for endpoint functions to extract rows from a loaded source.
    Returns empty list (not crash) if source unavailable.

    Args:
        payload:    Result of load_all()
        source_id:  e.g. "R18"
    """
    return payload.get("dataframes", {}).get(source_id, {}).get("rows", [])


def get_computed(payload: dict, key: str, fallback: Any = None) -> Any:
    """
    Helper for endpoint functions to read a computed constant.
    Returns fallback if key absent.

    Args:
        payload:  Result of load_all()
        key:      e.g. "OD_TODAY"
        fallback: Default if key not found
    """
    return payload.get("computed", {}).get(key, fallback)
```


---

## `SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/Backend/file_resolver.py`


```python
"""
file_resolver.py - R-series File Resolver for SCIP Backend

Scans the /data directory and matches files by R-code prefix.
Allows team to use natural filenames like:
    R18_Consolidated and Overdue 01-05-26.xlsx
    R08_Advance Summary 06-05-2026.xlsx
    R04_Total Daily Collection Report 07-05-2026.xlsx

Rules:
    - .xlsx files are matched for openpyxl-backed adapters; .xlsb is detected for future adapters only
    - One file per R-code in /data at any time (recommended)
    - If multiple files share the same R-code prefix, picks
      the one that sorts last alphabetically (latest date)
    - Missing R-code = None = graceful degradation
    - Non-xlsx files and Excel temp files (~$) silently ignored

Imports: os, re, logging only. No external dependencies.
Called by: data_loader.py
Position: constants.py > utils.py > file_resolver.py > data_loader.py
"""

import os
import re
import logging

logger = logging.getLogger(__name__)

VALID_R_CODES = {
    "R01", "R02", "R03", "R04", "R05", "R06", "R07", "R08", "R09",
    "R10", "R12", "R13", "R16", "R17", "R18", "R20", "R25", "R26",
    "R27", "R28", "R29", "R30", "R31", "R32", "R34", "R35", "R36",
    "R37", "R38"
}

R_CODE_PATTERN = re.compile(r"^(R\d{1,2})(?:[_\s-].*)?\.(xlsx|xlsb)$", re.IGNORECASE)


def resolve_r_series(data_dir):
    resolved = {}
    duplicates = {}

    if not os.path.isdir(data_dir):
        logger.warning("Data directory not found: %s", data_dir)
        return resolved

    for filename in os.listdir(data_dir):
        if not filename.lower().endswith((".xlsx", ".xlsb")):
            continue
        if filename.startswith("~$") or filename.startswith("."):
            continue

        match = R_CODE_PATTERN.match(filename)
        if not match:
            logger.info("Skipping unrecognised file: %s", filename)
            continue

        r_code = match.group(1).upper()

        if r_code not in VALID_R_CODES:
            logger.info("Skipping unknown R-code: %s (%s)", r_code, filename)
            continue

        full_path = os.path.join(data_dir, filename)

        if r_code in resolved:
            if r_code not in duplicates:
                duplicates[r_code] = [os.path.basename(resolved[r_code])]
            duplicates[r_code].append(filename)
            existing = os.path.basename(resolved[r_code])
            if filename > existing:
                resolved[r_code] = full_path
        else:
            resolved[r_code] = full_path

    for r_code, files in duplicates.items():
        logger.warning(
            "Multiple files for %s: %s. Using: %s.",
            r_code, files, os.path.basename(resolved[r_code])
        )

    found = sorted(resolved.keys())
    missing = sorted(VALID_R_CODES - set(found))
    logger.info("Resolved %d/%d R-series files: %s",
                len(found), len(VALID_R_CODES), found)
    if missing:
        logger.info("Missing (graceful degradation): %s", missing)

    return resolved


def get_file_for_code(resolved, r_code):
    return resolved.get(r_code.upper())


def get_snapshot_date_from_filename(resolved, r_code):
    filepath = resolved.get(r_code.upper())
    if not filepath:
        return None
    filename = os.path.basename(filepath)

    m = re.search(r"(\d{2})-(\d{2})-(\d{2})(?!\d)", filename)
    if m:
        day, month, year = m.groups()
        year_full = "20" + year if int(year) < 50 else "19" + year
        return "{}-{}-{}".format(year_full, month, day)

    m = re.search(r"(\d{2})-(\d{2})-(\d{4})", filename)
    if m:
        day, month, year = m.groups()
        return "{}-{}-{}".format(year, month, day)

    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", filename)
    if m:
        return m.group(0)

    return None


def get_resolution_summary(resolved):
    found = sorted(resolved.keys())
    missing = sorted(VALID_R_CODES - set(found))
    files = {}
    for code in found:
        files[code] = {
            "filename": os.path.basename(resolved[code]),
            "snapshot_date": get_snapshot_date_from_filename(resolved, code)
        }
    return {
        "total_found": len(found),
        "total_expected": len(VALID_R_CODES),
        "status": "healthy" if len(found) >= 5 else "degraded",
        "found": found,
        "missing": missing,
        "files": files
    }
```


---

## `SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/Backend/forecast.py`


```python
"""
SCIP forecast.py - Batch 5 month-end landing forecast

Purpose
- Build a transparent month-end landing forecast using trusted Batch 1-4 metrics.
- Use R04 Finance MTD actuals and R02 May MDO targets with explicit mixed-basis disclosure.
- Require lineaged inputs for all critical values.
- Infer working-day progress from the R04 pro-rata target row when possible.

The forecast is intentionally simple and auditable:
    current_run_rate = R04 MTD total collections / elapsed working days
    projected_landing = current_run_rate * total working days
    gap_to_mdo_target = projected_landing - R02 May total collections target
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

try:
    from fastapi import APIRouter, Query
except Exception:  # pragma: no cover
    APIRouter = None
    Query = None

import data_loader

TOLERANCE_PCT = 0.05


def _to_float(value: Any) -> Optional[float]:
    try:
        if value is None:
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _fmt_aed(value: Any) -> str:
    n = _to_float(value)
    if n is None:
        return "Unavailable"
    if abs(n) >= 1_000_000_000:
        return f"AED {n / 1_000_000_000:,.3f}B"
    if abs(n) >= 1_000_000:
        return f"AED {n / 1_000_000:,.1f}M"
    return f"AED {n:,.0f}"


def _fmt_pct(value: Any) -> str:
    n = _to_float(value)
    if n is None:
        return "Unavailable"
    return f"{n:.1f}%"


def _lineage(payload: Dict[str, Any], bucket: str, key: str) -> Dict[str, Any]:
    return (payload.get("computed", {}).get(bucket, {}) or {}).get(key, {}) or {}


def _lineage_is_usable(lineage: Dict[str, Any]) -> bool:
    required = ["source_file", "sheet", "cell_or_range", "validation_status", "confidence_state", "reporting_basis"]
    return bool(lineage) and all(lineage.get(k) not in (None, "") for k in required)


def _lineage_ref(metric_key: str, bucket: str, key: str, lineage: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "metric_key": metric_key,
        "lineage_bucket": bucket,
        "lineage_key": key,
        "has_lineage": _lineage_is_usable(lineage),
        "source_file": lineage.get("source_file"),
        "sheet": lineage.get("sheet"),
        "cell_or_range": lineage.get("cell_or_range"),
        "validation_status": lineage.get("validation_status"),
        "confidence_state": lineage.get("confidence_state"),
        "reporting_basis": lineage.get("reporting_basis"),
        "value": lineage.get("value"),
    }


def _infer_working_days(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Infer elapsed/total working days from the R04 pro-rata total target ratio.

    R04 sample exposes:
      month_target_total = E5
      mtd_prorata_total_target = E6
    The ratio is expected to be elapsed_working_days / total_working_days.
    We search small denominator candidates and pick the closest fraction.
    """
    c = payload.get("computed", {})
    month_target_total = _to_float(c.get("MONTH_TARGET_TOTAL"))
    prorata_total = _to_float(c.get("MTD_PRORATA_TOTAL_TARGET"))
    # Batch 2 stored these values primarily in R04_LINEAGE, not always as top-level computed keys.
    if month_target_total is None:
        month_target_total = _to_float(_lineage(payload, "R04_LINEAGE", "month_target_total").get("value"))
    if prorata_total is None:
        prorata_total = _to_float(_lineage(payload, "R04_LINEAGE", "mtd_prorata_total_target").get("value"))

    if not month_target_total or not prorata_total:
        return {
            "status": "fallback_default",
            "elapsed_working_days": 5,
            "total_working_days": 17,
            "remaining_working_days": 12,
            "source": "default_batch5_assumption",
            "basis": "R04 pro-rata values unavailable; default must be reviewed before production release.",
        }

    ratio = prorata_total / month_target_total
    best = None
    for total in range(10, 32):
        for elapsed in range(1, total + 1):
            err = abs((elapsed / total) - ratio)
            candidate = (err, elapsed, total)
            if best is None or candidate < best:
                best = candidate

    err, elapsed, total = best
    return {
        "status": "inferred_from_r04_prorata",
        "elapsed_working_days": elapsed,
        "total_working_days": total,
        "remaining_working_days": max(total - elapsed, 0),
        "source": "R04 mtd_prorata_total_target / month_target_total",
        "ratio": ratio,
        "fraction_error": err,
        "basis": "Elapsed and total working days inferred from visible R04 MTD pro-rata target row.",
        "lineage_refs": [
            _lineage_ref("MONTH_TARGET_TOTAL", "R04_LINEAGE", "month_target_total", _lineage(payload, "R04_LINEAGE", "month_target_total")),
            _lineage_ref("MTD_PRORATA_TOTAL_TARGET", "R04_LINEAGE", "mtd_prorata_total_target", _lineage(payload, "R04_LINEAGE", "mtd_prorata_total_target")),
        ],
    }


def build_month_end_forecast(payload: Dict[str, Any]) -> Dict[str, Any]:
    c = payload.get("computed", {})

    mtd_total = _to_float(c.get("MTD_TOTAL_COLLECTIONS"))
    mtd_da = _to_float(c.get("MTD_DA_TOTAL"))
    mtd_ns = _to_float(c.get("MTD_NS_TOTAL"))
    may_target = _to_float(c.get("MAY_TOTAL_COLLECTIONS_TARGET"))
    may_da_target = _to_float(c.get("MAY_DA_TARGET"))
    may_ns_target = _to_float(c.get("MAY_NEW_SALES_TARGET"))

    input_lineage = {
        "mtd_total_collections": _lineage(payload, "R04_LINEAGE", "mtd_total_collections"),
        "mtd_da_total": _lineage(payload, "R04_LINEAGE", "mtd_da_total"),
        "mtd_ns_total": _lineage(payload, "R04_LINEAGE", "mtd_ns_total"),
        "may_total_collections_target": _lineage(payload, "R02_LINEAGE", "may_total_collections_target_group"),
        "may_da_target": _lineage(payload, "R02_LINEAGE", "may_da_target_group"),
        "may_new_sales_target": _lineage(payload, "R02_LINEAGE", "may_new_sales_target_group"),
    }
    lineage_refs = [
        _lineage_ref("MTD_TOTAL_COLLECTIONS", "R04_LINEAGE", "mtd_total_collections", input_lineage["mtd_total_collections"]),
        _lineage_ref("MTD_DA_TOTAL", "R04_LINEAGE", "mtd_da_total", input_lineage["mtd_da_total"]),
        _lineage_ref("MTD_NS_TOTAL", "R04_LINEAGE", "mtd_ns_total", input_lineage["mtd_ns_total"]),
        _lineage_ref("MAY_TOTAL_COLLECTIONS_TARGET", "R02_LINEAGE", "may_total_collections_target_group", input_lineage["may_total_collections_target"]),
        _lineage_ref("MAY_DA_TARGET", "R02_LINEAGE", "may_da_target_group", input_lineage["may_da_target"]),
        _lineage_ref("MAY_NEW_SALES_TARGET", "R02_LINEAGE", "may_new_sales_target_group", input_lineage["may_new_sales_target"]),
    ]

    if mtd_total is None or may_target is None:
        return {
            "status": "blocked_untrusted_forecast",
            "reason": "Missing R04 MTD total or R02 May MDO target.",
            "lineage_refs": lineage_refs,
            "assumptions": [],
            "guardrails": {"no_silent_fallback": True, "critical_forecasts_require_lineage": True},
        }

    if not all(ref["has_lineage"] for ref in [lineage_refs[0], lineage_refs[3]]):
        return {
            "status": "blocked_untrusted_forecast",
            "reason": "Forecast critical inputs failed lineage gate.",
            "lineage_refs": lineage_refs,
            "assumptions": [],
            "guardrails": {"no_silent_fallback": True, "critical_forecasts_require_lineage": True},
        }

    wd = _infer_working_days(payload)
    elapsed = wd["elapsed_working_days"] or 1
    total_days = wd["total_working_days"] or elapsed
    remaining = wd["remaining_working_days"]

    current_run_rate = mtd_total / elapsed
    projected_landing = current_run_rate * total_days
    remaining_required = max(may_target - mtd_total, 0)
    required_daily_run_rate = remaining_required / remaining if remaining else 0.0
    gap_to_target = projected_landing - may_target
    achievement_pct = (mtd_total / may_target * 100) if may_target else None
    projected_achievement_pct = (projected_landing / may_target * 100) if may_target else None
    mdo_prorata_target = may_target * (elapsed / total_days) if total_days else None
    mdo_prorata_gap = mtd_total - mdo_prorata_target if mdo_prorata_target is not None else None

    da_run_rate = (mtd_da / elapsed) if mtd_da is not None else None
    ns_run_rate = (mtd_ns / elapsed) if mtd_ns is not None else None

    forecast = {
        "status": "ok",
        "contract_version": "forecast.month_end.v1.batch5",
        "forecast_date": datetime.utcnow().isoformat(timespec="seconds") + "Z",
        "forecast_name": "May month-end landing forecast",
        "reporting_basis": "R04 Finance actuals vs R02 MDO target",
        "basis_disclosure": "Actuals are R04 Finance daily collections; targets are R02 MDO targets. This is allowed only with visible basis labelling.",
        "tolerance_pct": TOLERANCE_PCT,
        "inputs": {
            "mtd_total_collections": mtd_total,
            "mtd_da_total": mtd_da,
            "mtd_new_sales_total": mtd_ns,
            "may_total_collections_target": may_target,
            "may_da_target": may_da_target,
            "may_new_sales_target": may_ns_target,
        },
        "working_days": wd,
        "outputs": {
            "current_daily_run_rate": current_run_rate,
            "required_daily_run_rate_remaining": required_daily_run_rate,
            "projected_month_end_landing": projected_landing,
            "gap_to_may_mdo_target": gap_to_target,
            "mtd_achievement_pct": achievement_pct,
            "projected_achievement_pct": projected_achievement_pct,
            "mdo_prorata_target_as_of_snapshot": mdo_prorata_target,
            "mdo_prorata_gap_as_of_snapshot": mdo_prorata_gap,
            "da_daily_run_rate": da_run_rate,
            "new_sales_daily_run_rate": ns_run_rate,
        },
        "display": {
            "mtd_total_collections": _fmt_aed(mtd_total),
            "may_total_collections_target": _fmt_aed(may_target),
            "current_daily_run_rate": _fmt_aed(current_run_rate),
            "required_daily_run_rate_remaining": _fmt_aed(required_daily_run_rate),
            "projected_month_end_landing": _fmt_aed(projected_landing),
            "gap_to_may_mdo_target": _fmt_aed(gap_to_target),
            "mtd_achievement_pct": _fmt_pct(achievement_pct),
            "projected_achievement_pct": _fmt_pct(projected_achievement_pct),
        },
        "assumptions": [
            "Month-end landing uses a straight-line current run-rate projection.",
            "Working days are inferred from the R04 pro-rata row unless an explicit calendar is later onboarded.",
            "Actuals use R04 Finance basis while target uses R02 MDO basis; UI must show the mixed-basis disclosure.",
            "R04 does not expose pure advance split; Batch 5 forecast therefore forecasts total collections, D+A and new-sales signals only.",
            "No silent fallback: forecast blocks if R04 MTD total or R02 May target lineage is missing.",
        ],
        "lineage_refs": lineage_refs + wd.get("lineage_refs", []),
        "guardrails": {
            "no_silent_fallback": True,
            "critical_forecasts_require_lineage": True,
            "forecast_assumptions_required": True,
            "finance_vs_mdo_label_required": True,
        },
    }
    return forecast


def load_payload(data_dir: Optional[str] = None, *, force_refresh: bool = False) -> Dict[str, Any]:
    path = Path(data_dir) if data_dir else None
    if hasattr(data_loader, "get_cached_payload"):
        return data_loader.get_cached_payload(data_dir=path, force_refresh=force_refresh)
    return data_loader.load_all(data_dir=path)


if APIRouter is not None:
    router = APIRouter(tags=["forecast"])

    @router.get("/forecast/month-end")
    async def get_month_end_forecast(data_dir: Optional[str] = Query(None, description="Optional data directory override for smoke tests")) -> Dict[str, Any]:
        payload = load_payload(data_dir)
        return build_month_end_forecast(payload)
else:  # pragma: no cover
    router = None
```


---

## `SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/Backend/main.py`


```python
"""
SOBHA COLLECTIONS INTELLIGENCE PLATFORM
main.py - FastAPI Application Entry Point
Version: v8.13 Batch 13
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

try:
    import data_loader
except Exception as exc:
    data_loader = None
    _data_loader_import_error = str(exc)
else:
    _data_loader_import_error = None

try:
    from health_endpoint import router as health_router
except Exception:
    health_router = None

try:
    from quickball import router as quickball_router
except Exception as exc:  # keep platform bootable; health will disclose missing router.
    quickball_router = None
    _quickball_import_error = str(exc)
else:
    _quickball_import_error = None

try:
    from forecast import router as forecast_router
except Exception as exc:
    forecast_router = None
    _forecast_import_error = str(exc)
else:
    _forecast_import_error = None

try:
    from account_action_queues import router as action_queues_router
except Exception as exc:
    action_queues_router = None
    _action_queues_import_error = str(exc)
else:
    _action_queues_import_error = None

try:
    from workflow import router as workflow_router
except Exception as exc:
    workflow_router = None
    _workflow_import_error = str(exc)
else:
    _workflow_import_error = None

try:
    from notifications import router as notifications_router
except Exception as exc:
    notifications_router = None
    _notifications_import_error = str(exc)
else:
    _notifications_import_error = None

try:
    from persistence import router as persistence_router
except Exception as exc:
    persistence_router = None
    _persistence_import_error = str(exc)
else:
    _persistence_import_error = None


try:
    import identity
    from identity import router as identity_router
except Exception as exc:
    identity = None
    identity_router = None
    _identity_import_error = str(exc)
else:
    _identity_import_error = None

try:
    import auth
    from auth import router as auth_router
except Exception as exc:
    auth = None
    auth_router = None
    _auth_import_error = str(exc)
else:
    _auth_import_error = None

try:
    from deployment import router as deployment_router
except Exception as exc:
    deployment_router = None
    _deployment_import_error = str(exc)
else:
    _deployment_import_error = None

try:
    import observability
    from observability import router as observability_router
except Exception as exc:
    observability = None
    observability_router = None
    _observability_import_error = str(exc)
else:
    _observability_import_error = None

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s - %(message)s")
logger = logging.getLogger(__name__)

_HERE = Path(__file__).resolve().parent
MANIFEST_PATH = _HERE / "manifest.json"

app = FastAPI(
    title="Sobha Collections Intelligence Platform",
    version="8.13.0-batch13",
    docs_url="/docs",
    redoc_url="/redoc",
)

_frontend_url = os.environ.get("FRONTEND_URL", "http://localhost:3000")
_env = os.environ.get("SCIP_ENV", "local")
_raw_origins = os.environ.get("CORS_ALLOWED_ORIGINS", _frontend_url)
_allowed_origins = sorted({origin.strip().rstrip("/") for origin in _raw_origins.split(",") if origin.strip()})
if _env == "local":
    _allowed_origins = sorted(set(_allowed_origins) | {
        "http://localhost:3000",
        "http://localhost:5173",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173",
    })
if _env != "local" and "*" in _allowed_origins:
    raise RuntimeError("Wildcard CORS is not allowed outside local development")

_allowed_headers = ["authorization", "content-type", "x-scip-correlation-id", "x-request-id"]
if os.environ.get("SCIP_AUTH_MODE", "jwt").lower() == "local_dev" and os.environ.get("SCIP_LOCAL_DEV_BYPASS", "false").lower() == "true":
    _allowed_headers += ["x-scip-actor-id", "x-scip-actor-name", "x-scip-role", "x-scip-entity-scope", "x-scip-collector-id", "x-scip-environment"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=_allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=_allowed_headers,
)

if observability is not None:
    app.middleware("http")(observability.correlation_middleware)

if auth is not None:
    app.middleware("http")(auth.rbac_middleware)

if health_router is not None:
    app.include_router(health_router)
if quickball_router is not None:
    app.include_router(quickball_router)
if forecast_router is not None:
    app.include_router(forecast_router)
if action_queues_router is not None:
    app.include_router(action_queues_router)
if workflow_router is not None:
    app.include_router(workflow_router)
if notifications_router is not None:
    app.include_router(notifications_router)
if persistence_router is not None:
    app.include_router(persistence_router)
if auth_router is not None:
    app.include_router(auth_router)
if identity_router is not None:
    app.include_router(identity_router)
if deployment_router is not None:
    app.include_router(deployment_router)
if observability_router is not None:
    app.include_router(observability_router)


@app.get("/manifest", tags=["platform"])
async def get_manifest() -> JSONResponse:
    try:
        with open(MANIFEST_PATH, "r", encoding="utf-8") as f:
            manifest = json.load(f)
        return JSONResponse(content=manifest, status_code=200)
    except FileNotFoundError:
        return JSONResponse(content={"status": "manifest_missing", "submodules": {}, "workflows": {}}, status_code=200)
    except json.JSONDecodeError as exc:
        return JSONResponse(content={"status": "manifest_error", "message": str(exc), "submodules": {}, "workflows": {}}, status_code=200)


@app.get("/", tags=["platform"])
async def root() -> dict:
    return {
        "platform": "Sobha Collections Intelligence Platform",
        "version": "v8.13 Batch 13",
        "status": "ok",
        "docs": "/docs",
        "health": "/health",
        "manifest": "/manifest",
        "quickball": "/quickball",
        "command_centres": "/command-centres",
        "month_end_forecast": "/forecast/month-end",
        "action_queues": "/action-queues",
        "collector_drilldown": "/action-queues/collector-drilldown",
        "workflows": "/workflows",
        "notifications": "/notifications",
        "notification_digests": "/notifications/digests",
        "persistence_summary": "/persistence/summary",
        "audit_export": "/audit/export",
        "security": "/security/me",
        "identity": "/identity/me",
        "identity_policy": "/identity/policy",
        "identity_provisioning": "/identity/provisioning",
        "rbac_policy_matrix": "/security/policy-matrix",
        "deployment_health": "/deployment/health",
        "observability_summary": "/observability/summary",
        "observability_dashboards": "/observability/dashboards",
        "observability_alerts": "/observability/alerts",
        "data_loader_import_error": _data_loader_import_error,
        "quickball_import_error": _quickball_import_error,
        "forecast_import_error": _forecast_import_error,
        "action_queues_import_error": _action_queues_import_error,
        "workflow_import_error": _workflow_import_error,
        "notifications_import_error": _notifications_import_error,
        "persistence_import_error": _persistence_import_error,
        "auth_import_error": _auth_import_error,
        "identity_import_error": _identity_import_error,
        "deployment_import_error": _deployment_import_error,
        "observability_import_error": _observability_import_error,
        "cors_allowed_origins": _allowed_origins,
        "environment": _env,
    }


@app.get("/cache/status", tags=["platform"])
async def cache_status() -> dict:
    data_cache = data_loader.get_cache_status() if data_loader is not None and hasattr(data_loader, "get_cache_status") else {"status": "unavailable"}
    action_cache = {"status": "unavailable"}
    try:
        import account_action_queues
        if hasattr(account_action_queues, "get_action_queue_cache_status"):
            action_cache = account_action_queues.get_action_queue_cache_status()
    except Exception as exc:
        action_cache = {"status": "error", "message": str(exc)}
    return {
        "status": "ok",
        "data_loader": data_cache,
        "action_queues": action_cache,
        "guardrails": {
            "lineage_preserved": True,
            "no_frontend_business_computation": True,
            "no_silent_fallback": True,
        },
    }


@app.post("/cache/refresh", tags=["platform"])
async def cache_refresh() -> dict:
    if data_loader is not None and hasattr(data_loader, "invalidate_cache"):
        data_loader.invalidate_cache()
    try:
        import account_action_queues
        if hasattr(account_action_queues, "invalidate_action_queue_cache"):
            account_action_queues.invalidate_action_queue_cache()
    except Exception:
        pass
    return {"status": "cache_invalidated", "next_request": "will_reload_sources"}


@app.on_event("startup")
async def on_startup() -> None:
    logger.info("Sobha Collections Intelligence Platform v8.13 Batch 13 starting")
    logger.info("Backend dir: %s", _HERE)
    logger.info("FRONTEND_URL: %s", _frontend_url)
    logger.info("Quickball router loaded: %s", quickball_router is not None)
    logger.info("Forecast router loaded: %s", forecast_router is not None)
    logger.info("Action queues router loaded: %s", action_queues_router is not None)
    logger.info("Workflow router loaded: %s", workflow_router is not None)
    logger.info("Notifications router loaded: %s", notifications_router is not None)
    logger.info("Persistence router loaded: %s", persistence_router is not None)
    logger.info("Auth router loaded: %s", auth_router is not None)
    logger.info("Deployment router loaded: %s", deployment_router is not None)
    logger.info("Observability router loaded: %s", observability_router is not None)
    logger.info("SCIP_ENV: %s", _env)
    logger.info("CORS origins: %s", _allowed_origins)
    if data_loader is not None and hasattr(data_loader, "get_cached_payload"):
        if os.environ.get("SCIP_WARM_DATA_CACHE_ON_STARTUP", "true").lower() == "true":
            try:
                data_loader.get_cached_payload()
                logger.info("SCIP data cache warmed on startup")
            except Exception as exc:
                logger.warning("SCIP data cache warmup failed; first request will retry: %s", exc)
```


---

## `SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/Backend/quickball.py`


```python
"""
SCIP quickball.py - Batch 4 lineage-first analytics copilot

Purpose
- Explain trusted Batch 1-3 critical metrics with source-level lineage.
- Block critical answers when lineage, validation, or confidence is missing.
- Provide role-aware interpretation without changing the underlying number.
- Expose FastAPI endpoints for explain-this-number and role command centres.

Dependency rule
- quickball imports data_loader and command_centres only.
- quickball never parses Excel directly; it only consumes the trusted payload.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Optional

try:  # FastAPI is available in deployment; keep import optional for smoke tests.
    from fastapi import APIRouter, Query
except Exception:  # pragma: no cover - allows pure Python smoke tests without FastAPI.
    APIRouter = None
    Query = None

import data_loader
import command_centres


# ---------------------------------------------------------------------------
# Role model - Batch 4 approved roles
# ---------------------------------------------------------------------------

ROLE_MODES: Dict[str, Dict[str, Any]] = {
    "board_cxo": {
        "label": "Board/CXO",
        "purpose": "Decision clarity, strategic risk, and source trust.",
        "tone": "executive",
        "focus": ["variance", "risk", "cash visibility", "decision needed"],
    },
    "cco_gm_agm": {
        "label": "CCO/GM/AGM",
        "purpose": "Daily intervention control and month-end landing.",
        "tone": "operational leadership",
        "focus": ["shortfall", "entity split", "intervention", "owner action"],
    },
    "finance": {
        "label": "Finance",
        "purpose": "Reconciliation, reporting basis, and audit traceability.",
        "tone": "control and reconciliation",
        "focus": ["source", "basis", "cell", "validation", "tolerance"],
    },
    "mis_qcg_admin": {
        "label": "MIS/QCG/Admin",
        "purpose": "Source freshness, validation, smoke gates, and data quality.",
        "tone": "data operations",
        "focus": ["lineage", "validation", "missing sources", "fallback policy"],
    },
    "collector_rm": {
        "label": "Collector/RM",
        "purpose": "Actionable collection focus without exposing unverified account detail.",
        "tone": "frontline action",
        "focus": ["priority", "follow-up", "OD", "daily target"],
    },
}

ROLE_ALIASES = {
    "board": "board_cxo",
    "cxo": "board_cxo",
    "board/cxo": "board_cxo",
    "executive": "board_cxo",
    "cco": "cco_gm_agm",
    "gm": "cco_gm_agm",
    "agm": "cco_gm_agm",
    "cco/gm/agm": "cco_gm_agm",
    "finance": "finance",
    "mis": "mis_qcg_admin",
    "qcg": "mis_qcg_admin",
    "admin": "mis_qcg_admin",
    "mis/qcg/admin": "mis_qcg_admin",
    "collector": "collector_rm",
    "rm": "collector_rm",
    "collector/rm": "collector_rm",
}


# ---------------------------------------------------------------------------
# Critical metric catalogue
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class MetricSpec:
    canonical_key: str
    label: str
    computed_key: Optional[str]
    lineage_bucket: str
    lineage_key: str
    reporting_basis: str
    source_code: str
    unit: str = "AED"
    critical: bool = True
    business_definition: str = ""


METRIC_CATALOG: Dict[str, MetricSpec] = {
    # R18 OD
    "OD_TODAY": MetricSpec("OD_TODAY", "Group overdue today", "OD_TODAY", "OD_LINEAGE", "OD_TODAY", "R18 overdue", "R18", business_definition="Group OD from R18 Grand Total."),
    "OD_GROUP": MetricSpec("OD_GROUP", "Group overdue roll-up", "OD_GROUP", "OD_LINEAGE", "OD_GROUP", "R18 overdue", "R18", business_definition="Sobha plus UAQ OD roll-up."),
    "OD_SOBHA": MetricSpec("OD_SOBHA", "Sobha overdue", "OD_SOBHA", "OD_LINEAGE", "OD_SOBHA", "R18 overdue", "R18"),
    "OD_UAQ": MetricSpec("OD_UAQ", "UAQ overdue", "OD_UAQ", "OD_LINEAGE", "OD_UAQ", "R18 overdue", "R18"),
    "OD_SOBHA_DUBAI": MetricSpec("OD_SOBHA_DUBAI", "Sobha Dubai overdue", "OD_SOBHA_DUBAI", "OD_LINEAGE", "OD_SOBHA_DUBAI", "R18 overdue", "R18"),
    "OD_SOBHA_AUH": MetricSpec("OD_SOBHA_AUH", "Sobha AUH overdue", "OD_SOBHA_AUH", "OD_LINEAGE", "OD_SOBHA_AUH", "R18 overdue", "R18"),
    "OD_SINIYA": MetricSpec("OD_SINIYA", "Siniya overdue", "OD_SINIYA", "OD_LINEAGE", "OD_SINIYA", "R18 overdue", "R18"),
    "OD_DOWNTOWN_UAQ": MetricSpec("OD_DOWNTOWN_UAQ", "Downtown UAQ overdue", "OD_DOWNTOWN_UAQ", "OD_LINEAGE", "OD_DOWNTOWN_UAQ", "R18 overdue", "R18"),

    # R04 Finance daily
    "MTD_TOTAL_COLLECTIONS": MetricSpec("MTD_TOTAL_COLLECTIONS", "MTD total collections", "MTD_TOTAL_COLLECTIONS", "R04_LINEAGE", "mtd_total_collections", "Finance", "R04", business_definition="Finance MTD total = Finance D+A/collection-due plus new sales."),
    "MTD_DA_TOTAL": MetricSpec("MTD_DA_TOTAL", "MTD Finance D+A", "MTD_DA_TOTAL", "R04_LINEAGE", "mtd_da_total", "Finance", "R04", business_definition="R04 Collection Due; Finance basis D+A."),
    "MTD_NS_TOTAL": MetricSpec("MTD_NS_TOTAL", "MTD new-sales collections", "MTD_NS_TOTAL", "R04_LINEAGE", "mtd_ns_total", "Finance", "R04"),
    "MTD_DLD_OQOOD_TOTAL": MetricSpec("MTD_DLD_OQOOD_TOTAL", "MTD DLD/Oqood", "MTD_DLD_OQOOD_TOTAL", "R04_LINEAGE", "mtd_dld_oqood_total", "Finance", "R04"),

    # R02 MDO targets and actuals
    "MAY_DA_TARGET": MetricSpec("MAY_DA_TARGET", "May MDO D+A target", "MAY_DA_TARGET", "R02_LINEAGE", "may_da_target_group", "MDO", "R02", business_definition="May target for MDO dues plus advance."),
    "MAY_TOTAL_COLLECTIONS_TARGET": MetricSpec("MAY_TOTAL_COLLECTIONS_TARGET", "May MDO total collections target", "MAY_TOTAL_COLLECTIONS_TARGET", "R02_LINEAGE", "may_total_collections_target_group", "MDO", "R02"),
    "MAY_DUES_TARGET": MetricSpec("MAY_DUES_TARGET", "May MDO dues target", "MAY_DUES_TARGET", "R02_LINEAGE", "may_dues_target_group", "MDO", "R02"),
    "MAY_ADV_TARGET": MetricSpec("MAY_ADV_TARGET", "May MDO advance target", "MAY_ADV_TARGET", "R02_LINEAGE", "may_advance_target_group", "MDO", "R02"),
    "FY_DA_TARGET": MetricSpec("FY_DA_TARGET", "FY MDO D+A target", "FY_DA_TARGET", "R02_LINEAGE", "fy_da_target_group", "MDO", "R02"),
    "FY_TOTAL_COLLECTIONS_TARGET": MetricSpec("FY_TOTAL_COLLECTIONS_TARGET", "FY MDO total collections target", "FY_TOTAL_COLLECTIONS_TARGET", "R02_LINEAGE", "fy_total_collections_target_group", "MDO", "R02"),

    # R08 advance
    "ADVANCE_2026_TOTAL": MetricSpec("ADVANCE_2026_TOTAL", "2026 total advance", "ADVANCE_2026_TOTAL", "R08_LINEAGE", "ADVANCE_2026_TOTAL", "R08 advance summary", "R08"),
    "ADVANCE_2026_CY": MetricSpec("ADVANCE_2026_CY", "2026 current-year advance", "ADVANCE_2026_CY", "R08_LINEAGE", "ADVANCE_2026_CY", "R08 advance summary", "R08"),
    "ADVANCE_2026_FY": MetricSpec("ADVANCE_2026_FY", "2026 future-year advance", "ADVANCE_2026_FY", "R08_LINEAGE", "ADVANCE_2026_FY", "R08 advance summary", "R08"),
    "CY_ADV_MIX_YTD": MetricSpec("CY_ADV_MIX_YTD", "Current-year advance mix", "CY_ADV_MIX_YTD", "R08_LINEAGE", "CY_ADV_MIX_YTD", "R08 advance summary", "R08", unit="pct"),
    "FY_ADV_MIX_YTD": MetricSpec("FY_ADV_MIX_YTD", "Future-year advance mix", "FY_ADV_MIX_YTD", "R08_LINEAGE", "FY_ADV_MIX_YTD", "R08 advance summary", "R08", unit="pct"),
    "YTD_2026_REBATE": MetricSpec("YTD_2026_REBATE", "YTD 2026 rebate / NPV applied", "YTD_2026_REBATE", "R08_LINEAGE", "ytd_2026_rebate", "R08 advance summary", "R08"),

    # R36 milestone cohort
    "PIPELINE_GROSS": MetricSpec("PIPELINE_GROSS", "Pipeline gross / active forward collectible calendar", "PIPELINE_GROSS", "R36_LINEAGE", "PIPELINE_GROSS", "R36 milestone cohort", "R36", business_definition="Active forward collectible calendar from 2026 onwards."),
    "PIPELINE_ACTIVE_TOTAL_PURCHASE_PRICE": MetricSpec("PIPELINE_ACTIVE_TOTAL_PURCHASE_PRICE", "Active total purchase price", "PIPELINE_ACTIVE_TOTAL_PURCHASE_PRICE", "R36_LINEAGE", "PIPELINE_ACTIVE_TOTAL_PURCHASE_PRICE", "R36 milestone cohort", "R36"),
    "PIPELINE_FORWARD_2026": MetricSpec("PIPELINE_FORWARD_2026", "2026 forward collectible", None, "R36_LINEAGE", "pipeline_forward_2026", "R36 milestone cohort", "R36"),
    "PIPELINE_FORWARD_2027": MetricSpec("PIPELINE_FORWARD_2027", "2027 forward collectible", None, "R36_LINEAGE", "pipeline_forward_2027", "R36 milestone cohort", "R36"),
    "PIPELINE_FORWARD_2028": MetricSpec("PIPELINE_FORWARD_2028", "2028 forward collectible", None, "R36_LINEAGE", "pipeline_forward_2028", "R36 milestone cohort", "R36"),
}

ALIASES: Dict[str, str] = {
    "od": "OD_TODAY",
    "od today": "OD_TODAY",
    "overdue": "OD_TODAY",
    "group od": "OD_TODAY",
    "sobha od": "OD_SOBHA",
    "uaq od": "OD_UAQ",
    "mtd collections": "MTD_TOTAL_COLLECTIONS",
    "daily collections": "MTD_TOTAL_COLLECTIONS",
    "r04 collections": "MTD_TOTAL_COLLECTIONS",
    "finance d+a": "MTD_DA_TOTAL",
    "new sales": "MTD_NS_TOTAL",
    "may target": "MAY_TOTAL_COLLECTIONS_TARGET",
    "may d+a target": "MAY_DA_TARGET",
    "mdo target": "MAY_TOTAL_COLLECTIONS_TARGET",
    "fy target": "FY_TOTAL_COLLECTIONS_TARGET",
    "advance": "ADVANCE_2026_TOTAL",
    "advance total": "ADVANCE_2026_TOTAL",
    "cy advance": "ADVANCE_2026_CY",
    "fy advance": "ADVANCE_2026_FY",
    "cy mix": "CY_ADV_MIX_YTD",
    "fy mix": "FY_ADV_MIX_YTD",
    "rebate": "YTD_2026_REBATE",
    "npv": "YTD_2026_REBATE",
    "pipeline": "PIPELINE_GROSS",
    "pipeline gross": "PIPELINE_GROSS",
    "r36 pipeline": "PIPELINE_GROSS",
    "2026 forward": "PIPELINE_FORWARD_2026",
    "2027 forward": "PIPELINE_FORWARD_2027",
    "2028 forward": "PIPELINE_FORWARD_2028",
}


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def normalize_role(role: Optional[str]) -> str:
    if not role:
        return "board_cxo"
    text = str(role).strip().lower().replace(" ", "_")
    text_slash = str(role).strip().lower()
    if text in ROLE_MODES:
        return text
    if text_slash in ROLE_ALIASES:
        return ROLE_ALIASES[text_slash]
    return ROLE_ALIASES.get(text, "board_cxo")


def normalize_metric_key(metric: str) -> Optional[str]:
    if not metric:
        return None
    raw = str(metric).strip()
    upper = raw.upper().replace(" ", "_").replace("-", "_")
    if upper in METRIC_CATALOG:
        return upper
    lower = raw.strip().lower().replace("_", " ")
    if lower in ALIASES:
        return ALIASES[lower]
    for alias, canonical in ALIASES.items():
        if alias in lower:
            return canonical
    return None


def _fmt_value(value: Any, unit: str) -> str:
    if value is None:
        return "Unavailable"
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)
    if unit == "pct":
        return f"{number:.2f}%"
    if unit == "AED":
        abs_n = abs(number)
        if abs_n >= 1_000_000_000:
            return f"AED {number / 1_000_000_000:,.3f}B"
        if abs_n >= 1_000_000:
            return f"AED {number / 1_000_000:,.1f}M"
        return f"AED {number:,.0f}"
    return f"{number:,.2f}"


def _get_metric_value(payload: Dict[str, Any], spec: MetricSpec, lineage: Dict[str, Any]) -> Any:
    computed = payload.get("computed", {})
    if spec.computed_key:
        return computed.get(spec.computed_key)
    # R36 forward buckets are stored inside FORWARD_COLLECTIBLE_CALENDAR.
    if spec.canonical_key.startswith("PIPELINE_FORWARD_"):
        year = spec.canonical_key.rsplit("_", 1)[-1]
        return (computed.get("FORWARD_COLLECTIBLE_CALENDAR") or {}).get(year)
    return lineage.get("value")


def _lineage_is_usable(lineage: Optional[Dict[str, Any]]) -> bool:
    if not isinstance(lineage, dict) or not lineage:
        return False
    required = ["source_file", "sheet", "cell_or_range", "validation_status", "confidence_state"]
    return all(lineage.get(k) not in (None, "") for k in required)


def _answer_blocked(spec: MetricSpec, reason: str, role_key: str) -> Dict[str, Any]:
    return {
        "status": "blocked_untrusted_metric",
        "role": ROLE_MODES[role_key],
        "metric_key": spec.canonical_key,
        "metric_label": spec.label,
        "reason": reason,
        "answer": (
            f"I cannot explain {spec.label} because the trusted lineage gate failed. "
            f"Reason: {reason}. The no-silent-fallback rule is active for {spec.source_code}."
        ),
        "lineage": None,
        "guardrail": {
            "critical_metric": spec.critical,
            "no_silent_fallback": True,
            "requires_lineage": True,
        },
    }


def _role_interpretation(role_key: str, spec: MetricSpec, value: Any, payload: Dict[str, Any]) -> str:
    computed = payload.get("computed", {})
    if role_key == "board_cxo":
        if spec.source_code == "R18":
            return "Board view: treat this as the current cash-risk exposure requiring entity-level review before the next executive discussion."
        if spec.source_code == "R36":
            return "Board view: this is the forward collectible base for strategic cash visibility and pipeline concentration review."
        if spec.source_code == "R08":
            return "Board view: use this to judge advance acceleration quality and current-year versus future-year cash pull-forward."
        if spec.source_code == "R02":
            return "Board view: this is an MDO target, so compare it with Finance actuals only when the reporting basis is shown."
        if spec.source_code == "R04":
            return "Board view: this is Finance-basis daily collection progress, useful for month-end landing visibility."
    if role_key == "cco_gm_agm":
        if spec.source_code == "R04":
            target = computed.get("MAY_TOTAL_COLLECTIONS_TARGET") or computed.get("MAY_DA_TARGET")
            if target:
                pct = (float(value or 0) / float(target)) * 100
                return f"Ops view: this is the working MTD progress signal. Current progress is about {pct:.1f}% of the comparable May MDO target basis, subject to Finance-vs-MDO labelling."
            return "Ops view: use this as the daily intervention baseline and pair it with remaining working days."
        if spec.source_code == "R18":
            return "Ops view: review the Sobha and UAQ splits first, then assign OD recovery actions by project/account owner."
        return "Ops view: convert this number into a weekly intervention queue and owner-wise follow-up."
    if role_key == "finance":
        return "Finance view: verify reporting basis, source file, sheet, cell/range, and validation status before using this in reconciliation or official reporting."
    if role_key == "mis_qcg_admin":
        return "MIS/QCG/Admin view: this metric passed the lineage gate; monitor source freshness, validation status, and any warnings before release."
    if role_key == "collector_rm":
        if spec.source_code == "R18":
            return "Collector/RM view: use the OD exposure to prioritise overdue follow-up; account-level action lists require account-level source onboarding."
        return "Collector/RM view: use this as a directional target/progress signal; customer-level tasking must come from lineaged account-level reports."
    return "Use this figure only with its reporting basis and source lineage visible."


# ---------------------------------------------------------------------------
# Public API functions
# ---------------------------------------------------------------------------

def explain_metric(payload: Dict[str, Any], metric: str, role: Optional[str] = "board_cxo") -> Dict[str, Any]:
    role_key = normalize_role(role)
    canonical = normalize_metric_key(metric)
    if not canonical or canonical not in METRIC_CATALOG:
        return {
            "status": "unknown_metric",
            "role": ROLE_MODES[role_key],
            "input": metric,
            "answer": "I could not map that request to a trusted SCIP critical metric. Try OD_TODAY, MTD_TOTAL_COLLECTIONS, MAY_DA_TARGET, ADVANCE_2026_TOTAL, or PIPELINE_GROSS.",
            "available_examples": sorted(list(METRIC_CATALOG.keys()))[:20],
        }

    spec = METRIC_CATALOG[canonical]
    computed = payload.get("computed", {})
    lineage_bucket = computed.get(spec.lineage_bucket, {}) or {}
    lineage = lineage_bucket.get(spec.lineage_key)

    if spec.critical and not _lineage_is_usable(lineage):
        return _answer_blocked(spec, f"Missing or incomplete lineage for {spec.lineage_bucket}.{spec.lineage_key}", role_key)

    if spec.critical and lineage.get("validation_status") not in ("passed", "disclosed", "warning"):
        return _answer_blocked(spec, f"Validation status is {lineage.get('validation_status')}", role_key)

    if spec.critical and lineage.get("confidence_state") not in ("live_validated", "live_warning", "disclosed"):
        return _answer_blocked(spec, f"Confidence state is {lineage.get('confidence_state')}", role_key)

    value = _get_metric_value(payload, spec, lineage)
    if value is None and spec.critical:
        return _answer_blocked(spec, "Metric value is unavailable despite lineage lookup", role_key)

    displayed_value = _fmt_value(value, spec.unit)
    role_note = _role_interpretation(role_key, spec, value, payload)
    basis = lineage.get("reporting_basis") or spec.reporting_basis
    business_definition = lineage.get("business_definition") or spec.business_definition

    answer = (
        f"{spec.label} is {displayed_value}. "
        f"Reporting basis: {basis}. "
        f"Source: {lineage.get('source_file')} / sheet {lineage.get('sheet')} / cell or range {lineage.get('cell_or_range')}. "
        f"Validation: {lineage.get('validation_status')}; confidence: {lineage.get('confidence_state')}. "
        f"Definition: {business_definition} "
        f"{role_note}"
    )

    return {
        "status": "answered",
        "role": ROLE_MODES[role_key],
        "metric_key": spec.canonical_key,
        "metric_label": spec.label,
        "value": value,
        "display_value": displayed_value,
        "unit": spec.unit,
        "reporting_basis": basis,
        "source_code": spec.source_code,
        "business_definition": business_definition,
        "answer": answer,
        "role_interpretation": role_note,
        "lineage": lineage,
        "guardrail": {
            "critical_metric": spec.critical,
            "no_silent_fallback": True,
            "requires_lineage": True,
            "lineage_gate_passed": True,
        },
    }


def build_sample_answers(payload: Dict[str, Any]) -> Dict[str, Any]:
    samples = [
        ("OD_TODAY", "board_cxo"),
        ("MTD_TOTAL_COLLECTIONS", "cco_gm_agm"),
        ("MAY_DA_TARGET", "finance"),
        ("ADVANCE_2026_TOTAL", "board_cxo"),
        ("YTD_2026_REBATE", "finance"),
        ("PIPELINE_GROSS", "board_cxo"),
        ("PIPELINE_FORWARD_2026", "mis_qcg_admin"),
    ]
    return {
        "samples": [explain_metric(payload, metric, role) for metric, role in samples],
        "catalog_count": len(METRIC_CATALOG),
    }


def load_payload(data_dir: Optional[str] = None, *, force_refresh: bool = False) -> Dict[str, Any]:
    path = Path(data_dir) if data_dir else None
    if hasattr(data_loader, "get_cached_payload"):
        return data_loader.get_cached_payload(data_dir=path, force_refresh=force_refresh)
    return data_loader.load_all(data_dir=path)


# ---------------------------------------------------------------------------
# FastAPI router
# ---------------------------------------------------------------------------

if APIRouter is not None:
    router = APIRouter(tags=["quickball"])

    @router.get("/quickball")
    async def quickball_status() -> Dict[str, Any]:
        return {
            "status": "ok",
            "mode": "lineage_first",
            "roles": ROLE_MODES,
            "metric_catalog_count": len(METRIC_CATALOG),
            "guardrails": {
                "no_silent_fallback": True,
                "critical_metrics_require_lineage": True,
                "reporting_basis_required": True,
            },
        }

    @router.get("/quickball/explain")
    async def quickball_explain(
        metric: str = Query(..., description="Metric name or natural-language alias, e.g. OD_TODAY or pipeline gross"),
        role: str = Query("board_cxo", description="board_cxo, cco_gm_agm, finance, mis_qcg_admin, collector_rm"),
    ) -> Dict[str, Any]:
        # Unknown metric requests should return immediately and must not trigger
        # a full workbook parse. Known metrics use the cached trusted payload.
        if not normalize_metric_key(metric):
            return explain_metric({"computed": {}}, metric, role)
        payload = load_payload()
        return explain_metric(payload, metric, role)

    @router.get("/quickball/sample-answers")
    async def quickball_sample_answers() -> Dict[str, Any]:
        payload = load_payload()
        return build_sample_answers(payload)

    @router.get("/command-centres")
    async def get_command_centres() -> Dict[str, Any]:
        payload = load_payload()
        return command_centres.build_command_centres(payload)

    @router.get("/command-centres/{role}")
    async def get_command_centre(role: str) -> Dict[str, Any]:
        payload = load_payload()
        centres = command_centres.build_command_centres(payload)
        role_key = normalize_role(role)
        return centres.get("roles", {}).get(role_key, {"status": "unknown_role", "role": role})
else:
    router = None
```


---

## `SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/src/App.jsx`


```jsx
/**
 * SCIP Batch 13 App.jsx
 * Liquid Glass SSO/JWT identity layer on top of Batch 12 observability and Batch 11 RBAC hardening.
 *
 * Preserved backend contracts:
 *   GET /command-centres
 *   GET /forecast/month-end
 *   GET /quickball/explain?metric=<metric>&role=<role>
 *   GET /action-queues
 *   GET /action-queues/collector-drilldown
 *   GET /workflows
 *   POST /workflows/assign | /reassign | /due-date | /disposition | /evidence | /close
 *
 * Guardrails:
 *   - No frontend financial computation. The UI only displays server-provided values.
 *   - No silent fallback. If backend fails, show unavailable/error state.
 *   - Entity Head role remains removed.
 *   - Liquid Glass is used for movement, context, command and reveal.
 *   - Solid surfaces are used for KPIs, charts, evidence, formulas and financial truth.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import "./liquidGlassTokens.css";
import "./scipPowerUatQuickball.css";

const BACKEND_URL = import.meta?.env?.VITE_BACKEND_URL || "https://scip.onrender.com";
const LOCAL_DEV_BYPASS = import.meta?.env?.VITE_SCIP_LOCAL_DEV_BYPASS === "true";

const ROLE_ORDER = ["board_cxo", "cco_gm_agm", "finance", "mis_qcg_admin", "collector_rm"];
const ACTOR_IDS = {
  board_cxo: "board_cxo_demo",
  cco_gm_agm: "cco_manager_demo",
  finance: "finance_demo",
  mis_qcg_admin: "mis_admin_demo",
  collector_rm: "collector_rm_demo",
};

function demoJwtForRole(role) {
  const envKey = `VITE_SCIP_JWT_${String(role || "").toUpperCase()}`;
  return import.meta?.env?.[envKey] || import.meta?.env?.VITE_SCIP_DEMO_JWT || "";
}

function authHeaders(role) {
  const correlationId = `scip-ui-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  if (LOCAL_DEV_BYPASS) {
    return {
      "X-SCIP-Actor-ID": ACTOR_IDS[role] || "board_cxo_demo",
      "X-SCIP-Actor-Name": ROLE_LABELS[role] || "Board/CXO",
      "X-SCIP-Role": role,
      "X-SCIP-Entity-Scope": role === "collector_rm" ? "Sobha Dubai" : "Group",
      "X-SCIP-Collector-ID": role === "collector_rm" ? "collector_rm_demo" : "",
      "X-SCIP-Environment": "local",
      "X-SCIP-Correlation-ID": correlationId,
    };
  }
  const token = demoJwtForRole(role);
  return {
    Authorization: token ? `Bearer ${token}` : "",
    "X-SCIP-Correlation-ID": correlationId,
  };
}


const ROLE_LABELS = {
  board_cxo: "Board/CXO",
  cco_gm_agm: "CCO/GM/AGM",
  finance: "Finance",
  mis_qcg_admin: "MIS/QCG/Admin",
  collector_rm: "Collector/RM",
};

const LIVE_PULSE_CHOICES = [
  {
    key: "current_signal",
    title: "Current Signal",
    question: "Are we okay today?",
    summary: "A calm reading of what needs attention now, anchored on OD, collections, and confidence.",
  },
  {
    key: "month_movement",
    title: "Month Movement",
    question: "How is this month moving?",
    summary: "MTD movement, run-rate, target gap, and the finance/MDO basis behind the month-end forecast.",
  },
  {
    key: "risk_action",
    title: "Risk & Action",
    question: "Where should we act?",
    summary: "Attention areas, OD pressure, collection gaps, and action-ready follow-up paths.",
  },
];

const NARRATIVE_STEPS = [
  { key: "story", label: "Story", question: "What is the board-level story?" },
  { key: "portfolio", label: "Portfolio", question: "What is the portfolio position?" },
  { key: "dues", label: "Dues", question: "Where is OD / dues risk?" },
  { key: "advance", label: "Advance", question: "What is the advance opportunity?" },
  { key: "roadmap", label: "Roadmap", question: "What should leadership do next?" },
];

function safeArray(value) {
  return Array.isArray(value) ? value : [];
}

function formatCardValue(card) {
  return card?.display_value || card?.display || "Unavailable";
}

function pickCardsForFocus(cards, route, focus) {
  const all = safeArray(cards);
  if (all.length <= 4) return all;
  const lowered = (text) => String(text || "").toLowerCase();
  const rules = {
    current_signal: ["od", "today", "confidence", "lineage"],
    month_movement: ["mtd", "month", "forecast", "target", "run-rate", "collections"],
    risk_action: ["risk", "action", "gap", "overdue", "attention"],
    story: ["story", "board", "forecast", "pipeline"],
    portfolio: ["portfolio", "group", "pipeline", "achievement"],
    dues: ["dues", "od", "overdue", "ageing"],
    advance: ["advance", "rebate", "cy", "fy"],
    roadmap: ["roadmap", "action", "risk", "next"],
  };
  const keywords = rules[focus] || [];
  const scored = all.map((card, index) => {
    const haystack = [card.title, card.card_id, card.reporting_basis, card.action, card.severity].map(lowered).join(" ");
    const score = keywords.filter((keyword) => haystack.includes(keyword)).length;
    return { card, score, index };
  });
  const selected = scored
    .sort((a, b) => b.score - a.score || a.index - b.index)
    .slice(0, route === "narratives" ? 4 : 4)
    .map((item) => item.card);
  return selected.length ? selected : all.slice(0, 4);
}

function getPrimaryCopy(route, focus, roleLabel) {
  const focusCopy = {
    current_signal: {
      answer: "Start with the signal, then ask for evidence only when needed.",
      copy: "The screen holds back dense tables and exposes the minimum trusted view: data confidence, the main lineaged cards, and the next curiosity path.",
    },
    month_movement: {
      answer: "The month view stays forecast-led and basis-labelled.",
      copy: "R04 Finance actuals and R02 MDO targets stay visibly labelled. The forecast panel discloses working-day assumptions and keeps calculations in the backend.",
    },
    risk_action: {
      answer: "Risk is treated as a prompt for action, not another chart wall.",
      copy: "The cards remain lineaged and action-oriented. Collector/account evidence remains gated until the user asks for depth.",
    },
    story: {
      answer: "Narratives now feel like a guided board briefing.",
      copy: "The rail moves Story → Portfolio → Dues → Advance → Roadmap. Executive output stays board-safe, while detailed evidence remains one click deeper.",
    },
    portfolio: {
      answer: "Portfolio is presented as position, implication, and proof on demand.",
      copy: "The screen prioritises a single board-safe answer and only reveals target basis, entity split, and source detail through the lineage/evidence drawer.",
    },
    dues: {
      answer: "Dues and OD are solid financial truth surfaces.",
      copy: "OD numbers never sit behind heavy blur. Glass is reserved for navigation and reveal; KPI cards remain stable and readable.",
    },
    advance: {
      answer: "Advance is framed as opportunity with CY/FY and rebate evidence.",
      copy: "R08 labels stay visible and the Sobha/UAQ hierarchy remains locked without inventing missing child splits.",
    },
    roadmap: {
      answer: "Roadmap closes the loop from insight to leadership action.",
      copy: "The interface keeps action close to context: Present, summary, export, action list, and Quickball explanation.",
    },
  };
  const item = focusCopy[focus] || focusCopy.current_signal;
  return { ...item, roleHint: `Current audience lens: ${roleLabel}.` };
}


function SecurityPostureBar({ security, role }) {
  const actor = security?.actor || {};
  const permissions = actor.permissions || [];
  return (
    <section className="security-posture glass-surface" aria-label="Security and RBAC posture">
      <div>
        <div className="kicker">Batch 11 · Secured RBAC</div>
        <h2>Authenticated actor: {actor.role_label || ROLE_LABELS[role]}</h2>
        <p>Row-level visibility is enforced by role, entity scope, and owner where applicable. Entity Head remains removed.</p>
      </div>
      <div className="security-chip-row">
        <span className="source-pill">Actor: {actor.actor_id || ACTOR_IDS[role]}</span>
        <span className="source-pill">Role: {actor.role || role}</span>
        <span className="source-pill">Permissions: {permissions.length}</span>
        <span className="source-pill">Audit denied attempts: logged</span>
      </div>
    </section>
  );
}

function DataConfidenceTrustBar({ trustBar, guardrails }) {
  const loaded = safeArray(trustBar?.sources_loaded);
  const missing = safeArray(trustBar?.sources_missing);
  const lineageCounts = trustBar?.critical_lineage_counts || {};
  const criticalSources = trustBar?.critical_sources || ["R18", "R04", "R02", "R08", "R36"];
  const allCriticalLineaged = criticalSources.every((source) => Number(lineageCounts[source] || 0) > 0);

  return (
    <section className="trust-bar glass-surface" aria-label="Data confidence trust bar">
      <div>
        <div className="trust-title-row">
          <span className="trust-dot" style={{ background: allCriticalLineaged ? "var(--status-good)" : "var(--status-attention)" }} />
          <span className="trust-title">Data confidence</span>
          <span className="trust-status">{allCriticalLineaged ? "Critical lineage live" : "Lineage needs review"}</span>
        </div>
        <div className="trust-meta" aria-label="Data confidence metadata">
          <span>Snapshot: {trustBar?.snapshot_date || "Unavailable"}</span>
          <span>Load: {trustBar?.load_timestamp || "Unavailable"}</span>
          <span>Tolerance: {trustBar?.tolerance_pct ?? 0.05}%</span>
          <span>No silent fallback: {guardrails?.no_silent_fallback ? "On" : "Check"}</span>
        </div>
      </div>
      <div className="trust-sources" aria-label="Critical lineage counts">
        {criticalSources.map((source) => (
          <span className="source-pill" key={source}>{source}: {lineageCounts[source] || 0}</span>
        ))}
        <span className="source-pill">Loaded: {loaded.length}</span>
        <span className={`source-pill ${missing.length ? "warn" : ""}`}>Missing: {missing.length}</span>
      </div>
    </section>
  );
}

function MetricBox({ label, value, basis }) {
  return (
    <div className="metric-box solid-truth">
      <span className="metric-label">{label}</span>
      <span className="metric-value">{value || "Unavailable"}</span>
      <span className="metric-basis">{basis}</span>
    </div>
  );
}

function ForecastPanel({ forecast, onOpenLineage }) {
  if (!forecast) return null;

  if (forecast.status !== "ok") {
    return (
      <section className="forecast-panel solid-truth" role="alert" aria-label="Month-end forecast blocked">
        <h2 className="panel-title">Month-end forecast blocked</h2>
        <p className="panel-sub">{forecast.reason || "Forecast could not be generated. No fallback forecast is shown."}</p>
      </section>
    );
  }

  const d = forecast.display || {};
  const wd = forecast.working_days || {};

  return (
    <section className="forecast-panel solid-truth gold-edge" aria-label="Month-end landing forecast">
      <div className="panel-header-row">
        <div>
          <div className="kicker">Month Movement</div>
          <h2 className="panel-title">May month-end landing forecast</h2>
          <p className="panel-sub">{forecast.basis_disclosure}</p>
        </div>
        <button className="secondary-button" onClick={() => onOpenLineage(forecast.lineage_refs || [], "Forecast lineage")}>View lineage</button>
      </div>

      <div className="forecast-grid">
        <MetricBox label="MTD actual" value={d.mtd_total_collections} basis="R04 Finance" />
        <MetricBox label="May target" value={d.may_total_collections_target} basis="R02 MDO" />
        <MetricBox label="Current run-rate" value={d.current_daily_run_rate} basis={`${wd.elapsed_working_days || "?"} elapsed working days`} />
        <MetricBox label="Required run-rate" value={d.required_daily_run_rate_remaining} basis={`${wd.remaining_working_days || "?"} remaining working days`} />
        <MetricBox label="Projected landing" value={d.projected_month_end_landing} basis="Backend straight-line projection" />
        <MetricBox label="Projected achievement" value={d.projected_achievement_pct} basis={`Gap ${d.gap_to_may_mdo_target || "Unavailable"}`} />
      </div>

      <details className="assumptions-box" open>
        <summary>Forecast assumptions</summary>
        <ul>
          {safeArray(forecast.assumptions).map((item) => <li key={item}>{item}</li>)}
        </ul>
      </details>
    </section>
  );
}

function CommandCentreCard({ card, onOpenLineage, onExplain }) {
  const refs = card?.lineage_display || card?.lineage_refs || [];
  const lineaged = refs.length > 0 && refs.every((ref) => ref.has_lineage);
  return (
    <article className="kpi-card solid-truth" aria-label={`${card?.title || "Command centre card"} card`}>
      <span className="label">{card?.severity || "info"} · {lineaged ? "Lineaged" : "Lineage warning"}</span>
      <h3>{card?.title}</h3>
      <span className="value">{formatCardValue(card)}</span>
      <span className="basis">Reporting basis: {card?.reporting_basis || "Unavailable"}</span>
      <p>{card?.action}</p>
      {card?.basis_disclosure && <p>{card.basis_disclosure}</p>}
      {safeArray(card?.assumptions).length > 0 && (
        <details>
          <summary>Assumptions</summary>
          <ul>
            {card.assumptions.map((item) => <li key={item}>{item}</li>)}
          </ul>
        </details>
      )}
      <div className="curiosity-row" aria-label="Card actions">
        <button className="secondary-button" onClick={() => onOpenLineage(refs, card?.title)}>Show evidence</button>
        <button className="ghost-button" onClick={() => onExplain(card?.lineage_refs?.[0]?.metric_key || card?.lineage_display?.[0]?.metric_key)}>Ask Quickball</button>
      </div>
    </article>
  );
}

function ArrivalScreen({ onEnter, dataDate }) {
  return (
    <main className="arrival" aria-label="SCIP arrival">
      <section className="arrival-card glass-surface gold-edge">
        <div className="kicker">Sobha Collections Intelligence Platform</div>
        <h1 className="arrival-title">SCIP</h1>
        <p className="arrival-subtitle">Begin with the signal. Follow an intelligent briefing that can go as deep as you ask.</p>
        <div className="arrival-doors" aria-label="Primary entry choices">
          <button className="door-card glass-surface" onClick={() => onEnter("live_pulse")}>
            <span className="kicker">Live Pulse</span>
            <h2>What needs attention now?</h2>
            <p>Current signal, month movement, risk and action. No raw tree until you ask for depth.</p>
          </button>
          <button className="door-card glass-surface" onClick={() => onEnter("narratives")}>
            <span className="kicker">Narratives</span>
            <h2>The story behind the numbers.</h2>
            <p>Guided executive briefing: Story, Portfolio, Dues, Advance, Roadmap, and Present-ready outputs.</p>
          </button>
        </div>
        <p className="data-date-note">Data date: {dataDate || "Unavailable"}</p>
      </section>
      <QuickballCommand collapsedPrompt="Ask Quickball..." />
    </main>
  );
}

function ContextIsland({ route, focus, depth, role, setRole, payload }) {
  const world = route === "narratives" ? "Narratives" : "Live Pulse";
  const focusLabel = route === "narratives"
    ? (NARRATIVE_STEPS.find((item) => item.key === focus)?.label || "Story")
    : (LIVE_PULSE_CHOICES.find((item) => item.key === focus)?.title || "Current Signal");
  return (
    <section className="context-island glass-surface" aria-label="Current context">
      <div>
        <div className="kicker">{world}</div>
        <div className="context-row">
          <span className="context-pill">Focus: {focusLabel}</span>
          <span className="context-pill">Depth: {depth}</span>
          <span className="context-pill">Entity: Group</span>
          <span className="context-pill">Basis labels: Finance · MDO · R08 · R36</span>
          <span className="context-pill">Contract: {payload?.contract_version || "Unavailable"}</span>
        </div>
      </div>
      <label>
        <span className="kicker">Audience lens</span>{" "}
        <select className="context-select" value={role} onChange={(event) => setRole(event.target.value)} aria-label="Audience lens">
          {ROLE_ORDER.map((key) => <option key={key} value={key}>{ROLE_LABELS[key]}</option>)}
        </select>
      </label>
    </section>
  );
}

function WorldHome({ route, focus, setFocus }) {
  if (route === "narratives") {
    return (
      <section className="world-home glass-surface" aria-label="Narratives home">
        <div className="kicker">Narratives</div>
        <h2 className="world-headline">A guided boardroom journey, not a dashboard menu.</h2>
        <p className="world-summary">Move through Story, Portfolio, Dues, Advance and Roadmap. Evidence appears only when requested.</p>
        <nav className="narrative-rail" aria-label="Narrative steps">
          {NARRATIVE_STEPS.map((step) => (
            <button key={step.key} className="rail-button" aria-current={focus === step.key ? "step" : undefined} onClick={() => setFocus(step.key)}>
              {step.label}
            </button>
          ))}
        </nav>
      </section>
    );
  }

  return (
    <section className="world-home glass-surface" aria-label="Live Pulse home">
      <div className="kicker">Live Pulse</div>
      <h2 className="world-headline">Three choices only. One signal at a time.</h2>
      <p className="world-summary">Target Track/YTD remains available as a follow-up from Month Movement, not as a fourth first-level choice.</p>
      <div className="choice-grid">
        {LIVE_PULSE_CHOICES.map((choice) => (
          <button key={choice.key} className="choice-card glass-surface" aria-pressed={focus === choice.key} onClick={() => setFocus(choice.key)}>
            <span className="kicker">{choice.question}</span>
            <h3>{choice.title}</h3>
            <p>{choice.summary}</p>
          </button>
        ))}
      </div>
    </section>
  );
}

function FocusScreen({ route, focus, roleLabel, cards, forecast, onOpenLineage, onExplain, setFocus }) {
  const selectedCards = pickCardsForFocus(cards, route, focus);
  const copy = getPrimaryCopy(route, focus, roleLabel);
  const primaryCard = selectedCards[0];
  const question = route === "narratives"
    ? (NARRATIVE_STEPS.find((item) => item.key === focus)?.question || "What is the board-level story?")
    : (LIVE_PULSE_CHOICES.find((item) => item.key === focus)?.question || "Are we okay today?");

  return (
    <section className="focus-screen glass-surface" aria-label="Focus screen">
      <div className="focus-layout">
        <div>
          <p className="screen-question">{question}</p>
          <h2 className="primary-answer">{copy.answer}</h2>
          <p className="answer-copy">{copy.copy} {copy.roleHint}</p>
          <div className="curiosity-row" aria-label="Curiosity paths">
            <button className="curiosity-chip" onClick={() => onOpenLineage(primaryCard?.lineage_display || primaryCard?.lineage_refs || [], primaryCard?.title || "Evidence")}>Show evidence</button>
            <button className="curiosity-chip" onClick={() => onExplain(primaryCard?.lineage_refs?.[0]?.metric_key || primaryCard?.lineage_display?.[0]?.metric_key || "OD_TODAY")}>Ask about this number</button>
            {route === "live_pulse" && focus === "month_movement" ? (
              <button className="curiosity-chip" onClick={() => setFocus("target_track")}>Open Target Track/YTD lens</button>
            ) : (
              <button className="curiosity-chip" onClick={() => setFocus(route === "narratives" ? "dues" : "risk_action")}>What should we do?</button>
            )}
          </div>
        </div>
        <div className="primary-visual solid-truth gold-edge" aria-label="Primary visual">
          <div>
            <span className="kicker">Primary visual</span>
            <div className="visual-number">{primaryCard ? formatCardValue(primaryCard) : forecast?.display?.projected_month_end_landing || "—"}</div>
          </div>
          <p className="visual-caption">{primaryCard?.title || "Forecast landing"} · Reporting basis: {primaryCard?.reporting_basis || forecast?.reporting_basis || "Backend contract"}</p>
        </div>
      </div>

      <div className="kpi-strip" aria-label="Lineaged command-centre cards">
        {selectedCards.map((card) => (
          <CommandCentreCard key={card.card_id || card.title} card={card} onOpenLineage={onOpenLineage} onExplain={onExplain} />
        ))}
      </div>
    </section>
  );
}

function ActionQueuePanel({ actionQueues, workflows, role, focus, depth, onOpenLineage, onOpenWorkflow }) {
  if (focus !== "risk_action") return null;
  if (!actionQueues) {
    return (
      <section className="action-queue-panel solid-truth" aria-label="Action queues unavailable">
        <div className="panel-header-row">
          <div>
            <div className="kicker">Risk & Action · L5 output</div>
            <h2 className="panel-title">Action queues unavailable</h2>
            <p className="panel-sub">The backend did not provide action-queue data. No fallback actions are shown.</p>
          </div>
        </div>
      </section>
    );
  }

  const queueRole = actionQueues.roles?.[role] || actionQueues.roles?.cco_gm_agm || {};
  const accountActions = safeArray(queueRole.account_actions).slice(0, depth === "detailed" ? 10 : 5);
  const processActions = safeArray(queueRole.process_actions).slice(0, depth === "detailed" ? 8 : 4);
  const managementActions = safeArray(queueRole.management_actions).slice(0, depth === "detailed" ? 8 : 4);
  const blocked = safeArray(queueRole.blocked_actions).slice(0, 4);
  const showEvidenceTable = depth === "detailed";
  const workflowRecords = safeArray(workflows?.records);
  const workflowByActionId = new Map(workflowRecords.map((record) => [record.source_action_id, record]));

  return (
    <section className="action-queue-panel solid-truth" aria-label="Account-level action queues and collector drilldowns">
      <div className="panel-header-row">
        <div>
          <div className="kicker">Risk & Action · L5 output</div>
          <h2 className="panel-title">Action queues and collector drilldowns</h2>
          <p className="panel-sub">{queueRole.headline || "Action queue status unavailable."}</p>
        </div>
        <div className="queue-status-stack">
          <span className={`queue-status ${accountActions.length ? "ready" : "blocked"}`}>
            {accountActions.length ? "Account actions ready" : "No account actions"}
          </span>
          <span className="queue-basis">{queueRole.reporting_basis || actionQueues.status}</span>
          <span className="queue-basis">Workflow: {workflows?.summary?.state_counts?.queued ?? 0} queued / {workflows?.summary?.state_counts?.assigned ?? 0} assigned</span>
        </div>
      </div>

      <div className="blocked-source-banner" role="status">
        <strong>Account-level safety gate:</strong> {queueRole.disclosure || actionQueues.data_grain_disclosure?.rule}
      </div>

      {accountActions.length > 0 && (
        <div className="account-action-grid" aria-label="Lineaged account actions">
          {accountActions.map((item) => (
            <article className="account-action-card" key={item.action_id}>
              <div className="queue-card-topline">
                <span className={`severity-dot ${item.severity}`}></span>
                <span>{item.entity_display || "Entity"}</span>
                <span>{item.ageing_bucket || item.pr_status || "Status"}</span>
              </div>
              <h3>{item.title}</h3>
              <p>{item.summary}</p>
              <dl className="account-action-meta">
                <div><dt>Owner</dt><dd>{item.collector_rm_owner || "Unavailable"}</dd></div>
                <div><dt>Account</dt><dd>{item.account_id || "Unavailable"}</dd></div>
                <div><dt>Unit</dt><dd>{item.unit || "Unavailable"}</dd></div>
                <div><dt>Amount</dt><dd>{item.display_amount || "Unavailable"}</dd></div>
              </dl>
              {item.ptp_date && <p className="queue-note">PTP date: {item.ptp_date}</p>}
              <div className="queue-card-footer">
                <span>{item.reporting_basis}</span>
                <button className="secondary-button" onClick={() => onOpenLineage(item.lineage_refs || [], item.title)}>Lineage</button>
                <button className="primary-button" onClick={() => onOpenWorkflow(workflowByActionId.get(item.action_id), item)}>Workflow</button>
              </div>
            </article>
          ))}
        </div>
      )}

      {processActions.length > 0 && (
        <div className="action-cohort-grid" aria-label="Process and governance actions">
          {processActions.map((item) => (
            <article className="action-cohort-card" key={item.action_id}>
              <div className="queue-card-topline">
                <span className={`severity-dot ${item.severity}`}></span>
                <span>{item.action_type}</span>
                <span>{item.ageing_bucket}</span>
              </div>
              <h3>{item.title}</h3>
              <p>{item.summary}</p>
              <div className="queue-card-footer">
                <span>{item.display_amount}</span>
                <button className="secondary-button" onClick={() => onOpenLineage(item.lineage_refs || [], item.title)}>Lineage</button>
              </div>
            </article>
          ))}
        </div>
      )}

      {managementActions.length > 0 && role !== "collector_rm" && (
        <div className="action-cohort-grid" aria-label="Management escalation actions">
          {managementActions.map((item) => (
            <article className="action-cohort-card" key={item.action_id}>
              <div className="queue-card-topline">
                <span className={`severity-dot ${item.severity}`}></span>
                <span>{item.entity_display}</span>
                <span>{item.ageing_bucket}</span>
              </div>
              <h3>{item.title}</h3>
              <p>{item.summary}</p>
              <div className="queue-card-footer">
                <span>{item.display_amount}</span>
                <button className="secondary-button" onClick={() => onOpenLineage(item.lineage_refs || [], item.title)}>Lineage</button>
              </div>
            </article>
          ))}
        </div>
      )}

      {role === "collector_rm" && blocked.length > 0 && (
        <div className="blocked-actions-grid" aria-label="Blocked collector actions">
          {blocked.map((item) => (
            <article className="blocked-action-card" key={item.action_id}>
              <div className="queue-severity">{item.severity}</div>
              <h3>{item.title}</h3>
              <p>{item.blocked_reason}</p>
              <button className="secondary-button" onClick={() => onOpenLineage(item.lineage_refs || [], item.title)}>View source evidence</button>
            </article>
          ))}
        </div>
      )}

      {showEvidenceTable && accountActions.length > 0 && (
        <div className="solid-evidence-table" aria-label="Detailed account action evidence">
          <div className="evidence-table-row evidence-table-head">
            <span>Owner</span><span>Account</span><span>Unit</span><span>Status</span><span>Amount</span><span>Basis</span>
          </div>
          {accountActions.map((item) => (
            <div className="evidence-table-row" key={`row-${item.action_id}`}>
              <span>{item.collector_rm_owner}</span>
              <span>{item.account_id}</span>
              <span>{item.unit}</span>
              <span>{item.ageing_bucket || item.pr_status}</span>
              <span>{item.display_amount}</span>
              <span>{item.reporting_basis}</span>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}


function WorkflowDrawer({ open, record, sourceAction, onClose }) {
  if (!open) return null;
  const timeline = safeArray(record?.event_log || record?.events);
  const evidence = safeArray(record?.evidence_attachments);
  const source = record?.source_snapshot || sourceAction || {};
  return (
    <>
      <div className="drawer-backdrop" onClick={onClose} aria-hidden="true" />
      <aside className="workflow-drawer glass-surface" role="dialog" aria-modal="true" aria-label="Workflow assignment drawer">
        <div className="drawer-header">
          <div>
            <div className="kicker">L5 action output · Workflow</div>
            <h2 className="drawer-title">{record?.title || sourceAction?.title || "Workflow action"}</h2>
            <p className="drawer-sub">Assignment and closure tracking inherits the source action gate. Source lineage remains immutable.</p>
          </div>
          <button className="secondary-button" onClick={onClose}>Close</button>
        </div>
        <div className="workflow-grid">
          <div className="workflow-summary solid-truth">
            <div className="workflow-state-pill">{record?.workflow_state || "queued"}</div>
            <dl className="account-action-meta">
              <div><dt>Assigned owner</dt><dd>{record?.assigned_owner || source.collector_rm_owner || "Unavailable"}</dd></div>
              <div><dt>Account</dt><dd>{source.account_id || "Unavailable"}</dd></div>
              <div><dt>Unit</dt><dd>{source.unit || "Unavailable"}</dd></div>
              <div><dt>Due date</dt><dd>{record?.due_date || "Not set"}</dd></div>
              <div><dt>Amount/status</dt><dd>{source.display_amount || source.pr_status || "Unavailable"}</dd></div>
              <div><dt>Basis</dt><dd>{source.reporting_basis || sourceAction?.reporting_basis || "Unavailable"}</dd></div>
            </dl>
          </div>
          <div className="workflow-actions solid-truth">
            <h3>Allowed workflow updates</h3>
            <p>Assign, reassign, due date, disposition, evidence, and closure are backend operations. This drawer displays the contract without moving workflow logic into the frontend.</p>
            <div className="workflow-button-row">
              <button className="secondary-button">Assign</button>
              <button className="secondary-button">Set due date</button>
              <button className="secondary-button">Disposition</button>
              <button className="secondary-button">Attach evidence</button>
              <button className="primary-button">Close</button>
            </div>
          </div>
        </div>
        <div className="solid-evidence-table workflow-timeline" aria-label="Solid evidence timeline">
          <div className="evidence-table-row evidence-table-head">
            <span>Event</span><span>Actor</span><span>From</span><span>To</span><span>Lineage hash</span><span>Time</span>
          </div>
          {timeline.length === 0 && (
            <div className="evidence-table-row"><span>No events loaded</span><span /> <span /> <span /> <span /> <span /></div>
          )}
          {timeline.map((event) => (
            <div className="evidence-table-row" key={event.event_id}>
              <span>{event.event_type}</span>
              <span>{event.actor_role}</span>
              <span>{event.from_state}</span>
              <span>{event.to_state}</span>
              <span>{String(event.lineage_hash || "").slice(0, 10)}...</span>
              <span>{event.created_at}</span>
            </div>
          ))}
        </div>
        {evidence.length > 0 && (
          <div className="solid-evidence-table" aria-label="Evidence attachments">
            <div className="evidence-table-row evidence-table-head"><span>Type</span><span>Reference</span><span>By</span><span>At</span><span>Note</span><span /></div>
            {evidence.map((item) => (
              <div className="evidence-table-row" key={item.evidence_id}><span>{item.evidence_type}</span><span>{item.evidence_ref}</span><span>{item.attached_by}</span><span>{item.attached_at}</span><span>{item.note}</span><span /></div>
            ))}
          </div>
        )}
      </aside>
    </>
  );
}

function LineageDrawer({ open, title, refs, onClose }) {
  if (!open) return null;
  return (
    <>
      <div className="drawer-backdrop" onClick={onClose} aria-hidden="true" />
      <aside className="lineage-drawer glass-surface" role="dialog" aria-modal="true" aria-label="Lineage drawer">
        <div className="drawer-header">
          <div>
            <h2 className="drawer-title">{title || "Evidence"}</h2>
            <p className="drawer-sub">Source file, sheet, cell/range, validation, confidence and reporting basis. Evidence is shown only after request.</p>
          </div>
          <button className="secondary-button" onClick={onClose}>Close</button>
        </div>
        <div className="drawer-body">
          {safeArray(refs).length === 0 && <div className="lineage-block solid-truth">No lineage reference supplied by backend for this item.</div>}
          {safeArray(refs).map((ref, index) => (
            <div key={`${ref.metric_key || "metric"}-${index}`} className="lineage-block solid-truth">
              <div className="lineage-metric">{ref.metric_key || "Metric"}</div>
              <div className="lineage-grid">
                <span>Source</span><strong>{ref.source_file || "Unavailable"}</strong>
                <span>Sheet</span><strong>{ref.sheet || "Unavailable"}</strong>
                <span>Cell/range</span><strong>{ref.cell_or_range || "Unavailable"}</strong>
                <span>Validation</span><strong>{ref.validation_status || "Unavailable"}</strong>
                <span>Confidence</span><strong>{ref.confidence_state || "Unavailable"}</strong>
                <span>Basis</span><strong>{ref.reporting_basis || "Unavailable"}</strong>
              </div>
            </div>
          ))}
        </div>
      </aside>
    </>
  );
}

const QUICKBALL_PROMPTS = [
  { label: "Explain number", metric: "OD_TODAY" },
  { label: "Show basis", metric: "MTD_TOTAL_COLLECTIONS" },
  { label: "Board note", metric: "OD_TODAY" },
  { label: "Open actions", metric: "ACTION_QUEUE" },
];

function getStoredQuickballPosition() {
  if (typeof window === "undefined") return { x: 24, y: 24 };
  try {
    const saved = window.localStorage.getItem("scip.quickball.position");
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Number.isFinite(parsed.x) && Number.isFinite(parsed.y)) {
        return {
          x: Math.max(12, Math.min(parsed.x, window.innerWidth - 76)),
          y: Math.max(12, Math.min(parsed.y, window.innerHeight - 76)),
        };
      }
    }
  } catch {
    window.localStorage.removeItem("scip.quickball.position");
  }
  return { x: Math.max(16, window.innerWidth - 92), y: Math.max(16, window.innerHeight - 92) };
}

function QuickballCommand({ role, answer, onAsk, collapsedPrompt = "Ask about this number..." }) {
  const [metric, setMetric] = useState("");
  const [open, setOpen] = useState(false);
  const [asking, setAsking] = useState(false);
  const [position, setPosition] = useState(getStoredQuickballPosition);
  const dragRef = useRef(null);
  const movedRef = useRef(false);
  const blocked = answer?.status === "blocked_untrusted_metric";

  useEffect(() => {
    if (typeof window === "undefined") return undefined;
    const clampPosition = () => {
      setPosition((current) => {
        const next = {
          x: Math.max(12, Math.min(current.x, window.innerWidth - (open ? 356 : 76))),
          y: Math.max(12, Math.min(current.y, window.innerHeight - (open ? 264 : 76))),
        };
        window.localStorage.setItem("scip.quickball.position", JSON.stringify(next));
        return next;
      });
    };
    window.addEventListener("resize", clampPosition);
    return () => window.removeEventListener("resize", clampPosition);
  }, [open]);

  const persistPosition = useCallback((next) => {
    setPosition(next);
    if (typeof window !== "undefined") {
      window.localStorage.setItem("scip.quickball.position", JSON.stringify(next));
    }
  }, []);

  const onPointerDown = useCallback((event) => {
    dragRef.current = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      originX: position.x,
      originY: position.y,
    };
    movedRef.current = false;
    event.currentTarget.setPointerCapture?.(event.pointerId);
  }, [position.x, position.y]);

  const onPointerMove = useCallback((event) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    const dx = event.clientX - drag.startX;
    const dy = event.clientY - drag.startY;
    if (Math.abs(dx) + Math.abs(dy) > 4) movedRef.current = true;
    const width = open ? 356 : 76;
    const height = open ? 264 : 76;
    persistPosition({
      x: Math.max(12, Math.min(drag.originX + dx, window.innerWidth - width)),
      y: Math.max(12, Math.min(drag.originY + dy, window.innerHeight - height)),
    });
  }, [open, persistPosition]);

  const onPointerUp = useCallback((event) => {
    const wasMoved = movedRef.current;
    dragRef.current = null;
    event.currentTarget.releasePointerCapture?.(event.pointerId);
    if (wasMoved) {
      setOpen(false);
      navigator.vibrate?.(12);
      return;
    }
    setOpen((value) => !value);
    navigator.vibrate?.(8);
  }, []);

  const runAsk = useCallback(async (nextMetric) => {
    if (!onAsk || asking) return;
    const value = String(nextMetric || metric || "OD_TODAY").trim();
    setAsking(true);
    try {
      await onAsk(value, role);
      setMetric("");
      setOpen(false);
    } finally {
      setAsking(false);
    }
  }, [asking, metric, onAsk, role]);

  return (
    <section
      className={`quickball-floating glass-surface ${open ? "open" : ""} ${dragRef.current ? "dragging" : ""}`}
      style={{ left: position.x, top: position.y }}
      aria-label="Quickball command capsule"
    >
      <button
        type="button"
        className="quickball-floating-trigger"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        aria-expanded={open}
        aria-label={open ? "Collapse Quickball" : "Open Quickball"}
      >
        <span className="quickball-orb" />
        {open && <span className="quickball-floating-title">Quickball</span>}
      </button>

      {open && (
        <div className="quickball-floating-body">
          <div className="quickball-row compact">
            <input
              className="quickball-input"
              value={metric}
              onChange={(event) => setMetric(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter") runAsk(metric);
              }}
              placeholder={collapsedPrompt}
              aria-label="Ask Quickball"
            />
            <button className="primary-button" disabled={asking} onClick={() => runAsk(metric)}>
              {asking ? "Asking..." : "Ask"}
            </button>
          </div>
          <div className="quickball-prompt-list" aria-label="Quickball prompts">
            {QUICKBALL_PROMPTS.map((prompt) => (
              <button key={prompt.label} type="button" className="ghost-button" disabled={asking} onClick={() => runAsk(prompt.metric)}>
                {prompt.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {answer && (
        <div className={`quickball-answer quickball-floating-answer solid-truth ${blocked ? "blocked-warning" : ""}`} role={blocked ? "alert" : "status"}>
          <strong>{blocked ? "Quickball blocked an untrusted answer." : (answer.metric_label || answer.metric_key || "Quickball")}</strong>
          <p>{blocked ? (answer.reason || "A critical metric failed lineage validation.") : answer.answer}</p>
        </div>
      )}
    </section>
  );
}

function NotificationEscalationPanel({ notifications, role, focus, onOpenLineage }) {
  const items = safeArray(notifications?.notifications).filter((item) => !role || item.recipient_role === role).slice(0, 8);
  const digests = notifications?.digests || {};
  if (focus !== "risk_action") {
    return (
      <section className="notification-capsule glass-surface" aria-label="Notification automation gated">
        <div className="kicker">L5 notification output</div>
        <h3>Escalations stay behind Risk & Action.</h3>
        <p>Notifications are evidence-driven outputs, not a third Arrival door or separate dashboard.</p>
      </section>
    );
  }
  return (
    <section className="notification-panel glass-surface" aria-label="Notification and escalation automation">
      <div className="section-heading-row">
        <div>
          <div className="kicker">Batch 9 · Notifications</div>
          <h2>Escalation automation</h2>
          <p>Collector reminders, manager escalations, finance nudges, and MIS/QCG alerts only emit when source action lineage and workflow event lineage are present.</p>
        </div>
        <span className="status-pill">{notifications?.status || "unavailable"}</span>
      </div>
      <div className="notification-digest-grid">
        <DigestCard digest={digests.daily_live_pulse_risk_action} />
        <DigestCard digest={digests.weekly_management_review} />
      </div>
      <div className="solid-evidence-list" role="list">
        {items.length === 0 && <p className="muted">No notification emitted for this role. Missing evidence is blocked rather than guessed.</p>}
        {items.map((item) => (
          <article className="notification-row solid-truth" key={item.notification_id} role="listitem">
            <div>
              <div className="row-kicker">{item.severity} · {item.notification_type}</div>
              <h3>{item.title}</h3>
              <p>{item.message}</p>
              <p className="basis-line">Basis: {item.reporting_basis}</p>
              <p className="basis-line">Rule evidence: {item.rule_id} · Dedupe: {item.suppression?.dedupe_key}</p>
            </div>
            <div className="row-actions">
              <button className="secondary-button" onClick={() => onOpenLineage(item.lineage?.source_action_lineage_refs, item.title)}>Lineage</button>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}


function AuditExportPanel({ auditSummary, focus }) {
  if (focus !== "risk_action") {
    return (
      <section className="audit-export-capsule glass-surface" aria-label="Audit export gated">
        <div className="kicker">L5 audit output</div>
        <h3>Audit exports stay behind Risk & Action.</h3>
        <p>Persistence, audit export, and evidence packs remain output actions, not a third Arrival door.</p>
      </section>
    );
  }
  const counts = auditSummary?.table_counts || {};
  const validations = auditSummary?.validations?.checks || {};
  return (
    <section className="audit-export-panel glass-surface" aria-label="Durable audit export">
      <div className="section-heading-row">
        <div>
          <div className="kicker">Batch 10 · Persistence & Audit</div>
          <h2>Durable audit pack</h2>
          <p>Workflow records, workflow events, notification emissions, suppression state, and audit exports are persisted with immutable lineage hashes.</p>
        </div>
        <span className="status-pill">{auditSummary?.status || "unseeded"}</span>
      </div>
      <div className="notification-digest-grid">
        <article className="digest-card solid-truth">
          <div className="row-kicker">Persistence</div>
          <h3>{counts.workflow_records || 0} workflow records</h3>
          <p>{counts.notification_emissions || 0} notification emissions · {counts.suppression_state || 0} suppression keys</p>
        </article>
        <article className="digest-card solid-truth">
          <div className="row-kicker">Audit controls</div>
          <h3>{validations.lineage_triggers_block_tampering ? "Lineage immutable" : "Lineage validation pending"}</h3>
          <p>Closed workflows auditable: {validations.closed_records_remain_auditable ? "yes" : "pending"}</p>
        </article>
      </div>
      <div className="row-actions">
        <a className="secondary-button" href={`${BACKEND_URL}/audit/export?format=json`} target="_blank" rel="noreferrer">Export JSON audit pack</a>
        <a className="secondary-button" href={`${BACKEND_URL}/audit/export?format=csv`} target="_blank" rel="noreferrer">Export CSV audit pack</a>
      </div>
    </section>
  );
}

function DigestCard({ digest }) {
  if (!digest) return <div className="digest-card solid-truth"><h3>Digest unavailable</h3></div>;
  return (
    <article className="digest-card solid-truth">
      <div className="row-kicker">{digest.output_layer}</div>
      <h3>{digest.title}</h3>
      <p>{digest.notification_count || 0} evidence-backed notification(s)</p>
      <p className="basis-line">Dedupe: {digest.suppression?.dedupe_key}</p>
    </article>
  );
}


function IdentityPostureBar({ identity }) {
  const actor = identity?.actor || {};
  const mode = identity?.auth_mode || "jwt";
  return (
    <section className="identity-posture glass-surface" aria-label="SSO and JWT identity posture">
      <span className="eyebrow">Identity</span>
      <strong>{actor.actor_name || "Verified actor required"}</strong>
      <p className="basis-line">SSO/JWT actor identity · mode {mode} · local-dev bypass only when explicitly enabled.</p>
      <div className="security-chip-row">
        <span className="glass-chip">Role: {actor.role_label || actor.role || "unverified"}</span>
        <span className="glass-chip">Scope: {(actor.entity_scope || []).join(", ") || "none"}</span>
        <span className="glass-chip">Collector: {actor.collector_id || "not scoped"}</span>
      </div>
    </section>
  );
}

function ObservabilityPanel({ observability, dashboards, alerts, focus }) {
  if (focus !== "risk_action") return null;
  const counters = observability?.counters || {};
  const timings = observability?.timings || {};
  const activeAlerts = alerts?.alerts || observability?.active_alerts || [];
  const dashboardList = dashboards?.dashboards || [];
  return (
    <section className="solid-evidence-card observability-panel" aria-label="Production observability">
      <div className="section-heading-row">
        <div>
          <p className="eyebrow">L5 governance output</p>
          <h2>Production observability</h2>
          <p className="basis-line">Correlation IDs, redacted structured logs, API timings, lineage coverage and security alerts remain backend-governed.</p>
        </div>
        <span className="basis-pill">{observability?.contract_version || "observability unavailable"}</span>
      </div>
      <div className="metric-grid compact">
        <article className="solid-mini-card">
          <span>Events</span>
          <strong>{observability?.event_count ?? "—"}</strong>
        </article>
        <article className="solid-mini-card">
          <span>API error rate</span>
          <strong>{observability?.api_error_rate_pct ?? "—"}%</strong>
        </article>
        <article className="solid-mini-card">
          <span>RBAC denials</span>
          <strong>{counters.rbac_denials_total ?? 0}</strong>
        </article>
        <article className="solid-mini-card">
          <span>Cache invalidations</span>
          <strong>{counters.cache_invalidations_total ?? 0}</strong>
        </article>
      </div>
      <div className="evidence-grid two-col">
        <article className="solid-mini-card">
          <span>API request p95</span>
          <strong>{timings.api_request_latency_ms?.p95_ms ?? "—"} ms</strong>
          <p className="basis-line">Measured server-side. No business computation moved into the frontend.</p>
        </article>
        <article className="solid-mini-card">
          <span>Frontend render p95</span>
          <strong>{timings.frontend_render_ms?.p95_ms ?? "—"} ms</strong>
          <p className="basis-line">Render timing only; financial values stay backend-calculated.</p>
        </article>
      </div>
      <div className="evidence-list">
        <h3>Active alert posture</h3>
        {activeAlerts.length ? activeAlerts.slice(0, 5).map((alert) => (
          <p key={alert.alert_key} className="basis-line">{alert.severity}: {alert.alert_key} · threshold {alert.threshold} · actual {alert.actual}</p>
        )) : <p className="basis-line">No active alerts from the latest evaluation.</p>}
      </div>
      <div className="evidence-list">
        <h3>Dashboard specs</h3>
        {dashboardList.slice(0, 4).map((item) => (
          <p key={item.dashboard_id} className="basis-line">{item.title}: {item.surface}</p>
        ))}
      </div>
    </section>
  );
}

export default function App() {
  const [payload, setPayload] = useState(null);
  const [forecast, setForecast] = useState(null);
  const [actionQueues, setActionQueues] = useState(null);
  const [workflows, setWorkflows] = useState(null);
  const [notifications, setNotifications] = useState(null);
  const [auditSummary, setAuditSummary] = useState(null);
  const [security, setSecurity] = useState(null);
  const [identity, setIdentity] = useState(null);
  const [deploymentHealth, setDeploymentHealth] = useState(null);
  const [observability, setObservability] = useState(null);
  const [observabilityDashboards, setObservabilityDashboards] = useState(null);
  const [observabilityAlerts, setObservabilityAlerts] = useState(null);
  const [role, setRole] = useState("board_cxo");
  const [route, setRoute] = useState("arrival");
  const [focus, setFocus] = useState("current_signal");
  const [depth, setDepth] = useState("summary");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [drawer, setDrawer] = useState({ open: false, title: "", refs: [] });
  const [workflowDrawer, setWorkflowDrawer] = useState({ open: false, record: null, sourceAction: null });
  const [quickballAnswer, setQuickballAnswer] = useState(null);
  const [roleRefreshing, setRoleRefreshing] = useState(false);

  useEffect(() => {
    let cancelled = false;

    const fetchJson = async (path, headers, fallback = null) => {
      try {
        const res = await fetch(`${BACKEND_URL}${path}`, { headers });
        if (!res.ok) {
          if (fallback !== null) return fallback;
          throw new Error(`${path} ${res.status}`);
        }
        return await res.json();
      } catch (err) {
        if (fallback !== null) return { ...fallback, error: err.message };
        throw err;
      }
    };

    async function load() {
      const initialLoad = !payload;
      if (initialLoad) setLoading(true);
      if (!initialLoad) setRoleRefreshing(true);
      setError(null);

      try {
        const headers = authHeaders(role);

        // Product UAT blocking set only. Optional governance/security surfaces
        // refresh below and must not freeze role switch or Quickball.
        const [centresJson, forecastJson, actionQueuesJson, workflowsJson] = await Promise.all([
          fetchJson("/command-centres", headers),
          fetchJson("/forecast/month-end", headers),
          fetchJson("/action-queues", headers),
          fetchJson("/workflows", headers),
        ]);

        if (!cancelled) {
          setPayload(centresJson);
          setForecast(forecastJson);
          setActionQueues(actionQueuesJson);
          setWorkflows(workflowsJson);
          setLoading(false);
          setRoleRefreshing(false);
        }

        // UAT-only optional surfaces. They are useful diagnostics, but should
        // never block Arrival, Live Pulse, role switch, or Quickball.
        const [notificationsJson, auditJson, securityJson, identityJson, deploymentJson, observabilityJson, observabilityDashboardsJson, observabilityAlertsJson] = await Promise.all([
          fetchJson("/notifications", headers, { notifications: [], status: "unavailable" }),
          fetchJson("/persistence/summary", headers, { status: "unavailable" }),
          fetchJson("/security/me", headers, { status: "unavailable", actor: { role } }),
          fetchJson("/identity/me", headers, { status: "unavailable" }),
          fetchJson("/deployment/health", headers, { status: "unavailable" }),
          fetchJson("/observability/summary", headers, { status: "unavailable" }),
          fetchJson("/observability/dashboards", headers, { dashboards: [] }),
          fetchJson("/observability/alerts", headers, { alerts: [] }),
        ]);

        if (!cancelled) {
          setNotifications(notificationsJson);
          setAuditSummary(auditJson);
          setSecurity(securityJson);
          setIdentity(identityJson);
          setDeploymentHealth(deploymentJson);
          setObservability(observabilityJson);
          setObservabilityDashboards(observabilityDashboardsJson);
          setObservabilityAlerts(observabilityAlertsJson);
        }
      } catch (err) {
        if (!cancelled) setError(err.message);
      } finally {
        if (!cancelled) {
          setLoading(false);
          setRoleRefreshing(false);
        }
      }
    }

    load();
    return () => { cancelled = true; };
  }, [role]);

  useEffect(() => {
    const start = performance.now();
    const frame = requestAnimationFrame(() => {
      const duration = performance.now() - start;
      const headers = authHeaders(role);
      fetch(`${BACKEND_URL}/observability/frontend-timing`, {
        method: "POST",
        headers: { ...headers, "Content-Type": "application/json" },
        body: JSON.stringify({ route, view: focus, duration_ms: duration, device: { reducedMotion: window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches || false } }),
      }).catch(() => {});
    });
    return () => cancelAnimationFrame(frame);
  }, [route, focus, role]);

  const activeRole = payload?.roles?.[role] || payload?.roles?.board_cxo || {};
  const trustBar = activeRole?.trust_bar || payload?.roles?.board_cxo?.trust_bar;
  const cards = useMemo(() => safeArray(activeRole?.cards), [activeRole]);
  const roleLabel = ROLE_LABELS[role] || "Board/CXO";

  const openLineage = useCallback((refs, title) => setDrawer({ open: true, title, refs: refs || [] }), []);
  const closeLineage = useCallback(() => setDrawer({ open: false, title: "", refs: [] }), []);
  const openWorkflow = useCallback((record, sourceAction) => {
    const events = safeArray(workflows?.event_log).filter((event) => event.source_action_id === (record?.source_action_id || sourceAction?.action_id));
    setWorkflowDrawer({ open: true, record: record ? { ...record, event_log: events } : null, sourceAction });
  }, [workflows]);
  const closeWorkflow = useCallback(() => setWorkflowDrawer({ open: false, record: null, sourceAction: null }), []);

  const enterWorld = useCallback((nextRoute) => {
    setRoute(nextRoute);
    setFocus(nextRoute === "narratives" ? "story" : "current_signal");
    setDepth(nextRoute === "narratives" ? "executive" : "summary");
  }, [role]);

  const askQuickball = useCallback(async (metric, roleKey) => {
    try {
      const params = new URLSearchParams({ metric: metric || "OD_TODAY", role: roleKey || role });
      const res = await fetch(`${BACKEND_URL}/quickball/explain?${params.toString()}`, { headers: authHeaders(roleKey || role) });
      if (!res.ok) throw new Error(`Quickball ${res.status}`);
      const json = await res.json();
      const actions = safeArray(json.follow_up_actions).slice(0, 2);
      setQuickballAnswer({ ...json, follow_up_actions: actions });
    } catch (err) {
      setQuickballAnswer({ status: "blocked_untrusted_metric", reason: err.message, answer: "Quickball is unavailable." });
    }
  }, [role]);

  if (loading) {
    return <main className="loading-screen">Loading SCIP Liquid Glass command surface...</main>;
  }

  if (error) {
    return (
      <main className="loading-screen" role="alert">
        <section className="error-card solid-truth">
          <h1>SCIP unavailable</h1>
          <p>{error}</p>
          <p>No fallback figures are shown. Backend data must be live and lineaged.</p>
        </section>
      </main>
    );
  }

  if (route === "arrival") {
    return <ArrivalScreen onEnter={enterWorld} dataDate={trustBar?.snapshot_date} />;
  }

  return (
    <main className="scip-app">
      <div className="liquid-page">
        <header className="top-chrome" aria-label="SCIP header">
          <div>
            <div className="kicker">SCIP Batch 12 · Observable Liquid Glass</div>
            <h1 className="brand-title">{route === "narratives" ? "Narratives" : "Live Pulse"}</h1>
          </div>
          <div className="chrome-actions">
            <button className="ghost-button" onClick={() => setRoute("arrival")}>Home</button>
            <button className="secondary-button" onClick={() => enterWorld("live_pulse")}>Live Pulse</button>
            <button className="secondary-button" onClick={() => enterWorld("narratives")}>Narratives</button>
            <button className="ghost-button" onClick={() => setDepth(depth === "detailed" ? (route === "narratives" ? "executive" : "summary") : "detailed")}>{depth === "detailed" ? "Reduce depth" : "Detailed"}</button>
          </div>
        </header>

        <ContextIsland route={route} focus={focus} depth={depth} role={role} setRole={setRole} payload={payload} />
        {roleRefreshing && <div className="context-refresh glass-surface" role="status">Refreshing role lens...</div>}
        <SecurityPostureBar security={security} role={role} />
        <IdentityPostureBar identity={identity} />
        <DataConfidenceTrustBar trustBar={trustBar} guardrails={payload?.guardrails} />
        <WorldHome route={route} focus={focus} setFocus={setFocus} />
        <FocusScreen route={route} focus={focus} roleLabel={roleLabel} cards={cards} forecast={forecast || payload?.forecast} onOpenLineage={openLineage} onExplain={(metric) => askQuickball(metric, role)} setFocus={setFocus} />
        {route === "live_pulse" && (focus === "month_movement" || focus === "target_track") && <ForecastPanel forecast={forecast || payload?.forecast} onOpenLineage={openLineage} />}
        {route === "live_pulse" && <ActionQueuePanel actionQueues={actionQueues} workflows={workflows} role={role} focus={focus} depth={depth} onOpenLineage={openLineage} onOpenWorkflow={openWorkflow} />}
        <NotificationEscalationPanel notifications={notifications} role={role} focus={focus} onOpenLineage={openLineage} />
        <AuditExportPanel auditSummary={auditSummary} focus={focus} />
        <ObservabilityPanel observability={observability} dashboards={observabilityDashboards} alerts={observabilityAlerts} focus={focus} />
        <WorkflowDrawer open={workflowDrawer.open} record={workflowDrawer.record} sourceAction={workflowDrawer.sourceAction} onClose={closeWorkflow} />
        <LineageDrawer open={drawer.open} title={drawer.title} refs={drawer.refs} onClose={closeLineage} />
      </div>
      <QuickballCommand role={role} answer={quickballAnswer} onAsk={askQuickball} collapsedPrompt={route === "narratives" ? "Ask for board explanation..." : "Ask about today's movement..."} />
    </main>
  );
}
```


---

## `SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/src/scipPowerUatQuickball.css`


```css
/*
 * SCIP Power UAT Quickball refinement overlay.
 * Safe UI-only enhancement: floating, draggable, quiet Quickball shell.
 * No frontend business computation, no fallback figures, no metric derivation.
 */

.quickball-floating {
  position: fixed;
  z-index: 60;
  width: 64px;
  min-height: 64px;
  border-radius: 999px;
  overflow: visible;
  touch-action: none;
  user-select: none;
  transition:
    width 180ms ease,
    min-height 180ms ease,
    border-radius 180ms ease,
    transform 160ms ease,
    box-shadow 160ms ease;
}

.quickball-floating.open {
  width: min(340px, calc(100vw - 32px));
  min-height: 232px;
  border-radius: 28px;
}

.quickball-floating.dragging {
  transform: scale(1.035);
  box-shadow: 0 28px 80px rgba(31, 41, 55, 0.15);
}

.quickball-floating-trigger {
  position: relative;
  display: grid;
  width: 64px;
  height: 64px;
  place-items: center;
  padding: 0;
  border: 0;
  border-radius: 999px;
  background: transparent;
  cursor: grab;
}

.quickball-floating-trigger:active {
  cursor: grabbing;
}

.quickball-floating.open .quickball-floating-trigger {
  width: 100%;
  height: 68px;
  grid-template-columns: 64px 1fr;
  justify-items: start;
}

.quickball-orb {
  display: block;
  width: 42px;
  height: 42px;
  border-radius: 999px;
  background:
    radial-gradient(circle at 35% 28%, rgba(255, 255, 255, 0.96), rgba(255, 255, 255, 0.42) 46%, rgba(47, 69, 95, 0.18) 100%);
  border: 1px solid rgba(255, 255, 255, 0.72);
  box-shadow:
    inset 0 1px 10px rgba(255, 255, 255, 0.7),
    0 12px 30px rgba(47, 69, 95, 0.14);
}

.quickball-floating-title {
  color: var(--text-muted, #657083);
  font-size: 0.9rem;
  font-weight: 500;
  letter-spacing: 0.01em;
}

.quickball-floating-body {
  display: grid;
  gap: 12px;
  padding: 0 18px 18px;
}

.quickball-row.compact {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 8px;
  align-items: center;
}

.quickball-prompt-list {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
}

.quickball-prompt-list .ghost-button {
  min-height: 36px;
  text-align: left;
  white-space: normal;
}

.quickball-floating-answer {
  position: absolute;
  right: 0;
  bottom: calc(100% + 10px);
  width: min(340px, calc(100vw - 32px));
  max-height: 260px;
  overflow: auto;
  box-shadow: 0 24px 60px rgba(31, 41, 55, 0.16);
}

.quickball-floating.open .quickball-floating-answer {
  position: static;
  width: auto;
  margin: 0 18px 18px;
}

.quickball-floating .primary-button:disabled,
.quickball-floating .ghost-button:disabled {
  cursor: wait;
  opacity: 0.62;
}

@media (max-width: 720px) {
  .quickball-floating.open {
    width: min(320px, calc(100vw - 24px));
  }

  .quickball-prompt-list {
    grid-template-columns: 1fr;
  }

  .quickball-floating-answer {
    width: min(320px, calc(100vw - 24px));
  }
}
```


---

## `SCIP_speed_ui_quickball_combined_patch/env/render_env_additions.env`


```bash
SCIP_DATA_CACHE_TTL_SECONDS=900
SCIP_ACTION_QUEUE_CACHE_TTL_SECONDS=900
SCIP_WARM_DATA_CACHE_ON_STARTUP=true
SCIP_SOURCE_ROOT=/tmp/scip/r-series
```


---

## `SCIP_speed_ui_quickball_combined_patch/smoke/smoke_cache_speed.sh`


```bash
#!/usr/bin/env bash
set -euo pipefail
BASE_URL="${1:-https://scip.onrender.com}"

echo "Cache status before:"
curl -sS "$BASE_URL/cache/status" | python -m json.tool || true

echo "First Quickball request:"
time curl -sS "$BASE_URL/quickball/explain?metric=OD_TODAY&role=board_cxo" >/tmp/scip_quickball_1.json
python -m json.tool </tmp/scip_quickball_1.json | head -80

echo "Second Quickball request, should be faster if cache is warm:"
time curl -sS "$BASE_URL/quickball/explain?metric=MTD_TOTAL_COLLECTIONS&role=board_cxo" >/tmp/scip_quickball_2.json
python -m json.tool </tmp/scip_quickball_2.json | head -80

echo "Cache status after:"
curl -sS "$BASE_URL/cache/status" | python -m json.tool || true
```


---

## `SCIP_speed_ui_quickball_combined_patch/patches/scip_speed_quickball_cache_patch.diff`


```diff
diff -ruN original/go-live-rc1/Backend/account_action_queues.py patched/go-live-rc1/Backend/account_action_queues.py
--- original/go-live-rc1/Backend/account_action_queues.py	2026-05-12 11:31:08.000000000 +0000
+++ patched/go-live-rc1/Backend/account_action_queues.py	2026-05-12 13:34:39.325596692 +0000
@@ -20,6 +20,10 @@
 
 from __future__ import annotations
 
+import copy
+import os
+import threading
+import time
 from dataclasses import dataclass, asdict
 from datetime import date, datetime
 from pathlib import Path
@@ -934,10 +938,63 @@
     return sorted(items, key=lambda x: (x.get("severity") == "risk", float(x.get("amount_aed") or 0)), reverse=True)[:limit]
 
 
-def build_action_queue_payload(data_dir: Optional[Path | str] = None, role: Optional[str] = None) -> Dict[str, Any]:
-    base = Path(data_dir or Path(__file__).resolve().parent)
+_ACTION_QUEUE_CACHE_LOCK = threading.RLock()
+_ACTION_QUEUE_CACHE: Dict[Tuple[str, str], Tuple[float, Dict[str, Any]]] = {}
+_ACTION_QUEUE_CACHE_HITS = 0
+_ACTION_QUEUE_CACHE_MISSES = 0
+
+
+def _action_cache_ttl_seconds() -> int:
+    try:
+        return int(os.environ.get("SCIP_ACTION_QUEUE_CACHE_TTL_SECONDS", os.environ.get("SCIP_DATA_CACHE_TTL_SECONDS", "900")))
+    except ValueError:
+        return 900
+
+
+def _resolve_action_data_dir(data_dir: Optional[Path | str] = None) -> Path:
+    base = Path(
+        data_dir
+        or os.environ.get("SCIP_SOURCE_ROOT")
+        or os.environ.get("DATA_DIR")
+        or Path(__file__).resolve().parent
+    ).resolve()
     if not any(base.glob("R10*.xlsx")) and Path("/mnt/data").exists():
-        base = Path("/mnt/data")
+        fallback = Path("/mnt/data").resolve()
+        if any(fallback.glob("R10*.xlsx")):
+            base = fallback
+    return base
+
+
+def invalidate_action_queue_cache() -> None:
+    global _ACTION_QUEUE_CACHE
+    with _ACTION_QUEUE_CACHE_LOCK:
+        _ACTION_QUEUE_CACHE = {}
+
+
+def get_action_queue_cache_status() -> Dict[str, Any]:
+    now = time.time()
+    with _ACTION_QUEUE_CACHE_LOCK:
+        entries = []
+        for (data_dir, role), (loaded_at, payload) in _ACTION_QUEUE_CACHE.items():
+            entries.append({
+                "data_dir": data_dir,
+                "role": role,
+                "age_seconds": round(now - loaded_at, 3),
+                "status": payload.get("status"),
+            })
+        return {
+            "status": "warm" if entries else "cold",
+            "ttl_seconds": _action_cache_ttl_seconds(),
+            "entries": entries,
+            "hits": _ACTION_QUEUE_CACHE_HITS,
+            "misses": _ACTION_QUEUE_CACHE_MISSES,
+            "lineage_preserved": True,
+            "no_silent_fallback": True,
+        }
+
+
+def _build_action_queue_payload_uncached(data_dir: Optional[Path | str] = None, role: Optional[str] = None) -> Dict[str, Any]:
+    base = _resolve_action_data_dir(data_dir)
     extracted = _extract_all(base)
     lookups = _build_lookups(extracted)
     term_by_key = lookups["termination"]
@@ -1065,6 +1122,48 @@
     }
 
 
+def build_action_queue_payload(
+    data_dir: Optional[Path | str] = None,
+    role: Optional[str] = None,
+    *,
+    force_refresh: bool = False,
+) -> Dict[str, Any]:
+    """Return role-scoped action queues using a short in-memory cache.
+
+    This keeps role switch and Risk & Action navigation from reparsing the
+    account/action workbooks on every click. RBAC filtering still runs after this
+    function in the route layer, so a deep copy is returned to avoid mutating the
+    shared cached payload.
+    """
+    global _ACTION_QUEUE_CACHE_HITS, _ACTION_QUEUE_CACHE_MISSES
+    base = _resolve_action_data_dir(data_dir)
+    role_key = role or "__all__"
+    cache_key = (str(base), role_key)
+    ttl = _action_cache_ttl_seconds()
+    now = time.time()
+
+    if ttl > 0 and not force_refresh:
+        with _ACTION_QUEUE_CACHE_LOCK:
+            cached = _ACTION_QUEUE_CACHE.get(cache_key)
+            if cached and now - cached[0] <= ttl:
+                _ACTION_QUEUE_CACHE_HITS += 1
+                return copy.deepcopy(cached[1])
+
+    with _ACTION_QUEUE_CACHE_LOCK:
+        now = time.time()
+        if ttl > 0 and not force_refresh:
+            cached = _ACTION_QUEUE_CACHE.get(cache_key)
+            if cached and now - cached[0] <= ttl:
+                _ACTION_QUEUE_CACHE_HITS += 1
+                return copy.deepcopy(cached[1])
+
+        _ACTION_QUEUE_CACHE_MISSES += 1
+        payload = _build_action_queue_payload_uncached(data_dir=base, role=role)
+        if ttl > 0:
+            _ACTION_QUEUE_CACHE[cache_key] = (time.time(), payload)
+        return copy.deepcopy(payload)
+
+
 def _sample_lineage_refs(roles: Dict[str, Any]) -> List[Dict[str, Any]]:
     refs: List[Dict[str, Any]] = []
     for payload in roles.values():
diff -ruN original/go-live-rc1/Backend/data_loader.py patched/go-live-rc1/Backend/data_loader.py
--- original/go-live-rc1/Backend/data_loader.py	2026-05-12 11:31:08.000000000 +0000
+++ patched/go-live-rc1/Backend/data_loader.py	2026-05-12 13:34:39.323447255 +0000
@@ -29,9 +29,12 @@
 
 from __future__ import annotations
 
+import copy
 import json
 import logging
 import os
+import threading
+import time
 from datetime import datetime, date
 from pathlib import Path
 from typing import Any, Optional
@@ -54,8 +57,45 @@
 # Resolve /data directory relative to this file's location.
 # In deployment: backend/ sits next to data/ at repo root.
 _HERE = Path(__file__).parent
-DATA_DIR = (_HERE.parent / "data").resolve()
+DEFAULT_DATA_DIR = (_HERE.parent / "data").resolve()
+DATA_DIR = Path(
+    os.environ.get("SCIP_SOURCE_ROOT")
+    or os.environ.get("DATA_DIR")
+    or DEFAULT_DATA_DIR
+).resolve()
 PIPELINE_CONFIG_PATH = (_HERE / "pipeline_config.json").resolve()
+logger.info("SCIP data source directory resolved to: %s", DATA_DIR)
+
+# ---------------------------------------------------------------------------
+# STAGING/UAT CACHE
+# ---------------------------------------------------------------------------
+# Render Free + Google Drive bootstrap + Excel parsing can make every request
+# expensive if endpoints call load_all() directly. The cache below keeps the
+# lineage-bearing server payload in memory for a short TTL. It does not compute
+# or fabricate business numbers; it only reuses the last trusted loader output.
+_DATA_CACHE_LOCK = threading.RLock()
+_DATA_CACHE_PAYLOAD: Optional[dict] = None
+_DATA_CACHE_LOADED_AT: Optional[float] = None
+_DATA_CACHE_DIR: Optional[str] = None
+_DATA_CACHE_HITS = 0
+_DATA_CACHE_MISSES = 0
+
+
+def _cache_ttl_seconds() -> int:
+    try:
+        return int(os.environ.get("SCIP_DATA_CACHE_TTL_SECONDS", "900"))
+    except ValueError:
+        return 900
+
+
+def _resolve_active_data_dir(data_dir: Optional[Path | str] = None) -> Path:
+    if data_dir:
+        return Path(data_dir).resolve()
+    return Path(
+        os.environ.get("SCIP_SOURCE_ROOT")
+        or os.environ.get("DATA_DIR")
+        or DATA_DIR
+    ).resolve()
 
 
 # ---------------------------------------------------------------------------
@@ -996,6 +1036,93 @@
     }
 
 
+def get_cached_payload(
+    data_dir: Optional[Path | str] = None,
+    *,
+    force_refresh: bool = False,
+    ttl_seconds: Optional[int] = None,
+    copy_payload: bool = False,
+) -> dict:
+    """Return the trusted data loader payload using a short in-memory cache.
+
+    This is the performance-critical entry point for FastAPI endpoints. It keeps
+    Quickball, command centres, and forecast from reparsing every Excel workbook
+    on each click or role change. The payload still contains the original
+    lineage, validation status, confidence state and missing-source disclosure.
+
+    Set SCIP_DATA_CACHE_TTL_SECONDS=0 to disable caching. Use force_refresh=True
+    only for an explicit source-refresh action, not for role switch or Quickball.
+    """
+    global _DATA_CACHE_PAYLOAD, _DATA_CACHE_LOADED_AT, _DATA_CACHE_DIR
+    global _DATA_CACHE_HITS, _DATA_CACHE_MISSES
+
+    active_dir = _resolve_active_data_dir(data_dir)
+    cache_dir = str(active_dir)
+    ttl = _cache_ttl_seconds() if ttl_seconds is None else int(ttl_seconds)
+    now = time.time()
+
+    if ttl > 0 and not force_refresh:
+        with _DATA_CACHE_LOCK:
+            is_valid = (
+                _DATA_CACHE_PAYLOAD is not None
+                and _DATA_CACHE_LOADED_AT is not None
+                and _DATA_CACHE_DIR == cache_dir
+                and now - _DATA_CACHE_LOADED_AT <= ttl
+            )
+            if is_valid:
+                _DATA_CACHE_HITS += 1
+                logger.debug("SCIP data cache hit: dir=%s age=%.2fs", cache_dir, now - _DATA_CACHE_LOADED_AT)
+                return copy.deepcopy(_DATA_CACHE_PAYLOAD) if copy_payload else _DATA_CACHE_PAYLOAD
+
+    with _DATA_CACHE_LOCK:
+        now = time.time()
+        if ttl > 0 and not force_refresh:
+            is_valid = (
+                _DATA_CACHE_PAYLOAD is not None
+                and _DATA_CACHE_LOADED_AT is not None
+                and _DATA_CACHE_DIR == cache_dir
+                and now - _DATA_CACHE_LOADED_AT <= ttl
+            )
+            if is_valid:
+                _DATA_CACHE_HITS += 1
+                logger.debug("SCIP data cache hit after lock: dir=%s", cache_dir)
+                return copy.deepcopy(_DATA_CACHE_PAYLOAD) if copy_payload else _DATA_CACHE_PAYLOAD
+
+        _DATA_CACHE_MISSES += 1
+        logger.info("SCIP data cache miss; loading source payload: dir=%s force_refresh=%s", cache_dir, force_refresh)
+        payload = load_all(data_dir=active_dir)
+        if ttl > 0:
+            _DATA_CACHE_PAYLOAD = payload
+            _DATA_CACHE_LOADED_AT = time.time()
+            _DATA_CACHE_DIR = cache_dir
+        return copy.deepcopy(payload) if copy_payload else payload
+
+
+def invalidate_cache() -> None:
+    """Clear the in-memory data payload cache."""
+    global _DATA_CACHE_PAYLOAD, _DATA_CACHE_LOADED_AT, _DATA_CACHE_DIR
+    with _DATA_CACHE_LOCK:
+        _DATA_CACHE_PAYLOAD = None
+        _DATA_CACHE_LOADED_AT = None
+        _DATA_CACHE_DIR = None
+
+
+def get_cache_status() -> dict:
+    now = time.time()
+    age = None if _DATA_CACHE_LOADED_AT is None else round(now - _DATA_CACHE_LOADED_AT, 3)
+    return {
+        "status": "warm" if _DATA_CACHE_PAYLOAD is not None else "cold",
+        "data_dir": _DATA_CACHE_DIR,
+        "loaded_at_epoch": _DATA_CACHE_LOADED_AT,
+        "age_seconds": age,
+        "ttl_seconds": _cache_ttl_seconds(),
+        "hits": _DATA_CACHE_HITS,
+        "misses": _DATA_CACHE_MISSES,
+        "lineage_preserved": True,
+        "no_silent_fallback": True,
+    }
+
+
 def get_source_rows(payload: dict, source_id: str) -> list[dict]:
     """
     Helper for endpoint functions to extract rows from a loaded source.
diff -ruN original/go-live-rc1/Backend/file_resolver.py patched/go-live-rc1/Backend/file_resolver.py
--- original/go-live-rc1/Backend/file_resolver.py	2026-05-12 11:31:08.000000000 +0000
+++ patched/go-live-rc1/Backend/file_resolver.py	2026-05-12 13:34:39.324820064 +0000
@@ -27,13 +27,13 @@
 logger = logging.getLogger(__name__)
 
 VALID_R_CODES = {
-    "R01", "R02", "R03", "R04", "R05", "R06", "R07", "R08",
+    "R01", "R02", "R03", "R04", "R05", "R06", "R07", "R08", "R09",
     "R10", "R12", "R13", "R16", "R17", "R18", "R20", "R25", "R26",
     "R27", "R28", "R29", "R30", "R31", "R32", "R34", "R35", "R36",
     "R37", "R38"
 }
 
-R_CODE_PATTERN = re.compile(r"^(R\d+)(?:_.*)?\.(xlsx|xlsb)$", re.IGNORECASE)
+R_CODE_PATTERN = re.compile(r"^(R\d{1,2})(?:[_\s-].*)?\.(xlsx|xlsb)$", re.IGNORECASE)
 
 
 def resolve_r_series(data_dir):
diff -ruN original/go-live-rc1/Backend/forecast.py patched/go-live-rc1/Backend/forecast.py
--- original/go-live-rc1/Backend/forecast.py	2026-05-12 11:31:08.000000000 +0000
+++ patched/go-live-rc1/Backend/forecast.py	2026-05-12 13:34:39.324429936 +0000
@@ -257,8 +257,10 @@
     return forecast
 
 
-def load_payload(data_dir: Optional[str] = None) -> Dict[str, Any]:
+def load_payload(data_dir: Optional[str] = None, *, force_refresh: bool = False) -> Dict[str, Any]:
     path = Path(data_dir) if data_dir else None
+    if hasattr(data_loader, "get_cached_payload"):
+        return data_loader.get_cached_payload(data_dir=path, force_refresh=force_refresh)
     return data_loader.load_all(data_dir=path)
 
 
diff -ruN original/go-live-rc1/Backend/main.py patched/go-live-rc1/Backend/main.py
--- original/go-live-rc1/Backend/main.py	2026-05-12 11:31:08.000000000 +0000
+++ patched/go-live-rc1/Backend/main.py	2026-05-12 13:34:39.326044214 +0000
@@ -16,6 +16,14 @@
 from fastapi.responses import JSONResponse
 
 try:
+    import data_loader
+except Exception as exc:
+    data_loader = None
+    _data_loader_import_error = str(exc)
+else:
+    _data_loader_import_error = None
+
+try:
     from health_endpoint import router as health_router
 except Exception:
     health_router = None
@@ -216,6 +224,7 @@
         "observability_summary": "/observability/summary",
         "observability_dashboards": "/observability/dashboards",
         "observability_alerts": "/observability/alerts",
+        "data_loader_import_error": _data_loader_import_error,
         "quickball_import_error": _quickball_import_error,
         "forecast_import_error": _forecast_import_error,
         "action_queues_import_error": _action_queues_import_error,
@@ -231,6 +240,41 @@
     }
 
 
+@app.get("/cache/status", tags=["platform"])
+async def cache_status() -> dict:
+    data_cache = data_loader.get_cache_status() if data_loader is not None and hasattr(data_loader, "get_cache_status") else {"status": "unavailable"}
+    action_cache = {"status": "unavailable"}
+    try:
+        import account_action_queues
+        if hasattr(account_action_queues, "get_action_queue_cache_status"):
+            action_cache = account_action_queues.get_action_queue_cache_status()
+    except Exception as exc:
+        action_cache = {"status": "error", "message": str(exc)}
+    return {
+        "status": "ok",
+        "data_loader": data_cache,
+        "action_queues": action_cache,
+        "guardrails": {
+            "lineage_preserved": True,
+            "no_frontend_business_computation": True,
+            "no_silent_fallback": True,
+        },
+    }
+
+
+@app.post("/cache/refresh", tags=["platform"])
+async def cache_refresh() -> dict:
+    if data_loader is not None and hasattr(data_loader, "invalidate_cache"):
+        data_loader.invalidate_cache()
+    try:
+        import account_action_queues
+        if hasattr(account_action_queues, "invalidate_action_queue_cache"):
+            account_action_queues.invalidate_action_queue_cache()
+    except Exception:
+        pass
+    return {"status": "cache_invalidated", "next_request": "will_reload_sources"}
+
+
 @app.on_event("startup")
 async def on_startup() -> None:
     logger.info("Sobha Collections Intelligence Platform v8.13 Batch 13 starting")
@@ -247,3 +291,10 @@
     logger.info("Observability router loaded: %s", observability_router is not None)
     logger.info("SCIP_ENV: %s", _env)
     logger.info("CORS origins: %s", _allowed_origins)
+    if data_loader is not None and hasattr(data_loader, "get_cached_payload"):
+        if os.environ.get("SCIP_WARM_DATA_CACHE_ON_STARTUP", "true").lower() == "true":
+            try:
+                data_loader.get_cached_payload()
+                logger.info("SCIP data cache warmed on startup")
+            except Exception as exc:
+                logger.warning("SCIP data cache warmup failed; first request will retry: %s", exc)
diff -ruN original/go-live-rc1/Backend/quickball.py patched/go-live-rc1/Backend/quickball.py
--- original/go-live-rc1/Backend/quickball.py	2026-05-12 11:31:08.000000000 +0000
+++ patched/go-live-rc1/Backend/quickball.py	2026-05-12 13:34:39.323935334 +0000
@@ -387,8 +387,10 @@
     }
 
 
-def load_payload(data_dir: Optional[str] = None) -> Dict[str, Any]:
+def load_payload(data_dir: Optional[str] = None, *, force_refresh: bool = False) -> Dict[str, Any]:
     path = Path(data_dir) if data_dir else None
+    if hasattr(data_loader, "get_cached_payload"):
+        return data_loader.get_cached_payload(data_dir=path, force_refresh=force_refresh)
     return data_loader.load_all(data_dir=path)
 
 
@@ -418,6 +420,10 @@
         metric: str = Query(..., description="Metric name or natural-language alias, e.g. OD_TODAY or pipeline gross"),
         role: str = Query("board_cxo", description="board_cxo, cco_gm_agm, finance, mis_qcg_admin, collector_rm"),
     ) -> Dict[str, Any]:
+        # Unknown metric requests should return immediately and must not trigger
+        # a full workbook parse. Known metrics use the cached trusted payload.
+        if not normalize_metric_key(metric):
+            return explain_metric({"computed": {}}, metric, role)
         payload = load_payload()
         return explain_metric(payload, metric, role)
 
diff -ruN original/go-live-rc1/src/App.jsx patched/go-live-rc1/src/App.jsx
--- original/go-live-rc1/src/App.jsx	2026-05-12 11:31:08.000000000 +0000
+++ patched/go-live-rc1/src/App.jsx	2026-05-12 13:37:17.239326146 +0000
@@ -923,51 +923,66 @@
   const [drawer, setDrawer] = useState({ open: false, title: "", refs: [] });
   const [workflowDrawer, setWorkflowDrawer] = useState({ open: false, record: null, sourceAction: null });
   const [quickballAnswer, setQuickballAnswer] = useState(null);
+  const [roleRefreshing, setRoleRefreshing] = useState(false);
 
   useEffect(() => {
     let cancelled = false;
+
+    const fetchJson = async (path, headers, fallback = null) => {
+      try {
+        const res = await fetch(`${BACKEND_URL}${path}`, { headers });
+        if (!res.ok) {
+          if (fallback !== null) return fallback;
+          throw new Error(`${path} ${res.status}`);
+        }
+        return await res.json();
+      } catch (err) {
+        if (fallback !== null) return { ...fallback, error: err.message };
+        throw err;
+      }
+    };
+
     async function load() {
-      setLoading(true);
+      const initialLoad = !payload;
+      if (initialLoad) setLoading(true);
+      if (!initialLoad) setRoleRefreshing(true);
       setError(null);
+
       try {
         const headers = authHeaders(role);
-        const [centresRes, forecastRes, actionQueuesRes, workflowsRes, notificationsRes, auditRes, securityRes, identityRes, deploymentRes, observabilityRes, observabilityDashboardsRes, observabilityAlertsRes] = await Promise.all([
-          fetch(`${BACKEND_URL}/command-centres`, { headers }),
-          fetch(`${BACKEND_URL}/forecast/month-end`, { headers }),
-          fetch(`${BACKEND_URL}/action-queues`, { headers }),
-          fetch(`${BACKEND_URL}/workflows`, { headers }),
-          fetch(`${BACKEND_URL}/notifications`, { headers }),
-          fetch(`${BACKEND_URL}/persistence/summary`, { headers }),
-          fetch(`${BACKEND_URL}/security/me`, { headers }),
-          fetch(`${BACKEND_URL}/identity/me`, { headers }),
-          fetch(`${BACKEND_URL}/deployment/health`, { headers }),
-          fetch(`${BACKEND_URL}/observability/summary`, { headers }),
-          fetch(`${BACKEND_URL}/observability/dashboards`, { headers }),
-          fetch(`${BACKEND_URL}/observability/alerts`, { headers }),
+
+        // Product UAT blocking set only. Optional governance/security surfaces
+        // refresh below and must not freeze role switch or Quickball.
+        const [centresJson, forecastJson, actionQueuesJson, workflowsJson] = await Promise.all([
+          fetchJson("/command-centres", headers),
+          fetchJson("/forecast/month-end", headers),
+          fetchJson("/action-queues", headers),
+          fetchJson("/workflows", headers),
         ]);
-        if (!centresRes.ok) throw new Error(`Command centres ${centresRes.status}`);
-        if (!forecastRes.ok) throw new Error(`Forecast ${forecastRes.status}`);
-        if (!actionQueuesRes.ok) throw new Error(`Action queues ${actionQueuesRes.status}`);
-        if (!workflowsRes.ok) throw new Error(`Workflows ${workflowsRes.status}`);
-        if (!notificationsRes.ok) throw new Error(`Notifications ${notificationsRes.status}`);
-        if (!auditRes.ok) throw new Error(`Persistence ${auditRes.status}`);
-        if (!securityRes.ok) throw new Error(`Security ${securityRes.status}`);
-        const centresJson = await centresRes.json();
-        const forecastJson = await forecastRes.json();
-        const actionQueuesJson = await actionQueuesRes.json();
-        const workflowsJson = await workflowsRes.json();
-        const notificationsJson = await notificationsRes.json();
-        const auditJson = await auditRes.json();
-        const securityJson = await securityRes.json();
-        const deploymentJson = deploymentRes.ok ? await deploymentRes.json() : { status: "unavailable" };
-        const observabilityJson = observabilityRes.ok ? await observabilityRes.json() : { status: "unavailable" };
-        const observabilityDashboardsJson = observabilityDashboardsRes.ok ? await observabilityDashboardsRes.json() : { dashboards: [] };
-        const observabilityAlertsJson = observabilityAlertsRes.ok ? await observabilityAlertsRes.json() : { alerts: [] };
+
         if (!cancelled) {
           setPayload(centresJson);
           setForecast(forecastJson);
           setActionQueues(actionQueuesJson);
           setWorkflows(workflowsJson);
+          setLoading(false);
+          setRoleRefreshing(false);
+        }
+
+        // UAT-only optional surfaces. They are useful diagnostics, but should
+        // never block Arrival, Live Pulse, role switch, or Quickball.
+        const [notificationsJson, auditJson, securityJson, identityJson, deploymentJson, observabilityJson, observabilityDashboardsJson, observabilityAlertsJson] = await Promise.all([
+          fetchJson("/notifications", headers, { notifications: [], status: "unavailable" }),
+          fetchJson("/persistence/summary", headers, { status: "unavailable" }),
+          fetchJson("/security/me", headers, { status: "unavailable", actor: { role } }),
+          fetchJson("/identity/me", headers, { status: "unavailable" }),
+          fetchJson("/deployment/health", headers, { status: "unavailable" }),
+          fetchJson("/observability/summary", headers, { status: "unavailable" }),
+          fetchJson("/observability/dashboards", headers, { dashboards: [] }),
+          fetchJson("/observability/alerts", headers, { alerts: [] }),
+        ]);
+
+        if (!cancelled) {
           setNotifications(notificationsJson);
           setAuditSummary(auditJson);
           setSecurity(securityJson);
@@ -980,9 +995,13 @@
       } catch (err) {
         if (!cancelled) setError(err.message);
       } finally {
-        if (!cancelled) setLoading(false);
+        if (!cancelled) {
+          setLoading(false);
+          setRoleRefreshing(false);
+        }
       }
     }
+
     load();
     return () => { cancelled = true; };
   }, [role]);
@@ -1023,7 +1042,7 @@
   const askQuickball = useCallback(async (metric, roleKey) => {
     try {
       const params = new URLSearchParams({ metric: metric || "OD_TODAY", role: roleKey || role });
-      const res = await fetch(`${BACKEND_URL}/quickball/explain?${params.toString()}`);
+      const res = await fetch(`${BACKEND_URL}/quickball/explain?${params.toString()}`, { headers: authHeaders(roleKey || role) });
       if (!res.ok) throw new Error(`Quickball ${res.status}`);
       const json = await res.json();
       const actions = safeArray(json.follow_up_actions).slice(0, 2);
@@ -1070,6 +1089,7 @@
         </header>
 
         <ContextIsland route={route} focus={focus} depth={depth} role={role} setRole={setRole} payload={payload} />
+        {roleRefreshing && <div className="context-refresh glass-surface" role="status">Refreshing role lens...</div>}
         <SecurityPostureBar security={security} role={role} />
         <IdentityPostureBar identity={identity} />
         <DataConfidenceTrustBar trustBar={trustBar} guardrails={payload?.guardrails} />
```


---

## `SCIP_speed_ui_quickball_combined_patch/patches/frontend_quickball_ui_safe_merge.diff`


```diff
--- /mnt/data/scip_merge_work/speed/SCIP_speed_quickball_patch/files/go-live-rc1/src/App.jsx	2026-05-12 13:37:49.000000000 +0000
+++ /mnt/data/scip_combined_build/SCIP_speed_ui_quickball_combined_patch/files/go-live-rc1/src/App.jsx	2026-05-12 13:51:57.240884966 +0000
@@ -19,8 +19,9 @@
  *   - Solid surfaces are used for KPIs, charts, evidence, formulas and financial truth.
  */
 
-import { useCallback, useEffect, useMemo, useState } from "react";
+import { useCallback, useEffect, useMemo, useRef, useState } from "react";
 import "./liquidGlassTokens.css";
+import "./scipPowerUatQuickball.css";
 
 const BACKEND_URL = import.meta?.env?.VITE_BACKEND_URL || "https://scip.onrender.com";
 const LOCAL_DEV_BYPASS = import.meta?.env?.VITE_SCIP_LOCAL_DEV_BYPASS === "true";
@@ -694,23 +695,164 @@
   );
 }
 
+const QUICKBALL_PROMPTS = [
+  { label: "Explain number", metric: "OD_TODAY" },
+  { label: "Show basis", metric: "MTD_TOTAL_COLLECTIONS" },
+  { label: "Board note", metric: "OD_TODAY" },
+  { label: "Open actions", metric: "ACTION_QUEUE" },
+];
+
+function getStoredQuickballPosition() {
+  if (typeof window === "undefined") return { x: 24, y: 24 };
+  try {
+    const saved = window.localStorage.getItem("scip.quickball.position");
+    if (saved) {
+      const parsed = JSON.parse(saved);
+      if (Number.isFinite(parsed.x) && Number.isFinite(parsed.y)) {
+        return {
+          x: Math.max(12, Math.min(parsed.x, window.innerWidth - 76)),
+          y: Math.max(12, Math.min(parsed.y, window.innerHeight - 76)),
+        };
+      }
+    }
+  } catch {
+    window.localStorage.removeItem("scip.quickball.position");
+  }
+  return { x: Math.max(16, window.innerWidth - 92), y: Math.max(16, window.innerHeight - 92) };
+}
+
 function QuickballCommand({ role, answer, onAsk, collapsedPrompt = "Ask about this number..." }) {
   const [metric, setMetric] = useState("");
+  const [open, setOpen] = useState(false);
+  const [asking, setAsking] = useState(false);
+  const [position, setPosition] = useState(getStoredQuickballPosition);
+  const dragRef = useRef(null);
+  const movedRef = useRef(false);
   const blocked = answer?.status === "blocked_untrusted_metric";
-  return (
-    <section className="quickball-capsule glass-surface" aria-label="Quickball command capsule">
-      <div className="quickball-row">
-        <input
-          className="quickball-input"
-          value={metric}
-          onChange={(event) => setMetric(event.target.value)}
-          placeholder={collapsedPrompt}
-          aria-label="Ask Quickball"
-        />
-        {onAsk ? <button className="primary-button" onClick={() => onAsk(metric, role)}>Ask</button> : null}
-      </div>
+
+  useEffect(() => {
+    if (typeof window === "undefined") return undefined;
+    const clampPosition = () => {
+      setPosition((current) => {
+        const next = {
+          x: Math.max(12, Math.min(current.x, window.innerWidth - (open ? 356 : 76))),
+          y: Math.max(12, Math.min(current.y, window.innerHeight - (open ? 264 : 76))),
+        };
+        window.localStorage.setItem("scip.quickball.position", JSON.stringify(next));
+        return next;
+      });
+    };
+    window.addEventListener("resize", clampPosition);
+    return () => window.removeEventListener("resize", clampPosition);
+  }, [open]);
+
+  const persistPosition = useCallback((next) => {
+    setPosition(next);
+    if (typeof window !== "undefined") {
+      window.localStorage.setItem("scip.quickball.position", JSON.stringify(next));
+    }
+  }, []);
+
+  const onPointerDown = useCallback((event) => {
+    dragRef.current = {
+      pointerId: event.pointerId,
+      startX: event.clientX,
+      startY: event.clientY,
+      originX: position.x,
+      originY: position.y,
+    };
+    movedRef.current = false;
+    event.currentTarget.setPointerCapture?.(event.pointerId);
+  }, [position.x, position.y]);
+
+  const onPointerMove = useCallback((event) => {
+    const drag = dragRef.current;
+    if (!drag || drag.pointerId !== event.pointerId) return;
+    const dx = event.clientX - drag.startX;
+    const dy = event.clientY - drag.startY;
+    if (Math.abs(dx) + Math.abs(dy) > 4) movedRef.current = true;
+    const width = open ? 356 : 76;
+    const height = open ? 264 : 76;
+    persistPosition({
+      x: Math.max(12, Math.min(drag.originX + dx, window.innerWidth - width)),
+      y: Math.max(12, Math.min(drag.originY + dy, window.innerHeight - height)),
+    });
+  }, [open, persistPosition]);
+
+  const onPointerUp = useCallback((event) => {
+    const wasMoved = movedRef.current;
+    dragRef.current = null;
+    event.currentTarget.releasePointerCapture?.(event.pointerId);
+    if (wasMoved) {
+      setOpen(false);
+      navigator.vibrate?.(12);
+      return;
+    }
+    setOpen((value) => !value);
+    navigator.vibrate?.(8);
+  }, []);
+
+  const runAsk = useCallback(async (nextMetric) => {
+    if (!onAsk || asking) return;
+    const value = String(nextMetric || metric || "OD_TODAY").trim();
+    setAsking(true);
+    try {
+      await onAsk(value, role);
+      setMetric("");
+      setOpen(false);
+    } finally {
+      setAsking(false);
+    }
+  }, [asking, metric, onAsk, role]);
+
+  return (
+    <section
+      className={`quickball-floating glass-surface ${open ? "open" : ""} ${dragRef.current ? "dragging" : ""}`}
+      style={{ left: position.x, top: position.y }}
+      aria-label="Quickball command capsule"
+    >
+      <button
+        type="button"
+        className="quickball-floating-trigger"
+        onPointerDown={onPointerDown}
+        onPointerMove={onPointerMove}
+        onPointerUp={onPointerUp}
+        aria-expanded={open}
+        aria-label={open ? "Collapse Quickball" : "Open Quickball"}
+      >
+        <span className="quickball-orb" />
+        {open && <span className="quickball-floating-title">Quickball</span>}
+      </button>
+
+      {open && (
+        <div className="quickball-floating-body">
+          <div className="quickball-row compact">
+            <input
+              className="quickball-input"
+              value={metric}
+              onChange={(event) => setMetric(event.target.value)}
+              onKeyDown={(event) => {
+                if (event.key === "Enter") runAsk(metric);
+              }}
+              placeholder={collapsedPrompt}
+              aria-label="Ask Quickball"
+            />
+            <button className="primary-button" disabled={asking} onClick={() => runAsk(metric)}>
+              {asking ? "Asking..." : "Ask"}
+            </button>
+          </div>
+          <div className="quickball-prompt-list" aria-label="Quickball prompts">
+            {QUICKBALL_PROMPTS.map((prompt) => (
+              <button key={prompt.label} type="button" className="ghost-button" disabled={asking} onClick={() => runAsk(prompt.metric)}>
+                {prompt.label}
+              </button>
+            ))}
+          </div>
+        </div>
+      )}
+
       {answer && (
-        <div className={`quickball-answer solid-truth ${blocked ? "blocked-warning" : ""}`} role={blocked ? "alert" : "status"}>
+        <div className={`quickball-answer quickball-floating-answer solid-truth ${blocked ? "blocked-warning" : ""}`} role={blocked ? "alert" : "status"}>
           <strong>{blocked ? "Quickball blocked an untrusted answer." : (answer.metric_label || answer.metric_key || "Quickball")}</strong>
           <p>{blocked ? (answer.reason || "A critical metric failed lineage validation.") : answer.answer}</p>
         </div>
```


---

## `SCIP_speed_ui_quickball_combined_patch/apply_from_repo_root.sh`


```bash
#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -d "$ROOT/go-live-rc1/Backend" ]; then
  TARGET="$ROOT/go-live-rc1"
elif [ -d "$ROOT/Backend" ]; then
  TARGET="$ROOT"
else
  echo "Could not find go-live-rc1/Backend or Backend under: $ROOT" >&2
  exit 1
fi

mkdir -p "$TARGET/Backend" "$TARGET/src"

cp "$PKG_DIR/files/go-live-rc1/Backend/data_loader.py" "$TARGET/Backend/data_loader.py"
cp "$PKG_DIR/files/go-live-rc1/Backend/quickball.py" "$TARGET/Backend/quickball.py"
cp "$PKG_DIR/files/go-live-rc1/Backend/forecast.py" "$TARGET/Backend/forecast.py"
cp "$PKG_DIR/files/go-live-rc1/Backend/file_resolver.py" "$TARGET/Backend/file_resolver.py"
cp "$PKG_DIR/files/go-live-rc1/Backend/account_action_queues.py" "$TARGET/Backend/account_action_queues.py"
cp "$PKG_DIR/files/go-live-rc1/Backend/main.py" "$TARGET/Backend/main.py"
cp "$PKG_DIR/files/go-live-rc1/src/App.jsx" "$TARGET/src/App.jsx"
cp "$PKG_DIR/files/go-live-rc1/src/scipPowerUatQuickball.css" "$TARGET/src/scipPowerUatQuickball.css"

(
  cd "$TARGET/Backend"
  python -m py_compile data_loader.py quickball.py forecast.py file_resolver.py account_action_queues.py main.py
)

echo "Applied SCIP combined speed + safe UI Quickball patch to: $TARGET"
echo "Next: git diff, npm install, npm run build, commit, push origin release, redeploy Render and Cloudflare."
```


---

## `SCIP_speed_ui_quickball_combined_patch/CONTRADICTIONS_RESOLVED.md`


```markdown
# Contradictions handled before merge

The attached UI patch was reviewed against the locked SCIP UAT rules and the speed patch.

## Resolved decisions

1. The UI patch `src/App.jsx` was not copied wholesale.
   - Reason: it is a standalone/demo-style frontend with placeholder cards such as `Server value` and `Pending validation`.
   - Resolution: keep the backend-connected `App.jsx` from the speed package and merge only safe UI behavior.

2. No frontend metric computation was introduced.
   - Resolution: `App.jsx` still renders only backend-provided command-centre, forecast, action queue, workflow, notification, observability, and Quickball payloads.

3. No silent fallback or fake figures were introduced.
   - Resolution: failed critical/product endpoints still surface unavailable/error state. Quickball still returns blocked/unavailable state if the backend cannot answer with trust.

4. Quickball remains quiet/contextual, not a third Arrival door.
   - Resolution: Quickball is now a small floating transparent disk with tap-to-expand and drag-to-place behavior.

5. The two-door Arrival model is preserved.
   - Resolution: Arrival remains Live Pulse and Narratives only.

6. The UI patch CSS was not used as a full replacement.
   - Reason: replacing `liquidGlassTokens.css` could break existing runtime classes used by the backend-connected App.
   - Resolution: add a small overlay file, `src/scipPowerUatQuickball.css`, and import it from `App.jsx`.

7. Build/deployment shell files were not overwritten.
   - Reason: the speed package targets the active `go-live-rc1` runtime layout, and package/index/vite/netlify files may already differ in the live repo.
   - Resolution: this combined patch only changes the files required for speed and safe Quickball UI behavior.

## Included safe UI features

- Floating Quickball disk.
- Tap-to-expand Quickball panel.
- Drag-to-place Quickball.
- Persisted placement in `localStorage`.
- Light browser vibration where supported.
- Compact prompt buttons: Explain number, Show basis, Board note, Open actions.
- Collapses after an ask/drag while leaving the backend answer visible as a compact response card.

## Preserved backend fixes

- TTL-backed `data_loader` cache.
- Fast Quickball path using cached trusted payload.
- Cached action queue extraction.
- `/cache/status` and `/cache/refresh`.
- R09 known-source resolver fix.
```


---

## `SCIP_speed_ui_quickball_combined_patch/README.md`


```markdown
# SCIP Combined Speed + Safe UI Quickball Patch

Purpose: fix slow role switch and slow Quickball during staging Product UAT, while safely integrating the attached UI Quickball/nav refinement.

Target layout:

```txt
go-live-rc1/Backend
go-live-rc1/src
```

The script also supports repos whose runtime is directly under:

```txt
Backend
src
```

## What this fixes

1. Quickball speed: `/quickball/explain` uses a short-lived trusted backend data cache instead of reloading every workbook each time.
2. Role switch speed: frontend role changes remain optimistic/non-blocking, and backend calls reuse cached payloads.
3. Risk & Action/action queue speed: action queue extraction is cached.
4. R09 resolver issue: `R09_Collections 07-05-2026.xlsx` is no longer skipped as an unknown R-code.
5. UI refinement: Quickball becomes a small floating transparent disk with tap-to-expand and drag-to-place behavior.

## Files changed

```txt
go-live-rc1/Backend/data_loader.py
go-live-rc1/Backend/quickball.py
go-live-rc1/Backend/forecast.py
go-live-rc1/Backend/file_resolver.py
go-live-rc1/Backend/account_action_queues.py
go-live-rc1/Backend/main.py
go-live-rc1/src/App.jsx
go-live-rc1/src/scipPowerUatQuickball.css
```

## Apply in Codespaces

From repo root:

```bash
unzip SCIP_speed_ui_quickball_combined_patch.zip
bash SCIP_speed_ui_quickball_combined_patch/apply_from_repo_root.sh .
```

Review the diff:

```bash
git diff -- go-live-rc1/Backend/data_loader.py \
  go-live-rc1/Backend/quickball.py \
  go-live-rc1/Backend/forecast.py \
  go-live-rc1/Backend/file_resolver.py \
  go-live-rc1/Backend/account_action_queues.py \
  go-live-rc1/Backend/main.py \
  go-live-rc1/src/App.jsx \
  go-live-rc1/src/scipPowerUatQuickball.css
```

Backend syntax check:

```bash
cd go-live-rc1/Backend
python -m py_compile data_loader.py quickball.py forecast.py file_resolver.py account_action_queues.py main.py
```

Frontend build check:

```bash
cd ..
npm install
npm run build
```

Commit and push to active branch:

```bash
cd ..
git add go-live-rc1/Backend/data_loader.py \
  go-live-rc1/Backend/quickball.py \
  go-live-rc1/Backend/forecast.py \
  go-live-rc1/Backend/file_resolver.py \
  go-live-rc1/Backend/account_action_queues.py \
  go-live-rc1/Backend/main.py \
  go-live-rc1/src/App.jsx \
  go-live-rc1/src/scipPowerUatQuickball.css

git commit -m "Fix SCIP UAT speed and refine Quickball UI"
git push origin release
```

## Render env vars to add or confirm

```txt
SCIP_DATA_CACHE_TTL_SECONDS=900
SCIP_ACTION_QUEUE_CACHE_TTL_SECONDS=900
SCIP_WARM_DATA_CACHE_ON_STARTUP=true
SCIP_SOURCE_ROOT=/tmp/scip/r-series
```

## Verify after Render redeploy

Open:

```txt
https://scip.onrender.com/cache/status
https://scip.onrender.com/quickball/explain?metric=OD_TODAY&role=board_cxo
https://scip.onrender.com/quickball/explain?metric=MTD_TOTAL_COLLECTIONS&role=board_cxo
```

Expected:

```txt
/cache/status shows warm data cache after first load.
Second Quickball request is much faster than the first.
Render logs no longer show a full Data load complete cycle for every Quickball question or role switch.
R09 no longer logs as Skipping unknown R-code.
```

## Verify after Cloudflare redeploy

Expected:

```txt
Role switch updates immediately or near-immediately.
Quickball appears as a small floating disk.
Quickball expands on tap/click.
Quickball can be dragged and position persists after reload.
Quickball prompt calls are faster after backend cache warmup.
No third Arrival door appears.
No Entity Head role appears.
No frontend fallback figures appear.
```

## Guardrails preserved

```txt
No frontend business computation.
No silent fallback figures.
Critical metrics still require lineage.
Quickball still blocks unlineaged critical answers.
Cached payload includes server-provided lineage and validation state.
Role/RBAC filtering still runs after cache retrieval.
Entity Head is not introduced.
```

## Validation performed before packaging

```txt
Backend py_compile passed for the patched backend files.
The attached UI patch was conflict-reviewed and only safe UI behavior was merged.
Full npm/Vite build still needs to be run inside Codespaces against your repo dependencies.
```
```
