# SCIP Insights Engine — PACKAGE MANIFEST

Programme: replace static insight authoring with a live, lineage-bound engine. Built in 5 reversible, shadow-first waves (A, B, C, D-1, D-2). All local smokes green; nothing live (env-gated, default off).

## Top level
- `HANDOFF.md` — start here; context, state, locked rules, env flags, the one finding.
- `ACTION_PLAN.md` — ordered, gated rollout steps.
- `SCIP_Insights_Engine_Surgical_Replacement_Plan.md` — the full 8-section design.
- `PACKAGE_MANIFEST.md` — this file.

## engine/ (flat, runnable — drop .py/.json into go-live-rc1/Backend; .jsx/.css to frontend)
| File | Wave | Purpose | Deploy target |
|---|---|---|---|
| `insight_registry.json` | A→B | declarative insight specs + frame_sets + cutover config | Backend |
| `insight_compiler.py` | A→B | compiles registry vs governed values; frames + blocked degrade | Backend |
| `command_centres_shadow_patch.py` | A→D | read-only hook: attaches `resolved_insights` | Backend (1 line in build_command_centres) |
| `editorial_token_validator.py` | C | post-LLM whitelist; the no-hallucinated-number guarantee | Backend |
| `narrative_fact_builder.py` | C | frozen verified fact set per Narratives chapter | Backend |
| `constrained_editorial.py` | C | gate → LLM → validate → deterministic fallback | Backend |
| `_wave_c_shim.py` | C | LOCAL-ONLY fallback for provider gate / llm_providers (real modules win on deploy) | not deployed (or harmless) |
| `section_rules.py` | D-1→D-2 | loads FINAL_section_mapping rules; containment (by key + M-code), single-source, routes | Backend |
| `placement_binder.py` | D-1 | registry-driven placement + R1–R5 enforcement | Backend |
| `placement_shadow_patch.py` | D-1 | read-only hook: attaches `placement_shadow` | Backend (1 line) |
| `command_centres_v2.py` | D-2 | binder-as-render-source cutover (env-gated) | Backend |
| `build_d2_migration.py` | D-2 | generator: crosswalk + section_placement (fabrication/completeness/boundary guards) | Backend (run once) |
| `metric_crosswalk.json` | D-2 | metric_key↔M-code↔lineage (generated) | Backend |
| `section_placement.json` | D-2 | migrated kpis/used_in placement; 1 quarantined (M037) (generated) | Backend |
| `scip_focusscreen_wave_b_patch.jsx` | B | FocusScreen renders live insights for Live Pulse; static fallback | Frontend (replace FocusScreen) |
| `scip_insight_cards_wave_b.css` | B | additive insight-card styles (reuses Liquid Slate tokens) | Frontend (append to liquidGlassTokens.css) |
| `FINAL_section_mapping.json` | input | reference copy the binder/generator read | repo copy is canonical — DO NOT overwrite |
| `FINAL_metrics.json` | input | reference copy the crosswalk reads | repo copy is canonical — DO NOT overwrite |
| `smoke_insight_shadow_parity.py` | A | parity gate (supports `SCIP_USE_REAL_COMMAND_CENTRES=1`) | local/staging |
| `smoke_insight_wave_b.py` | B | frames + blocked-degrade gate | local/staging |
| `smoke_editorial_wave_c.py` | C | whitelist / rogue-injection / withheld / error gate | local/staging |
| `smoke_placement_wave_d1.py` | D-1 | placement parity + R1–R5 enforcement gate | local/staging |
| `smoke_placement_wave_d2.py` | D-2 | render parity + crosswalk + completeness + quarantine gate | local/staging |
| `run_all_smokes.sh` | — | regenerate D-2 artifacts + run all five smokes | local/staging |

## docs/
- `WAVE_B_README.md`, `WAVE_C_README.md`, `WAVE_D1_README.md`, `WAVE_D2_README.md` — per-wave detail, smoke results, deploy/rollback.
- `WAVE_D2_DELETIONS.md` — the gated, irreversible deletion manifest (apply last).

## archive/
- `insight_registry_wave_a.json`, `insight_compiler_wave_a.py` — Wave A originals, kept for rollback reference.

## Verify
`cd engine && bash run_all_smokes.sh` → "ALL WAVE SMOKES PASS". Python 3.10+, stdlib only.
