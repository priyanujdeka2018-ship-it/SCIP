# SCIP Insights Engine — Wave D-1 (Placement Binder, shadow)

**Wave D is split in two.** D-1 (this drop) builds the Placement Binder and the boundary/containment/single-source enforcement and runs it in **shadow** — proving it reproduces the current placement and enforces the kept `FINAL_section_mapping.json` rules, without changing what renders. D-2 (next) cuts `command_centres` over to the binder, migrates `submodules[].kpis` into the registry, and deletes the hardcoded card-list functions and the static fallbacks A–C retained.

## What D-1 does
- Resolves per-role card placement from the registry `surface_binding` (priority desc, slot asc) instead of the hardcoded `_board_cards`/`_ops_cards` lists — and proves the order/membership is identical to today's.
- Enforces the kept placement rules from `FINAL_section_mapping.json`:
  - **R1 route** — only the two Liquid Glass Arrival doors (`live_pulse`, `narratives`); no third door.
  - **R2 submodule** — a bound submodule must exist among the 49 real `S0X_SMy` ids.
  - **R3 containment** — a content family can't be placed in a forbidden section (CIV/nationality OD stays S01, not S04; NPV KPIs not re-displayed in S05; advance 3-yr monthly stays S05, not S01) — grounded in `boundary_rules`.
  - **R4 single-source** — a single-source constant (`OD_TODAY`, `CY_ADV_MIX_YTD`, `PIPELINE_ADV_DENOM`, `MDO_targets`, `DAILY_DAYS`, …) must resolve to **one** lineage origin across all insights — never recomputed or hardcoded per section (from `cross_section_feeds` + `global_component_rules`).
  - **R5 no-dup slot** — no two placed insights share the same `(route, focus, slot)`.
- Attaches its output under `result["placement_shadow"]` read-only. Live cards untouched.

## Smoke results (local)
`python smoke_placement_wave_d1.py` → all pass:
- **Parity**: binder per-role order equals the command_centres order for all five roles; zero violations on the clean set; all 15 insights placed.
- **Single-source**: OD_TODAY, CY_ADV_MIX_YTD, PIPELINE_ADV_DENOM, MDO_targets, DAILY_DAYS recognised.
- **Enforcement**: injected CIV-in-S04 (R3), third door (R1), bad submodule S99_SM9 (R2), divergent OD_TODAY origin (R4, flags both refs), and duplicate slot (R5) all rejected with the correct reason; the first slot occupant is placed and the duplicate dropped.

Regression: Waves A, B, C smokes still pass alongside D-1.

## Files
- `section_rules.py` — loads `FINAL_section_mapping.json`; exposes submodule ids, valid routes, single-source constants, and the containment table (each entry cites its `boundary_rules` source).
- `placement_binder.py` — registry-driven per-role placement + R1–R5 enforcement; shadow.
- `placement_shadow_patch.py` — read-only attach hook.
- `smoke_placement_wave_d1.py` — the D-1 gate.
- `FINAL_section_mapping.json` — the canonical rules file the binder reads (already in the repo; the loader points at it).

## Deploy (non-destructive)
1. Place `section_rules.py`, `placement_binder.py`, `placement_shadow_patch.py` into `go-live-rc1/Backend/`. The binder reads the repo's existing `FINAL_section_mapping.json`.
2. Add one line at the end of `build_command_centres()` after the Wave A–C hook: `return attach_placement_shadow(result, payload)`.
3. Inspect `result["placement_shadow"]`: on the live payload, `violations` should be `[]` and per-role order should match the live cards. (Authoritative parity check: compare `placement_order(...)` against the live `command_centres` card order, the same way `SCIP_USE_REAL_COMMAND_CENTRES=1` was used in Wave A.)

## Rollback
Remove the one line, or set `SCIP_PLACEMENT_SHADOW=off`. The binder is never in the critical path; any error is swallowed and the original result returned.

## D-2 preview (destructive, gated)
- Migrate `submodules[].kpis` (M-code → submodule) out of `FINAL_section_mapping.json` into the registry `surface_binding` as the single placement authority.
- Make the binder the **render source** for command_centres (replace the hardcoded card-list functions).
- Delete `_board_cards`/`_ops_cards`/`_finance_cards`/`_mis_cards`/`_collector_cards` as placement authorities and the static fallbacks A–C kept.
- Gate: D-2 cutover only after D-1 reports `violations: []` and order parity on the **live** payload.

## Note on D-1 vs the live data
The binder's enforcement is data-state independent (it checks placement and lineage origins, not values), so the 13/28 partial load does not affect D-1 parity. A card whose source is unresolved still has a valid placement; it simply carries a blocked/Unavailable value from the Wave B path.
