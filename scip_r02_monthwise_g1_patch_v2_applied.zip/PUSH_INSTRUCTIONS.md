# R02 Monthwise + G1 — PUSH INSTRUCTIONS (as-applied, verified)

Everything in this bundle was applied to a fresh clone of `release` (HEAD `67dfb31`)
and verified end-to-end. Two ways to land it — pick ONE.

## Option A — git patch (preferred, exact)

In Codespaces on the `release` branch:
```bash
git apply --check r02_monthwise_g1.patch   # dry-run, must be silent
git am r02_monthwise_g1.patch              # applies with the commit message
git push origin release
```
If `git am` complains (e.g. line endings), fall back to Option B.

## Option B — copy the as-applied files

Copy from `as_applied/` into `go-live-rc1/Backend/`, overwriting:
- `r02_monthwise_extension.py` (new)
- `smoke_r02_monthwise.py` (new)
- `pipeline_config.json`
- `metric_catalog.json`
- `source_adapters.py`

Then commit and push. NOTE: only safe if `release` HEAD is still `67dfb31`
(no other backend pushes since). If HEAD moved, use Option A.

## Post-push gate (Render)

After Render redeploys, the bootstrap pulls R-series from Drive; then:
```bash
cd go-live-rc1/Backend
python smoke_r02_monthwise.py "$SCIP_SOURCE_ROOT/<resolved R02 file>"
```
Gate: `SMOKE: ALL GATES GREEN`. The extension keys appear in the live payload
under `computed.R02_LINEAGE` (planned_*, q1_achievement_planned_*,
q1_mdo_achievement_by_category).

## What changed (verified against real 06-05 workbook)

| File | Change |
|---|---|
| `source_adapters.py` | +7 lines: 1 import + 1 call in `R02MDOAdapter.extract()` before the payload-clean tail |
| `r02_monthwise_extension.py` | NEW — planned-basis extraction, 26 metrics + 25 lineage records, 5 validations |
| `pipeline_config.json` | `sources.R02` only: stale flat `column_map` replaced with section_iterator truth; governance keys (`reporting_basis`, `entity_mapping`, `metric_disambiguation`, `validation_check`) preserved; +5 Monthwise rules (14 total); dead keys (`column_map`, `column_types`, `aggregations`, `data_date_col`) removed — R02 routes via adapter dispatch, generic path never reads them |
| `metric_catalog.json` | +4 non-critical entries (33 total), `computed_key: null` → Quickball resolves via lineage value |

## Verified evidence (this clone)

- Standalone smoke: ALL GATES GREEN (`final_smoke.txt`)
- End-to-end `run_adapter` additivity: 26 metrics / 25 lineage added, **0 removed,
  0 pre-existing values changed** (only `last_loaded_at` timestamps + the
  intentional `lineage_metric_count`)
- Quickball: `MDO_PLANNED_NS_TARGET_Q1 → AED 1.097B`,
  `Q1_MDO_ACHIEVEMENT_BY_CATEGORY → 52.40%`, lineage usable; absent lineage →
  `blocked_untrusted_metric` (no number)
- `py_compile` clean on adapter, extension, quickball, data_loader
- JSON valid on both config files

## Two findings for your decision (NOT changed by this patch)

1. **Silent constant fallback in `data_loader.py` (~line 680):**
   `FY_DUES_TARGET = r02_aggs.get(...) or C.MDO_DUES_FY_2026_AED` (same for ADV).
   When R02 fails to load, these publish STALE design constants (11.5B / 4.0B vs
   file 10.33B / 2.76B) with no `unavailable` state — a direct "no silent
   fallback" rule violation when triggered. Removing the `or C.*` is a one-line
   behaviour change; recommend doing it, but it needs your explicit go.
2. **Engine files not on `release`:** branch HEAD is May 23 — the Waves A–D
   Phase 0 landing has NOT been pushed. Memory says Phase 0 was deployed; the
   repo says otherwise. Either the push is pending, or it went somewhere other
   than `release`. Worth resolving before Phase 1 gates, since Render deploys
   from `release`.

## Rollback

`git revert <commit>` — single commit, additive code; env-free.
