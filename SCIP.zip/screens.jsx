/* SCIP — screens: Arrival, World Home, Focus, Narrative */
/* eslint-disable react/prop-types */

// ---------- ARRIVAL ----------
function Arrival({ onEnter, dataDate }) {
  return (
    <main className="arrival" aria-label="SCIP arrival">
      <div className="arrival-inner">
        <div className="arrival-mark">S</div>
        <div className="eyebrow arrival-eyebrow">Sobha Collections Intelligence Platform</div>
        <h1 className="arrival-title display">Begin with the signal.</h1>
        <p className="arrival-sub">
          An intelligent briefing that can go as deep as you ask. Two doors. No dashboards waiting for you.
        </p>

        <div className="doors" aria-label="Primary entry choices">
          <button className="door glass edge-accent" onClick={() => onEnter("live_pulse")}>
            <div className="door-poster door-poster--pulse" aria-hidden="true" />
            <div className="door-top">
              <div className="door-icon"><IconPulse size={18} /></div>
              <div className="door-meta">Door 01 · Operational</div>
            </div>
            <div className="door-spacer" />
            <h2 className="door-title">Live Pulse</h2>
            <p className="door-desc">What needs attention today. Current signal, month movement, risk and action — three doors, no menus.</p>
            <div className="door-cta">Enter Live Pulse <span className="arrow"><IconChevron size={14} /></span></div>
          </button>

          <button className="door glass" onClick={() => onEnter("narratives")}>
            <div className="door-poster door-poster--narr" aria-hidden="true" />
            <div className="door-top">
              <div className="door-icon"><IconBook size={18} /></div>
              <div className="door-meta">Door 02 · Executive</div>
            </div>
            <div className="door-spacer" />
            <h2 className="door-title">Narratives</h2>
            <p className="door-desc">The story behind the numbers. A guided five-chapter briefing — Story, Portfolio, Dues, Advance, Roadmap.</p>
            <div className="door-cta">Enter Narratives <span className="arrow"><IconChevron size={14} /></span></div>
          </button>
        </div>

        <div className="arrival-foot">
          <span>Data {dataDate}</span>
          <span className="sep" />
          <span>{window.SCIP.TRUST.load_timestamp}</span>
          <span className="sep" />
          <span>{window.SCIP.TRUST.sources_loaded.length} sources lineaged</span>
          <span className="sep" />
          <span>Contract {window.SCIP.TRUST.contract}</span>
        </div>
      </div>
    </main>
  );
}

// ---------- LIVE PULSE HOME (three choices) ----------
const LIVE_PULSE_CHOICES = [
  {
    key: "current_signal",
    eyebrow: "Are we okay today?",
    title: "Current Signal",
    desc: "A calm reading of what needs attention now, anchored on OD, collections and confidence.",
    metric: "184.6M",
    unit: "AED · group OD",
    severity: "warn",
  },
  {
    key: "month_movement",
    eyebrow: "How is May moving?",
    title: "Month Movement",
    desc: "MTD movement, run-rate and target gap. The forecast discloses its basis.",
    metric: "92%",
    unit: "of May target",
    severity: "warn",
  },
  {
    key: "risk_action",
    eyebrow: "Where should we act?",
    title: "Risk & Action",
    desc: "Lineaged action queues with owners, due dates and immutable workflow events.",
    metric: "82",
    unit: "open actions",
    severity: "risk",
  },
];

function LivePulseHome({ focus, setFocus, role }) {
  const choices = window.SCIP.LIVE_PULSE_BY_ROLE[role] || window.SCIP.LIVE_PULSE_BY_ROLE.cco_gm_agm;
  return (
    <section className="world-hero glass" aria-label="Live Pulse home">
      <div className="world-hero-meta">
        <span className="eyebrow">Live Pulse</span>
        <span className="dot dot--ok dot--pulse" />
        <span className="small" style={{ color: "var(--text-mute)" }}>Backend live · {window.SCIP.TRUST.load_timestamp}</span>
      </div>
      <h2 className="world-hero-title display h2">Three choices. One signal at a time.</h2>
      <p className="world-hero-sub body-lg">Doors adapt to your lens — the count stays three by design. Deeper lenses remain follow-ups, never a fourth door.</p>

      <div className="choices">
        {choices.map((c) => {
          const sevDot = c.severity === "risk" ? "dot--risk" : c.severity === "warn" ? "dot--warn" : "dot--ok";
          return (
            <button key={c.key} className="choice glass--quiet" aria-pressed={focus === c.key} onClick={() => setFocus(c.key)}>
              <span className="eyebrow choice-q">{c.eyebrow}</span>
              <h3 className="choice-title">{c.title}</h3>
              <p className="choice-desc">{c.desc}</p>
              <div className="choice-foot">
                <span className="eyebrow eyebrow--mute"><span className={`dot ${sevDot}`} /> Read</span>
                <div className="right">
                  <div className="choice-metric">{c.metric}</div>
                  <div className="choice-metric-unit">{c.unit}</div>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}

// ---------- NARRATIVES HOME (rail) ----------
function NarrativesHome({ focus, setFocus, onPresent }) {
  return (
    <section className="world-hero glass" aria-label="Narratives home">
      <div className="world-hero-meta">
        <span className="eyebrow">Narratives</span>
        <span className="small" style={{ color: "var(--text-mute)" }}>A guided five-chapter briefing</span>
        <span style={{ flex: 1 }} />
        <button className="btn btn--primary" onClick={onPresent}>
          <span style={{ display: "inline-flex", width: 0, height: 0, borderTop: "5px solid transparent", borderBottom: "5px solid transparent", borderLeft: "8px solid currentColor" }} />
          Present
        </button>
      </div>
      <h2 className="world-hero-title display h2">A boardroom journey, not a dashboard menu.</h2>
      <p className="world-hero-sub body-lg">
        Move through Story, Portfolio, Dues, Advance and Roadmap. Evidence stays one click deeper — the surface remains calm.
      </p>
      <nav className="narrative-rail" aria-label="Narrative steps">
        {window.SCIP.NARRATIVES.map((n) => (
          <button key={n.key} aria-current={focus === n.key ? "step" : undefined} onClick={() => setFocus(n.key)}>
            <span className="num">{n.num}</span>{n.label}
          </button>
        ))}
      </nav>
    </section>
  );
}

// ---------- FOCUS SCREEN (Live Pulse focus or Narrative chapter) ----------
function FocusScreen({ route, focus, role, entity, onOpenLineage, onAskQuickball, setFocus, forecastLayout, autoLineage }) {
  // Narrative focus → render Story page (separate look)
  if (route === "narratives") {
    return <NarrativeStory focus={focus} setFocus={setFocus} onOpenLineage={onOpenLineage} onAskQuickball={onAskQuickball} />;
  }

  const s = window.SCIP.SIGNALS[focus] || window.SCIP.SIGNALS.current_signal;
  const posterClass = `focus-poster focus-poster--${s.poster}`;

  // Entity-scoped hero title (driven by Group/Sobha/UAQ toggle).
  const entityLbl = window.entityLabel ? window.entityLabel(entity || "group") : "Group";
  const heroTitle = useMemo(() => {
    const t = s.hero.title;
    return t.replace(/^Group\b/, entityLbl);
  }, [s.hero.title, entityLbl]);
  const curiosities = focus === "current_signal" ? [
    { k: "show_evidence", label: "Show source evidence" },
    { k: "ask", label: "Ask about this number" },
    { k: "open_runway", label: "Open Month Movement →" },
  ] : focus === "month_movement" ? [
    { k: "show_evidence", label: "Show forecast lineage" },
    { k: "ask", label: "Ask about the run-rate" },
    { k: "what_should_we_do", label: "What should we do? →" },
  ] : [
    { k: "show_evidence", label: "Show action lineage" },
    { k: "ask", label: "Ask about a risk pocket" },
    { k: "open_queues", label: "Open action queues ↓" },
  ];

  function handleCuriosity(k) {
    if (k === "show_evidence") {
      const lineageKey = focus === "current_signal" ? "OD_TODAY" : focus === "month_movement" ? "FORECAST_LANDING" : "RISK_PRESSURE";
      onOpenLineage(lineageKey, s.hero.title);
    } else if (k === "ask") {
      onAskQuickball(focus === "current_signal" ? "explain group od today" : focus === "month_movement" ? "show source basis for projected landing" : "prepare board explanation for risk pressure");
    } else if (k === "open_runway") {
      setFocus("month_movement");
    } else if (k === "what_should_we_do") {
      setFocus("risk_action");
    } else if (k === "open_queues") {
      const el = document.querySelector("[data-anchor=action-queues]");
      if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  return (
    <section className="focus glass" aria-label="Focus screen">
      <div className={posterClass} aria-hidden="true" />
      <span className="eyebrow">{s.poster === "ok" ? "Composed" : s.poster === "warn" ? "Attention" : "Risk"} · Live</span>
      <p className="focus-q small" style={{ marginTop: 14 }}>{s.question}</p>
      <h2 className="focus-answer">{s.answer}</h2>
      <p className="focus-copy">{s.copy}</p>

      <div className="hero-numeric">
        <div className="hero-figure solid edge-accent">
          <div className="hero-figure-top">
            <span className="eyebrow">{heroTitle}</span>
            <span className="chip chip--accent"><span className="shield" /> Lineaged</span>
          </div>
          <div>
            <div className="hero-figure-value num">{s.hero.value}</div>
            <div className="hero-figure-cap">{s.hero.delta} · {s.hero.basis}</div>
          </div>
        </div>
        <div className="hero-side">
          {s.side.map((tile) => (
            <div key={tile.label} className="hero-side-tile solid">
              <div>
                <div className="label">{tile.label}</div>
                <div className="val">{tile.val}</div>
              </div>
              <div className="basis">{tile.basis}</div>
            </div>
          ))}
        </div>
      </div>

      <CuriosityRail items={curiosities} onChoose={handleCuriosity} />
    </section>
  );
}

// ---------- NARRATIVE STORY page (editorial chapter) ----------
function NarrativeStory({ focus, setFocus, onOpenLineage, onAskQuickball }) {
  const n = window.SCIP.NARRATIVES.find((s) => s.key === focus) || window.SCIP.NARRATIVES[0];
  const idx = window.SCIP.NARRATIVES.indexOf(n);
  const prev = idx > 0 ? window.SCIP.NARRATIVES[idx - 1] : null;
  const next = idx < window.SCIP.NARRATIVES.length - 1 ? window.SCIP.NARRATIVES[idx + 1] : null;

  return (
    <section className="story glass" aria-label="Narrative chapter">
      <div className={`focus-poster focus-poster--${n.tone || "ok"}`} aria-hidden="true" style={{ opacity: 0.4 }} />
      <span className="story-num">CHAPTER {n.num} · {n.label.toUpperCase()}</span>
      <h2 className="story-title display h1">{n.title}</h2>
      <p className="story-lede">{n.lede}</p>
      <blockquote className="story-quote">"{n.quote}"</blockquote>

      <div className="story-stats">
        {n.stats.map((s) => (
          <div key={s.label} className="story-stat solid">
            <div className="label">{s.label}</div>
            <div className="val num">{s.val}</div>
            <div className={`delta ${s.tone}`}>{s.delta}</div>
          </div>
        ))}
      </div>

      <div className="curiosity" style={{ marginTop: 26 }}>
        <button className="chip" onClick={() => onOpenLineage("OD_TODAY", n.label)}>Show evidence</button>
        <button className="chip" onClick={() => onAskQuickball("explain group od today")}>Ask Quickball</button>
        <button className="chip" onClick={() => setFocus(next ? next.key : n.key)}>Continue to {next ? next.label : "—"} →</button>
      </div>

      <div className="story-nav">
        <button className="btn btn--ghost" disabled={!prev} onClick={() => prev && setFocus(prev.key)}>
          <IconChevron dir="left" /> {prev ? prev.label : "Start"}
        </button>
        <button className="btn btn--primary" disabled={!next} onClick={() => next && setFocus(next.key)}>
          {next ? next.label : "End"} <IconChevron />
        </button>
      </div>
    </section>
  );
}

// ---------- RUNWAY PANEL (forecast metaphor) ----------
function RunwayPanel({ onOpenLineage, layout = "default" }) {
  const f = window.SCIP.FORECAST;
  const r = f.runway;
  const layoutClass = `runway-panel glass edge-accent layout-${layout}`;
  return (
    <section className={layoutClass} aria-label="Month-end runway">
      <div className="runway-head">
        <div>
          <span className="eyebrow">May runway · landing forecast</span>
          <h2 className="display h3 title">A 7-working-day glide to AED 441.2M.</h2>
          <p className="sub">{f.basis}. Working-day arithmetic and projection live on the backend.</p>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn btn--ghost" onClick={() => onOpenLineage("FORECAST_LANDING", "Forecast landing")}>Forecast lineage</button>
        </div>
      </div>

      <div>
        <div className="runway" role="img" aria-label={`MTD position ${r.actual_pct}% along month`}>
          <div className="runway-grid" />
          <div className="runway-track" />
          <div className="runway-actual" style={{ left: 0, width: `${r.actual_pct}%` }} />
          <div className="runway-projected" style={{ left: `${r.actual_pct}%`, width: `${r.projected_pct - r.actual_pct}%` }} />
          <div className="runway-target" style={{ left: `${r.target_pct}%` }} />
          <div className="runway-now" style={{ left: `${r.actual_pct}%` }} />
          <div className="runway-marker" style={{ left: `${r.actual_pct}%` }} />
        </div>
        <div className="runway-axis"><span>1 May</span><span>Today</span><span>31 May</span></div>

        <div className="runway-stats">
          <div className="runway-stat solid">
            <div className="label">MTD actual</div>
            <div className="value num">{f.display.mtd_actual}</div>
            <div className="basis">R04 · {f.working_days.elapsed} of {f.working_days.total} working days</div>
          </div>
          <div className="runway-stat solid">
            <div className="label">May target</div>
            <div className="value num">{f.display.may_target}</div>
            <div className="basis">R02 MDO</div>
          </div>
          <div className="runway-stat solid">
            <div className="label">Required run-rate</div>
            <div className="value num">{f.display.daily_run_rate_required}</div>
            <div className="basis">For remaining {f.working_days.remaining} working days</div>
          </div>
          <div className="runway-stat solid runway-stat--accent">
            <div className="label">Projected landing</div>
            <div className="value num">{f.display.projected_landing}</div>
            <div className="basis">{f.display.projected_achievement} · {f.display.gap}</div>
          </div>
        </div>
      </div>

      <div className="runway-foot">
        <ul>
          <li><span className="dot dot--trust" /> Actual to today (R04)</li>
          <li><span style={{ width: 12, height: 2, background: "var(--teal-2)", display: "inline-block" }} /> Projected glide</li>
          <li><span style={{ width: 2, height: 12, background: "var(--text-hi)", opacity: 0.4, display: "inline-block" }} /> May target</li>
        </ul>
        <span className="mono small">Assumptions: {f.assumptions.length} · server-disclosed</span>
      </div>
    </section>
  );
}

// ---------- ACTION QUEUES ----------
function ActionQueues({ role, onOpenLineage, onOpenWorkflow }) {
  const queues = window.SCIP.QUEUES[role] || [];
  if (!queues.length) {
    return (
      <section className="queue-section" data-anchor="action-queues" aria-label="Action queues">
        <div className="section-head">
          <div>
            <span className="eyebrow">Risk & Action · L5 output</span>
            <h2 className="display h2 title">No action queue for this role</h2>
            <p className="sub">This role does not own account-level actions. Try CCO/GM/AGM or Collector/RM to see live queues.</p>
          </div>
        </div>
      </section>
    );
  }
  return (
    <section className="queue-section" data-anchor="action-queues" aria-label="Action queues">
      <div className="section-head">
        <div>
          <span className="eyebrow">Risk & Action · L5 output</span>
          <h2 className="display h2 title">Action queues · {window.SCIP.ROLES[role].label}</h2>
          <p className="sub">Each card is gated by lineage and maps to a workflow record with an immutable event log.</p>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <span className="chip chip--ok"><span className="dot dot--ok" /> {queues.length} ready</span>
          <span className="chip">11 stale</span>
        </div>
      </div>

      <div className="queue-grid">
        {queues.map((q) => (
          <article key={q.id} className={`queue-card solid queue-card--${q.severity}`}>
            <div className="queue-meta">
              <span>{q.action_type}</span>
              <span className="sep" />
              <span>{q.entity}</span>
            </div>
            <h3 className="queue-title">{q.title}</h3>
            <p className="queue-summary">{q.summary}</p>
            <div className="queue-key">
              <div className="queue-key-item"><div className="k">Owner</div><div className="v">{q.owner}</div></div>
              <div className="queue-key-item"><div className="k">Amount</div><div className="v">{q.amount}</div></div>
              <div className="queue-key-item"><div className="k">Accounts</div><div className="v">{q.account}</div></div>
              <div className="queue-key-item"><div className="k">Ageing</div><div className="v">{q.ageing}</div></div>
            </div>
            <div className="queue-foot">
              <span className="basis">Basis {q.basis}</span>
              <div className="queue-actions">
                <button className="btn btn--sm btn--ghost" onClick={() => onOpenLineage("OD_TODAY", q.title)}>Evidence</button>
                <button className="btn btn--sm btn--primary" onClick={() => onOpenWorkflow(q)}>Workflow</button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

Object.assign(window, {
  Arrival, LivePulseHome, NarrativesHome, FocusScreen, NarrativeStory,
  RunwayPanel, ActionQueues,
});
