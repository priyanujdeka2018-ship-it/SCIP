/* SCIP mock data — shaped to look like server-provided contracts
 * (no frontend computation; we just stage what the backend would emit).
 */

const ROLES = {
  board_cxo: {
    label: "Board / CXO",
    short: "BC",
    desc: "Board-safe story, risk, confidence.",
  },
  cco_gm_agm: {
    label: "CCO / GM / AGM",
    short: "CG",
    desc: "Intervention control, run-rate, escalations.",
  },
  finance: {
    label: "Finance",
    short: "FN",
    desc: "Reconciliation, PR/SOA, audit.",
  },
  mis_qcg_admin: {
    label: "MIS / QCG / Admin",
    short: "MQ",
    desc: "Data health, governance, refresh.",
  },
  collector_rm: {
    label: "Collector / RM",
    short: "CR",
    desc: "Own queues, promise follow-up, accounts.",
  },
};
const ROLE_KEYS = ["board_cxo", "cco_gm_agm", "finance", "mis_qcg_admin", "collector_rm"];

const TRUST = {
  snapshot_date: "21 May 2026",
  load_timestamp: "07:42 GST",
  tolerance_pct: 0.05,
  contract: "v2.4.1",
  sources_loaded: ["R02","R04","R08","R18","R36","R09","R10","R17","R20","R30","R31","R32","R34"],
  sources_missing: ["R38"],
  critical_lineage: { R02: 4, R04: 6, R08: 3, R18: 5, R36: 2 },
  posture: "ok", // ok | warn | risk
};

// ------- focus signals --------
const SIGNALS = {
  current_signal: {
    question: "Are we okay today?",
    answer: "Calm on the surface, two pockets need attention by Friday.",
    copy: "Group OD is steady against last refresh. Two ageing buckets in Sobha Dubai and one PR/SOA bottleneck are the only items requiring action this week.",
    poster: "ok",
    hero: {
      title: "Group overdue · today",
      value: "AED 184.6M",
      delta: "-2.1% vs yesterday",
      basis: "R18 · Sub Totals A–H aggregated · snapshot 21 May",
    },
    side: [
      { label: "Active accounts", val: "1,284", basis: "R09 · live receipts" },
      { label: "Broken PTPs (7d)", val: "37", basis: "R10 · promise vs receipt" },
    ],
  },
  month_movement: {
    question: "How is May moving?",
    answer: "On pace but the last week needs a 1.18× lift to land target.",
    copy: "Finance daily actuals (R04) are tracking 92% of the May MDO target (R02). Working-day arithmetic is server-side; the runway below shows where we sit today and what the remaining days require.",
    poster: "warn",
    hero: {
      title: "MTD collections",
      value: "AED 412.8M",
      delta: "92% of May MDO target",
      basis: "R04 Finance · R02 MDO",
    },
    side: [
      { label: "May target", val: "AED 448.5M", basis: "R02 MDO" },
      { label: "Projected landing", val: "AED 441.2M", basis: "Backend straight-line" },
    ],
  },
  risk_action: {
    question: "Where should we act?",
    answer: "Three pockets carry 64% of the open risk this week.",
    copy: "Risk surfaces are lineaged and action-oriented. Each card maps to a workflow record with assigned owner, due date and immutable event log. Collector/account evidence stays gated until you ask for depth.",
    poster: "risk",
    hero: {
      title: "Risk pressure index",
      value: "0.64",
      delta: "Up from 0.58 last week",
      basis: "R18 + R10 + R34 weighted · backend",
    },
    side: [
      { label: "Open actions", val: "82", basis: "Across roles · L5 output" },
      { label: "Stale > 7d", val: "11", basis: "Workflow event log" },
    ],
  },
};

// ------- narrative chapters --------
const NARRATIVES = [
  {
    key: "story",
    num: "01",
    label: "Story",
    question: "What is the board-level story?",
    title: "A composed quarter, with one chapter still to write.",
    lede: "May is on a credible path to its target. Sobha Dubai is carrying the month, UAQ is steady on advance, and the only true exposure sits in a small set of high-value PTP breaks under active follow-up.",
    quote: "Run-rate is sufficient, posture is calm, and lineage is intact across all critical sources except R38.",
    stats: [
      { label: "Projected landing", val: "AED 441.2M", delta: "98.4% of MDO target", tone: "ok" },
      { label: "Forward collectible · Q3", val: "AED 1.21B", delta: "+6.4% YoY", tone: "ok" },
      { label: "Risk pressure index", val: "0.64", delta: "+0.06 wk/wk", tone: "warn" },
    ],
  },
  {
    key: "portfolio",
    num: "02",
    label: "Portfolio",
    question: "What is the portfolio position?",
    title: "Group, Sobha and UAQ — composed, asymmetric, in balance.",
    lede: "Sobha contributes 71% of MTD collections with Dubai leading. UAQ advance is unusually strong from Siniya. The portfolio is balanced for the season; no entity is shouldering disproportionate risk.",
    quote: "Sobha Dubai and Siniya are the two engines of the month.",
    stats: [
      { label: "Sobha Dubai · MTD", val: "AED 248.4M", delta: "60.2% of group", tone: "ok" },
      { label: "Sobha AUH · MTD", val: "AED 44.9M", delta: "10.9% of group", tone: "ok" },
      { label: "UAQ · MTD", val: "AED 119.5M", delta: "28.9% of group", tone: "ok" },
    ],
  },
  {
    key: "dues",
    num: "03",
    label: "Dues",
    question: "Where is OD / dues risk?",
    title: "Two ageing pockets carry most of the pressure.",
    lede: "Of AED 184.6M in group OD, AED 117.3M sits in 61–120 day buckets — concentrated in 142 high-value accounts under collector RM-4 and RM-7. Termination-stage exposure is contained at AED 11.4M across 6 accounts.",
    quote: "The 61–120 bucket in Sobha Dubai is the one to watch this week.",
    stats: [
      { label: "61–120 day · OD", val: "AED 117.3M", delta: "63.5% of total OD", tone: "warn" },
      { label: "180+ day · OD", val: "AED 22.1M", delta: "Stable wk/wk", tone: "risk" },
      { label: "Termination stage", val: "AED 11.4M", delta: "6 accounts · R34", tone: "risk" },
    ],
  },
  {
    key: "advance",
    num: "04",
    label: "Advance",
    question: "What is the advance opportunity?",
    title: "Advance is quietly outperforming — CY rebate is the lever.",
    lede: "R08 advance summary shows AED 332.6M of CY advance, of which AED 84.1M is eligible for rebate-led acceleration. Siniya leads; Downtown UAQ is catching up after April's milestone push.",
    quote: "Rebate-eligible advance is the cleanest lever for the next 14 days.",
    stats: [
      { label: "CY advance", val: "AED 332.6M", delta: "+11.8% MoM", tone: "ok" },
      { label: "Rebate-eligible", val: "AED 84.1M", delta: "25.3% of CY", tone: "ok" },
      { label: "FY forward · Q3", val: "AED 562.0M", delta: "On schedule", tone: "ok" },
    ],
  },
  {
    key: "roadmap",
    num: "05",
    label: "Roadmap",
    question: "What should leadership do next?",
    title: "Three decisions to close out May with composure.",
    lede: "Land the month by clearing the two ageing pockets, approve the rebate push for the rebate-eligible CY pool, and ratify the R38 source refresh so risk lineage is whole again before the next board cycle.",
    quote: "All three decisions are scoped, lineaged, and ready for present-ready output.",
    stats: [
      { label: "Clear 61–120 pocket", val: "AED 117.3M", delta: "RM-4 · RM-7 owners", tone: "warn" },
      { label: "Rebate push (14d)", val: "AED 84.1M", delta: "Sobha Dubai · Siniya", tone: "ok" },
      { label: "Restore R38 lineage", val: "1 source", delta: "MIS/QCG owner", tone: "warn" },
    ],
  },
];

// ------- forecast (Month Movement) --------
const FORECAST = {
  status: "ok",
  basis: "R04 Finance daily actuals × R02 May MDO target",
  working_days: { elapsed: 14, remaining: 7, total: 21 },
  display: {
    mtd_actual: "AED 412.8M",
    may_target: "AED 448.5M",
    daily_run_rate_current: "AED 29.5M / day",
    daily_run_rate_required: "AED 34.9M / day",
    projected_landing: "AED 441.2M",
    projected_achievement: "98.4%",
    gap: "AED 7.3M short",
  },
  runway: {
    actual_pct: 67,     // MTD position on month axis (14/21 ≈ 67%)
    projected_pct: 92,  // projected at month-end on target axis (98.4% → display)
    target_pct: 100,
    confidence: "high",
  },
  assumptions: [
    "Run-rate calculated on R04 Finance actuals, excluding inter-company.",
    "Remaining working days exclude UAE federal holidays (3 in May 2026).",
    "Projection is straight-line on current run-rate; no behavioural model.",
    "Sobha AUH child split treated as not-yet-disclosed where source absent.",
  ],
};

// ------- command-centre tiles (per role) --------
const TILES = {
  board_cxo: [
    { id: "t1", title: "Group OD today", value: "184.6", unit: "M AED", basis: "R18", trust: true, severity: "warn" },
    { id: "t2", title: "MTD vs May MDO target", value: "92%", unit: "", basis: "R04 × R02", trust: true, severity: "ok" },
    { id: "t3", title: "Projected May landing", value: "441.2", unit: "M AED", basis: "Forecast", trust: true, severity: "ok" },
    { id: "t4", title: "Risk pressure index", value: "0.64", unit: "", basis: "Composite", trust: true, severity: "warn" },
  ],
  cco_gm_agm: [
    { id: "t1", title: "Group OD today", value: "184.6", unit: "M AED", basis: "R18", trust: true, severity: "warn" },
    { id: "t2", title: "Open actions across teams", value: "82", unit: "", basis: "Action queues", trust: true, severity: "warn" },
    { id: "t3", title: "Broken PTPs · last 7d", value: "37", unit: "", basis: "R10", trust: true, severity: "warn" },
    { id: "t4", title: "Required run-rate", value: "34.9", unit: "M/day", basis: "R04 × R02", trust: true, severity: "warn" },
  ],
  finance: [
    { id: "t1", title: "PR to SOA · stale > 5d", value: "23", unit: "items", basis: "R20", trust: true, severity: "warn" },
    { id: "t2", title: "Daily collections · today", value: "27.4", unit: "M AED", basis: "R04", trust: true, severity: "ok" },
    { id: "t3", title: "Reconciliation tolerance", value: "0.04%", unit: "", basis: "R04 × R18", trust: true, severity: "ok" },
    { id: "t4", title: "Advance posted", value: "332.6", unit: "M AED", basis: "R08", trust: true, severity: "ok" },
  ],
  mis_qcg_admin: [
    { id: "t1", title: "Sources loaded today", value: "13/14", unit: "", basis: "Manifest", trust: true, severity: "warn" },
    { id: "t2", title: "Lineage coverage", value: "94%", unit: "critical", basis: "5 R-series", trust: true, severity: "ok" },
    { id: "t3", title: "Adapter failures", value: "0", unit: "this cycle", basis: "Observability", trust: true, severity: "ok" },
    { id: "t4", title: "RBAC denials (24h)", value: "4", unit: "logged", basis: "Audit", trust: true, severity: "ok" },
  ],
  collector_rm: [
    { id: "t1", title: "Your active queue", value: "18", unit: "accounts", basis: "R09 · scoped", trust: true, severity: "warn" },
    { id: "t2", title: "Your broken PTPs", value: "4", unit: "this week", basis: "R10", trust: true, severity: "warn" },
    { id: "t3", title: "Promised inflows · 7d", value: "5.6", unit: "M AED", basis: "R10", trust: true, severity: "ok" },
    { id: "t4", title: "Termination follow-ups", value: "2", unit: "open", basis: "R34", trust: true, severity: "risk" },
  ],
};

// ------- action queues --------
const QUEUES = {
  cco_gm_agm: [
    {
      id: "q1",
      severity: "risk",
      action_type: "61–120 day cluster",
      entity: "Sobha Dubai · Project Hartland Phase 4",
      title: "AED 38.4M in 12 accounts crossing 120d threshold",
      summary: "Cluster has 4 broken PTPs in last 7 days. RM-4 ownership. Recommend escalation huddle today, then RM reassignment if no commit by EOD.",
      owner: "RM-4 · Aisha Khalid",
      account: "12 accounts",
      amount: "AED 38.4M",
      ageing: "91–120d",
      basis: "R18 · R10 · R34",
    },
    {
      id: "q2",
      severity: "warn",
      action_type: "Broken PTP follow-up",
      entity: "Sobha Dubai · Mixed",
      title: "11 PTPs broken in last 72 hours — high value",
      summary: "Aggregate AED 14.2M committed but unreceipted. Recommend personal RM call-down today; finance to align on receipt window.",
      owner: "RM-7 · Omar Yousef",
      account: "11 accounts",
      amount: "AED 14.2M",
      ageing: "0–30d",
      basis: "R10 · R09",
    },
    {
      id: "q3",
      severity: "warn",
      action_type: "PR/SOA bottleneck",
      entity: "Sobha AUH · pre-registration",
      title: "23 PRs stalled > 5d in TAT pipeline",
      summary: "PR-to-SOA TAT exceeds policy on 23 items; finance assignment needed. Customer experience impact if not resolved by Thursday.",
      owner: "Finance ops",
      account: "23 items",
      amount: "AED 6.1M",
      ageing: "PR > 5d",
      basis: "R20",
    },
    {
      id: "q4",
      severity: "risk",
      action_type: "Termination stage",
      entity: "Sobha Dubai · Project Estepona",
      title: "6 accounts at termination decision point",
      summary: "Legal escalation gate reached. CCO sign-off requested before termination notices are dispatched. All lineage from R34 is intact.",
      owner: "Legal + CCO",
      account: "6 accounts",
      amount: "AED 11.4M",
      ageing: "180+d",
      basis: "R34",
    },
    {
      id: "q5",
      severity: "ok",
      action_type: "Rebate push opportunity",
      entity: "Sobha Dubai · Siniya",
      title: "84.1M CY advance rebate-eligible — accelerate",
      summary: "Within the rebate window. Coordinated outreach script ready. Finance has confirmed treasury bandwidth for receipt.",
      owner: "RM-2 · Hassan Mohd",
      account: "Multiple",
      amount: "AED 84.1M",
      ageing: "—",
      basis: "R08",
    },
    {
      id: "q6",
      severity: "warn",
      action_type: "Stale workflow",
      entity: "Across teams",
      title: "11 workflows stale > 7 days",
      summary: "Workflows assigned but not progressed. Recommend reassignment review or close with disposition. Audit log preserved.",
      owner: "Various",
      account: "11 workflows",
      amount: "—",
      ageing: "—",
      basis: "Workflow log",
    },
  ],
  board_cxo: [
    {
      id: "q1",
      severity: "warn",
      action_type: "Decision · approve",
      entity: "Group",
      title: "Rebate push for AED 84.1M CY advance",
      summary: "CCO recommends acceleration. Treasury aligned. Board ratification requested by Thursday.",
      owner: "CCO · Treasury",
      account: "—",
      amount: "AED 84.1M",
      ageing: "—",
      basis: "R08 · CCO memo",
    },
    {
      id: "q2",
      severity: "risk",
      action_type: "Decision · ratify",
      entity: "Sobha Dubai · Estepona",
      title: "Termination of 6 long-overdue accounts",
      summary: "Legal escalation reached after 180+ days. Board ratification required before notices dispatch.",
      owner: "Legal · CCO",
      account: "6 accounts",
      amount: "AED 11.4M",
      ageing: "180+d",
      basis: "R34 · Legal",
    },
  ],
  finance: [
    {
      id: "q1",
      severity: "warn",
      action_type: "PR/SOA backlog",
      entity: "Sobha AUH",
      title: "23 PR items stalled > 5d in TAT",
      summary: "Pre-registration receipts not yet bound to SOA. Finance ops queue full lineage from R20.",
      owner: "Finance ops",
      account: "23 items",
      amount: "AED 6.1M",
      ageing: "> 5d",
      basis: "R20",
    },
    {
      id: "q2",
      severity: "ok",
      action_type: "Reconciliation",
      entity: "Group",
      title: "R04 vs R18 tolerance 0.04%",
      summary: "Within the 0.05% locked tolerance. No action required; lineage hash recorded.",
      owner: "Finance",
      account: "—",
      amount: "—",
      ageing: "—",
      basis: "R04 × R18",
    },
  ],
  mis_qcg_admin: [
    {
      id: "q1",
      severity: "warn",
      action_type: "Source refresh",
      entity: "R38 Risk Analysis",
      title: "R38 not loaded in latest cycle",
      summary: "Adapter reports source missing in last refresh. Risk lineage degraded for some composite metrics. Owner contact needed.",
      owner: "MIS · QCG",
      account: "—",
      amount: "—",
      ageing: "—",
      basis: "Manifest",
    },
  ],
  collector_rm: [
    {
      id: "q1",
      severity: "risk",
      action_type: "Broken PTP",
      entity: "Acct #4827 · Hartland P4 · Unit 14-203",
      title: "Promise of AED 1.4M missed by 3 days",
      summary: "Customer last contact: 17 May. Reach today; propose 7-day extension with finance approval if needed.",
      owner: "You (RM-4)",
      account: "4827",
      amount: "AED 1.4M",
      ageing: "91–120d",
      basis: "R10",
    },
    {
      id: "q2",
      severity: "warn",
      action_type: "PTP follow-up",
      entity: "Acct #3902 · Estepona · Unit 8-1112",
      title: "PTP due tomorrow, no receipt yet",
      summary: "Customer responded positively last week. Soft nudge today; receipt expected in next 36h.",
      owner: "You (RM-4)",
      account: "3902",
      amount: "AED 0.6M",
      ageing: "31–60d",
      basis: "R10",
    },
  ],
};

// ------- workflows --------
const WORKFLOWS = {
  q1: {
    state: "assigned",
    owner: "RM-4 · Aisha Khalid",
    due: "23 May 2026",
    timeline: [
      { time: "18 May 09:14", title: "Action queued from R10/R18 evidence", note: "Lineage hash a83f…", done: true },
      { time: "18 May 15:42", title: "Assigned to RM-4 by CCO ops", note: "Actor: cco_manager_demo · audit-logged", done: true },
      { time: "19 May 11:08", title: "Customer outreach attempt 1", note: "Voice · no answer", done: true },
      { time: "20 May 09:30", title: "Promise to pay logged", note: "AED 1.4M by 23 May", done: true },
      { time: "21 May —",     title: "Awaiting receipt window", note: "Finance flagged for confirm", done: false },
    ],
  },
};

// ------- lineage references --------
const LINEAGE = {
  // metric_key → provenance chain (4–6 nodes)
  OD_TODAY: {
    metric: "Group OD today",
    value: "AED 184.6M",
    chain: [
      { label: "Source file", value: "R18_Consolidated_Overdue.xlsx", note: "Snapshot 21 May 2026 · 07:42 GST", verified: true },
      { label: "Sheet", value: "OD_Summary_Daily", note: "Detected by R18OverdueAdapter", verified: true },
      { label: "Cell / range", value: "B12:H64", note: "Sub Totals A through H aggregated", verified: true },
      { label: "Validation", value: "Tolerance check 0.04%", note: "Within locked 0.05% tolerance", verified: true },
      { label: "Confidence", value: "High", note: "All required sub totals present and matched", verified: true },
      { label: "Reporting basis", value: "R18 · OD / overdue / ageing", note: "Entity hierarchy locked", verified: true },
    ],
  },
  MTD_VS_TARGET: {
    metric: "MTD vs May MDO target",
    value: "92%",
    chain: [
      { label: "Source files", value: "R04_Finance_Daily.xlsx · R02_MDO.xlsx", note: "Both refreshed 21 May", verified: true },
      { label: "Sheets", value: "Daily_Collections / MDO_May", note: "Adapter-resolved", verified: true },
      { label: "Range", value: "MTD totals · target row 14", note: "Server arithmetic only", verified: true },
      { label: "Validation", value: "Cross-source reconciliation OK", note: "Within 0.05%", verified: true },
      { label: "Confidence", value: "High", note: "Both sources lineaged", verified: true },
      { label: "Reporting basis", value: "R04 Finance × R02 MDO", note: "Finance vs MDO labels live", verified: true },
    ],
  },
  FORECAST_LANDING: {
    metric: "Projected May landing",
    value: "AED 441.2M",
    chain: [
      { label: "Computed by", value: "Backend · /forecast/month-end", note: "No frontend computation", verified: true },
      { label: "Inputs", value: "R04 MTD + working days remaining", note: "Straight-line on run-rate", verified: true },
      { label: "Target source", value: "R02 May MDO", note: "Achievement = projection / target", verified: true },
      { label: "Validation", value: "Working-day arithmetic checked", note: "21 total · 14 elapsed · 7 remaining", verified: true },
      { label: "Confidence", value: "High · disclosed", note: "Assumptions exposed in panel", verified: true },
      { label: "Reporting basis", value: "Finance × MDO · disclosed", note: "Not behaviour-modelled", verified: true },
    ],
  },
  RISK_PRESSURE: {
    metric: "Risk pressure index",
    value: "0.64",
    chain: [
      { label: "Composite of", value: "R18 ageing + R10 PTP + R34 termination", note: "Weights server-defined", verified: true },
      { label: "Sources loaded", value: "3 of 3 critical", note: "R38 absent · supplementary only", verified: true },
      { label: "Validation", value: "Component lineage all present", note: "Composite trusted", verified: true },
      { label: "Confidence", value: "Medium · component", note: "Supplementary R38 missing", verified: false },
      { label: "Reporting basis", value: "Composite · server-side", note: "Server returns score + components", verified: true },
    ],
  },
};

// ------- role-aware Live Pulse doors --------
// The triplet count is locked (calm = three doors). Labels adapt to the lens.
const LIVE_PULSE_BY_ROLE = {
  board_cxo: [
    { key: "current_signal", eyebrow: "Are we okay today?", title: "Current Signal", desc: "A board-safe reading of posture: OD, collections and confidence.", metric: "184.6M", unit: "AED · group OD", severity: "warn" },
    { key: "month_movement", eyebrow: "Will we land May?", title: "Month Landing", desc: "Projected landing vs MDO target, with disclosed assumptions.", metric: "98.4%", unit: "projected achievement", severity: "ok" },
    { key: "risk_action", eyebrow: "What needs my decision?", title: "Decisions", desc: "Only items needing board ratification or sign-off appear here.", metric: "2", unit: "open decisions", severity: "warn" },
  ],
  cco_gm_agm: [
    { key: "current_signal", eyebrow: "Are we okay today?", title: "Current Signal", desc: "A calm reading of what needs attention now, anchored on OD, collections and confidence.", metric: "184.6M", unit: "AED · group OD", severity: "warn" },
    { key: "month_movement", eyebrow: "How is May moving?", title: "Month Movement", desc: "MTD movement, run-rate and target gap. The forecast discloses its basis.", metric: "92%", unit: "of May target", severity: "warn" },
    { key: "risk_action", eyebrow: "Where should we act?", title: "Risk & Action", desc: "Lineaged action queues with owners, due dates and immutable workflow events.", metric: "82", unit: "open actions", severity: "risk" },
  ],
  finance: [
    { key: "current_signal", eyebrow: "Is the ledger clean?", title: "Reconciliation", desc: "Daily actuals vs OD cross-checks, tolerance posture and PR/SOA state.", metric: "0.04%", unit: "tolerance · in bounds", severity: "ok" },
    { key: "month_movement", eyebrow: "How is May moving?", title: "Month Movement", desc: "MTD actuals against MDO target with full basis disclosure.", metric: "92%", unit: "of May target", severity: "warn" },
    { key: "risk_action", eyebrow: "What is stuck?", title: "Process Queue", desc: "PR-to-SOA bottlenecks, receipt windows, audit-ready exceptions.", metric: "23", unit: "stalled items", severity: "warn" },
  ],
  mis_qcg_admin: [
    { key: "current_signal", eyebrow: "Is the data healthy?", title: "Data Health", desc: "Source freshness, adapter success and lineage coverage this cycle.", metric: "13/14", unit: "sources loaded", severity: "warn" },
    { key: "month_movement", eyebrow: "How is the platform used?", title: "Adoption", desc: "Role engagement, evidence opens and refresh cadence.", metric: "94%", unit: "lineage coverage", severity: "ok" },
    { key: "risk_action", eyebrow: "What needs governance?", title: "Governance", desc: "Refresh gaps, RBAC denials and audit follow-ups.", metric: "1", unit: "source missing", severity: "warn" },
  ],
  collector_rm: [
    { key: "current_signal", eyebrow: "How is my book today?", title: "My Book", desc: "Your scoped accounts, receipts landed and what moved overnight.", metric: "18", unit: "active accounts", severity: "warn" },
    { key: "month_movement", eyebrow: "What have I promised?", title: "My Promises", desc: "PTPs due this week, broken promises and expected inflows.", metric: "5.6M", unit: "AED promised · 7d", severity: "ok" },
    { key: "risk_action", eyebrow: "Who do I call first?", title: "My Queue", desc: "Your prioritised follow-ups with full account evidence.", metric: "6", unit: "due today", severity: "risk" },
  ],
};


const QUICKBALL_SUGGEST = [
  "Explain Group OD today",
  "Take me to Risk & Action",
  "Switch to Sobha Dubai",
  "Show source basis for projected landing",
  "Start Present mode",
];

const QUICKBALL_ANSWERS = {
  "explain group od today": {
    metric: "Group OD today",
    value: "AED 184.6M",
    answer: "Group OD today aggregates Sub Totals A–H from R18 Consolidated Overdue, snapshot dated 21 May 2026 07:42 GST. Tolerance check vs R04 Finance daily is 0.04%, within the locked 0.05% rule. Down 2.1% from yesterday's snapshot; movement driven by AED 4M receipts in Sobha Dubai 61–120d bucket.",
    basis: "R18 · lineaged · confidence high",
    blocked: false,
    lineage_key: "OD_TODAY",
  },
  "what changed since yesterday": {
    metric: "Day-over-day delta",
    value: "−AED 4.0M",
    answer: "Net OD movement since the previous snapshot is −AED 4.0M, driven primarily by receipts of AED 4.6M against Sobha Dubai 61–120 day bucket, offset by AED 0.6M of new entries into 31–60 day bucket. No structural change to the risk pressure index.",
    basis: "R18 snapshot 20 May vs 21 May",
    blocked: false,
    lineage_key: "OD_TODAY",
  },
  "show source basis for projected landing": {
    metric: "Projected May landing",
    value: "AED 441.2M",
    answer: "Projected month-end landing is generated by the backend forecast service using R04 Finance MTD (AED 412.8M) and the remaining working days (7 of 21), straight-lined on the current daily run-rate of AED 29.5M. Required run-rate to hit the R02 May MDO target of AED 448.5M is AED 34.9M / day for the remaining 7 working days.",
    basis: "Forecast service · R04 × R02",
    blocked: false,
    lineage_key: "FORECAST_LANDING",
  },
  "open action list for rm-4": {
    metric: "RM-4 active queue",
    value: "18 accounts",
    answer: "RM-4 currently owns 18 active accounts totalling AED 47.6M. The 91–120 day cluster on Hartland P4 carries the highest concentration (12 accounts, AED 38.4M) with 4 broken PTPs in the last 7 days. Recommend escalation huddle today and reassignment review if no commit by EOD.",
    basis: "R09 + R10 + R18 · scoped to RM-4",
    blocked: false,
    lineage_key: "OD_TODAY",
  },
  "prepare board explanation for risk pressure": {
    metric: "Risk pressure index — board explanation",
    value: "0.64",
    answer: "Risk pressure has risen from 0.58 to 0.64 over the past week, driven by an increase in broken PTPs (37 in the last 7 days vs 24 the prior week). Composition: ageing 41%, PTP breakage 34%, termination exposure 25%. Composite is server-side; component lineage is intact for R18, R10 and R34. R38 is not loaded — composite is rendered with that disclosure.",
    basis: "Composite · R18 + R10 + R34 · R38 absent",
    blocked: false,
    lineage_key: "RISK_PRESSURE",
  },
};

const BLOCKED_ANSWER = {
  metric: "Untrusted metric",
  value: "—",
  answer: "Quickball cannot answer because the underlying metric does not have complete lineage in this snapshot. No fallback figure will be invented. Try a metric backed by R04, R02, R08, R18 or R36.",
  basis: "Trust gate · no silent fallback",
  blocked: true,
};

window.SCIP = {
  ROLES, ROLE_KEYS, TRUST, SIGNALS, NARRATIVES, FORECAST, TILES, QUEUES, WORKFLOWS,
  LINEAGE, QUICKBALL_SUGGEST, QUICKBALL_ANSWERS, BLOCKED_ANSWER, LIVE_PULSE_BY_ROLE,
};
