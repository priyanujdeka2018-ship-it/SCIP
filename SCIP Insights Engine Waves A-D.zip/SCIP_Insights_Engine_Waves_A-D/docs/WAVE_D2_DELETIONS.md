# SCIP Wave D-2 — Deletion Manifest (apply ONLY after live cutover is stable)

This is the final, irreversible cleanup. Do **not** apply it until:
1. D-1 reported `placement_shadow.violations == []` and per-role order parity on the **live** Render payload, and
2. D-2 cutover ran with `SCIP_PLACEMENT_RENDER=binder` on live and the role cards matched the prior static render (the `smoke_placement_wave_d2.py` render-parity check, run against the real `command_centres`).

Until both hold, keep `SCIP_PLACEMENT_RENDER=static` and leave everything below in place. Rollback for every item is `git revert` (deletion is the only step in this whole programme that is not env-reversible — that is why it is last and gated).

## Delete (Backend/command_centres.py)
- `_board_cards(payload)`
- `_ops_cards(payload)`
- `_finance_cards(payload)`
- `_mis_cards(payload)`
- `_collector_cards(payload)`
- the inline severity ternary `"risk" if ach is not None and ach < 50 else "monitor"` (already superseded by the registry `threshold_cross` predicate in Wave B)
- the legacy branch of the `roles = {...}` assignment in `build_command_centres` (keep only the `SCIP_PLACEMENT_RENDER=binder` path; drop the env switch once binder is the sole source)

Keep: `_card`, `_metric_ref`, `_fmt_aed`, `_fmt_pct`, `_build_trust_bar`, the forecast-card injection, and `_ensure_batch5_card_contract` — the binder render path reuses these.

## Delete / deprecate (Backend/quickball.py)
- `_role_interpretation(...)` body (Wave C retired it; the constrained editorial path is now the source for Narratives role notes)
- the interpretive segment of `explain_metric(...)` (keep the deterministic trust spine)

## Delete (Frontend App.jsx)
- `pickCardsForFocus(...)` selection rules (Live Pulse placement is backend `surface_placement` from Wave B; the rest now comes from the binder)
- the data-bound entries of `getPrimaryCopy(...)` / `focusCopy` (keep pure scaffolding copy)

## Deprecate in place (do NOT delete the files)
- `FINAL_section_mapping.json` → `submodules[].kpis` and `global_component_rules`/`cross_section_feeds` remain as the **rules** the binder enforces, but `kpis` is no longer the placement authority. Add `"_deprecated_as_placement_authority": true` next to each `kpis` array; placement now lives in `section_placement.json`.
- `FINAL_metrics.json` → `metrics[].used_in` is now reference only; placement authority is `section_placement.json`. Mark with a top-level `"_used_in_is_reference_only": true`.

## Carry forward the one real finding
`section_placement.json` quarantined `s05_sm4__m037` — `M037 npv_rebate_rate_pct` was bound into `S05_SM4`, which `boundary_rules` forbid ("NPV lives in S01, not S05 — no re-display of numbers"). Before deleting `used_in`, **remove `S05_SM4` from M037's `used_in`** in `FINAL_metrics.json` (or confirm it is intentional advisory-only with no number re-display). This is a latent inconsistency the migration surfaced; do not silently drop it.

## After deletion — verification
- `SCIP_USE_REAL_COMMAND_CENTRES=1 python smoke_placement_wave_d1.py` (order parity on live) — still green.
- `python smoke_placement_wave_d2.py` render parity — still green (against the binder-only path).
- Frontend: Live Pulse and Narratives render unchanged; no card lost; no number changed.
