/* SCIP — primitive components: chrome, tiles, chips, helpers */
/* eslint-disable react/prop-types */

const { useState, useEffect, useRef, useMemo, useCallback } = React;

// ---------- icons (drawn with SVG primitives only — square / circle / lines) -----
function IconChevron({ size = 14, dir = "right" }) {
  const r = { right: 0, left: 180, down: 90, up: -90 }[dir] || 0;
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" style={{ transform: `rotate(${r}deg)` }} aria-hidden="true">
      <path d="M6 3 L11 8 L6 13" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}
function IconClose({ size = 14 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" aria-hidden="true">
      <path d="M4 4 L12 12 M12 4 L4 12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
  );
}
function IconBolt({ size = 14 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" aria-hidden="true">
      <path d="M9 1 L3 9 L7 9 L7 15 L13 7 L9 7 Z" stroke="currentColor" strokeWidth="1.2" fill="none" strokeLinejoin="round"/>
    </svg>
  );
}
function IconPulse({ size = 14 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" aria-hidden="true">
      <path d="M1 8 H5 L7 4 L9 12 L11 8 H15" stroke="currentColor" strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}
function IconBook({ size = 14 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" aria-hidden="true">
      <rect x="2.5" y="2.5" width="11" height="11" rx="1.5" stroke="currentColor" strokeWidth="1.2" fill="none"/>
      <path d="M5 6 H11 M5 8.5 H11 M5 11 H9" stroke="currentColor" strokeWidth="1" strokeLinecap="round"/>
    </svg>
  );
}
function IconSearch({ size = 14 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" aria-hidden="true">
      <circle cx="7" cy="7" r="4" stroke="currentColor" strokeWidth="1.4" fill="none"/>
      <path d="M10 10 L14 14" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
    </svg>
  );
}

// ---------- Chrome (top nav with brand, route nav, entity + role pills) ----------
const ENTITIES = [
  { value: "group",        label: "Group" },
  { value: "sobha",        label: "Sobha" },
  { value: "sobha_dubai",  label: "Sobha Dubai" },
  { value: "sobha_auh",    label: "Sobha AUH" },
  { value: "uaq",          label: "UAQ" },
  { value: "siniya",       label: "Siniya" },
  { value: "downtown_uaq", label: "Downtown UAQ" },
];
function entityLabel(v) { return (ENTITIES.find((e) => e.value === v) || ENTITIES[0]).label; }

function Chrome({ route, setRoute, role, setRole, entity, setEntity, dataDate }) {
  const [menu, setMenu] = useState(false);
  const [entMenu, setEntMenu] = useState(false);
  const ref = useRef(null);
  const entRef = useRef(null);
  useEffect(() => {
    function onClick(e) {
      if (ref.current && !ref.current.contains(e.target)) setMenu(false);
      if (entRef.current && !entRef.current.contains(e.target)) setEntMenu(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);
  const roles = window.SCIP.ROLES;
  return (
    <header className="chrome" aria-label="SCIP top chrome">
      <div className="chrome-brand" onClick={() => setRoute("arrival")}>
        <div className="chrome-mark">S</div>
        <div>
          <div className="chrome-name">SCIP</div>
          <div className="chrome-sub">{dataDate} · {window.SCIP.TRUST.load_timestamp}</div>
        </div>
      </div>
      <nav className="chrome-nav" aria-label="Primary navigation">
        <button aria-current={route === "live_pulse"} onClick={() => setRoute("live_pulse")}>Live Pulse</button>
        <button aria-current={route === "narratives"} onClick={() => setRoute("narratives")}>Narratives</button>
      </nav>
      <div className="chrome-right">
        <div style={{ position: "relative" }} ref={entRef}>
          <button className="role-pill entity-pill" onClick={() => setEntMenu(!entMenu)} aria-haspopup="true" aria-expanded={entMenu} title="Entity scope">
            <span className="entity-glyph" aria-hidden="true">⌬</span>
            <span>{entityLabel(entity)}</span>
            <span className="caret"><IconChevron dir="down" /></span>
          </button>
          {entMenu && (
            <div className="role-menu glass" role="menu" style={{ width: 240 }}>
              <div style={{ padding: "8px 12px 4px", fontFamily: "var(--f-mono)", fontSize: 10, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--text-mute)" }}>Entity scope</div>
              {ENTITIES.map((e) => (
                <button key={e.value} aria-current={entity === e.value} onClick={() => { setEntity(e.value); setEntMenu(false); }}>
                  <div className="avatar-sm" style={{ background: entity === e.value ? "linear-gradient(135deg, var(--accent), var(--accent-hi))" : "rgba(255,255,255,0.08)", color: entity === e.value ? "#1a1407" : "var(--text)", fontSize: 11 }}>
                    {e.label[0]}
                  </div>
                  <div>
                    <div className="role-name">{e.label}</div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
        <div style={{ position: "relative" }} ref={ref}>
          <button className="role-pill" onClick={() => setMenu(!menu)} aria-haspopup="true" aria-expanded={menu}>
            <span className="avatar">{roles[role].short}</span>
            <span>{roles[role].label}</span>
            <span className="caret"><IconChevron dir="down" /></span>
          </button>
          {menu && (
            <div className="role-menu glass" role="menu">
              {window.SCIP.ROLE_KEYS.map((k) => (
                <button key={k} aria-current={role === k} onClick={() => { setRole(k); setMenu(false); }}>
                  <div className="avatar-sm" style={{ background: role === k ? "linear-gradient(135deg, var(--accent), var(--accent-hi))" : "rgba(255,255,255,0.08)", color: role === k ? "#1a1407" : "var(--text)" }}>
                    {roles[k].short}
                  </div>
                  <div>
                    <div className="role-name">{roles[k].label}</div>
                    <div className="role-desc">{roles[k].desc}</div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

// ---------- Context strip (quiet meta line — no R-codes) ----------
function ContextStrip({ route, focus, role, entity, setEntity }) {
  const focusLabel = useMemo(() => {
    if (route === "narratives") {
      const n = window.SCIP.NARRATIVES.find((s) => s.key === focus);
      return n ? n.label : "Story";
    }
    const map = { current_signal: "Current Signal", month_movement: "Month Movement", risk_action: "Risk & Action" };
    return map[focus] || "Current Signal";
  }, [route, focus]);
  const t = window.SCIP.TRUST;
  return (
    <div className="context-strip glass--quiet" aria-label="Context">
      <span className="label">Reading</span>
      <span className="chip chip--accent">{focusLabel}</span>
      <span className="sep" />
      <span className="chip">{entityLabel(entity)}</span>
      <span className="sep" />
      <span className="chip">{window.SCIP.ROLES[role].label}</span>
      <span style={{ flex: 1 }} />
      <span className="chip"><span className="dot dot--ok dot--pulse" /> Live · {t.contract}</span>
    </div>
  );
}

// ---------- Tile (lineaged KPI tile, calm) ----------
function Tile({ tile, onOpenLineage, autoLineage }) {
  const sev = tile.severity || "ok";
  const sevDot = sev === "risk" ? "dot--risk" : sev === "warn" ? "dot--warn" : "dot--ok";
  const lineageKey = tile.lineage_key || (
    tile.title.toLowerCase().includes("od") ? "OD_TODAY" :
    tile.title.toLowerCase().includes("target") || tile.title.toLowerCase().includes("mtd") ? "MTD_VS_TARGET" :
    tile.title.toLowerCase().includes("landing") || tile.title.toLowerCase().includes("forecast") ? "FORECAST_LANDING" :
    tile.title.toLowerCase().includes("risk") ? "RISK_PRESSURE" : "OD_TODAY"
  );
  return (
    <article
      className="tile solid"
      onClick={() => onOpenLineage(lineageKey, tile.title)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => { if (e.key === "Enter") onOpenLineage(lineageKey, tile.title); }}
    >
      <div className="tile-head">
        <span className="eyebrow eyebrow--mute"><span className={`dot ${sevDot}`} /> &nbsp;{sev === "risk" ? "Risk" : sev === "warn" ? "Attention" : "On track"}</span>
        {tile.trust && (
          <span className="tile-trust"><span className="shield" /> Lineaged</span>
        )}
      </div>
      <div>
        <h4 className="tile-title">{tile.title}</h4>
        <div className="tile-value">{tile.value}{tile.unit && <span className="unit">{tile.unit}</span>}</div>
      </div>
      <div className="tile-foot">
        <span>{tile.basis}</span>
        <span className="arrow"><IconChevron /></span>
      </div>
    </article>
  );
}

// ---------- Curiosity rail (chip row beneath answers) ----------
function CuriosityRail({ items, onChoose }) {
  return (
    <div className="curiosity">
      {items.map((it) => (
        <button key={it.k} className="chip" onClick={() => onChoose(it.k)}>{it.label}</button>
      ))}
    </div>
  );
}

// ---------- Trust rail (calm bottom strip; details on click) ----------
function TrustRail() {
  const t = window.SCIP.TRUST;
  const [open, setOpen] = useState(false);
  return (
    <div className="trust-rail glass--quiet" aria-label="Data trust posture">
      <div className="group">
        <span className="dot dot--trust dot--pulse" />
        <span style={{ color: "var(--text)" }}>Lineage live · all critical sources verified</span>
      </div>
      <div className="group">
        <span>Snapshot {t.snapshot_date}</span>
        <span style={{ color: "var(--text-faint)" }}>·</span>
        <span>Tolerance {t.tolerance_pct}%</span>
        <button
          className="btn btn--sm btn--ghost"
          style={{ height: 26, padding: "0 11px", fontSize: 11, letterSpacing: "0.06em" }}
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
        >
          {open ? "Hide" : "Details"} <IconChevron dir={open ? "up" : "down"} size={10} />
        </button>
      </div>
      {open && (
        <div className="trust-details" role="region" aria-label="Source manifest">
          <div className="trust-details-grid">
            <div>
              <div className="trust-details-label">Snapshot</div>
              <div className="trust-details-val">{t.snapshot_date} · {t.load_timestamp}</div>
            </div>
            <div>
              <div className="trust-details-label">Contract</div>
              <div className="trust-details-val">{t.contract}</div>
            </div>
            <div>
              <div className="trust-details-label">Sources lineaged</div>
              <div className="trust-details-val">{t.sources_loaded.length} of {t.sources_loaded.length + t.sources_missing.length}</div>
            </div>
            <div>
              <div className="trust-details-label">Tolerance</div>
              <div className="trust-details-val">{t.tolerance_pct}% locked</div>
            </div>
          </div>
          <div style={{ marginTop: 14, display: "flex", flexWrap: "wrap", gap: 6 }}>
            {t.sources_loaded.map((s) => <span key={s} className="pill ok">{s}</span>)}
            {t.sources_missing.map((s) => <span key={s} className="pill warn">{s} missing</span>)}
          </div>
        </div>
      )}
    </div>
  );
}

Object.assign(window, {
  IconChevron, IconClose, IconBolt, IconPulse, IconBook, IconSearch,
  Chrome, ContextStrip, Tile, CuriosityRail, TrustRail,
  ENTITIES, entityLabel,
});
