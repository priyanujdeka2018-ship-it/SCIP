# SCIP Insights Engine — ACTION PLAN

Ordered, gated steps to take the engine from "built and shadow-green" to live. Each step is reversible by env flip except the final deletion. Do not skip a gate: a step's live confirmation is the precondition for the next.

## Phase 0 — Land the code (no behaviour change)
1. Copy `engine/*.py` and `engine/*.json` into `go-live-rc1/Backend/` (except the two frontend files). The reference `FINAL_section_mapping.json` / `FINAL_metrics.json` already exist in the repo — **do not overwrite them**; the engine reads the repo copies.
2. Apply the frontend files: `scip_focusscreen_wave_b_patch.jsx` (replace `FocusScreen`, pass the two new props) and append `scip_insight_cards_wave_b.css` to `liquidGlassTokens.css`.
3. Wire the hooks at the end of `build_command_centres()` in order: `attach_shadow_insights(result, payload)` then `attach_placement_shadow(result, payload)`; and add the `SCIP_PLACEMENT_RENDER` dispatch on the `roles =` assignment per `command_centres_v2.py` header.
4. Leave all env flags at defaults. Deploy. Confirm the app behaves exactly as before (shadow attaches under `resolved_insights` / `placement_shadow`; nothing renders differently).
   - **Gate:** app unchanged; `result.resolved_insights.status == "ok"` and `result.placement_shadow.status == "ok"` in the live response.

## Phase 1 — Confirm parity on live data (the real gates)
5. Run, against the live Render payload (not synthetic): `SCIP_USE_REAL_COMMAND_CENTRES=1 python smoke_insight_shadow_parity.py`.
   - **Gate A:** PARITY OK for all roles. Inspect the Wave-B blocked preview — confirm the cards it would block correspond to genuinely unresolved/failed sources (expected while 13/28).
6. Confirm `placement_shadow.violations == []` on live and that per-role order matches the live cards (`placement_order(...)` vs live card order).
   - **Gate B:** zero placement violations; order parity.

## Phase 2 — Cut over Live Pulse (Wave B)
7. Set `SCIP_INSIGHT_CUTOVER=live_pulse`. Verify Live Pulse renders data-state frames; cards on unresolved/failed sources show "Unavailable" + reason, never a number; pacing breach/ok matches the old severity.
   - **Gate:** Live Pulse numbers + lineage unchanged vs Phase 0; blocked cards carry no figure. Rollback = `SCIP_INSIGHT_CUTOVER=shadow`.

## Phase 3 — Cut over placement render (Wave D-2)
8. Set `SCIP_PLACEMENT_RENDER=binder`. Verify role cards are identical to the static render (run the D-2 render-parity check against the real module).
   - **Gate:** role cards byte-identical; no card lost. Rollback = `SCIP_PLACEMENT_RENDER=static`.

## Phase 4 — Enable the editorial model (Wave C)
9. In staging, run the dual-provider shadow set from the LLM Provider Switch Pack; confirm blocked-answer parity and that the token-whitelist rejects injected numbers (re-run `smoke_editorial_wave_c.py` against the chosen provider adapter).
10. Set `SCIP_LLM_PROVIDER` to the real provider. Editorial renders for Narratives chapters on open (lazy); rejections fall back to the deterministic phrase.
    - **Gate:** no editorial surfaces a number absent from its fact set; withheld chapters never call the model. Rollback = `SCIP_LLM_PROVIDER=mock`.

## Phase 5 — Fix the surfaced finding, then delete (irreversible)
11. Fix `M037` `used_in` in `FINAL_metrics.json` — remove `S05_SM4` (or confirm advisory-only, no number re-display). Re-run `python build_d2_migration.py`; confirm `quarantined == []`.
12. Apply `docs/WAVE_D2_DELETIONS.md`: delete `_board_cards`/`_ops_cards`/`_finance_cards`/`_mis_cards`/`_collector_cards`, the severity ternary, the legacy `roles` branch; retire `_role_interpretation` + the `explain_metric` interpretive segment; remove `pickCardsForFocus` + data-bound `getPrimaryCopy`; mark `kpis`/`used_in` deprecated-as-authority.
    - **Gate:** all smokes still green; Live Pulse + Narratives unchanged. Rollback = `git revert` (this is the only non-env-reversible step — do it last).

## Runs in parallel (not blocked by the above)
- Resolve the remaining **15 R-series files** so more cards resolve instead of blocking. Diagnostic order when a number is missing: adapter extraction → sheet layout → filename → source freshness → lineage → metric mapping — before touching deployment.
- Production gates untouched by this work and still required before go-live: JWT/SSO verification, RBAC tests, persistence/audit/observability.

## Definition of done for this engine work
Live Pulse on deterministic frames; Narratives on the constrained-LLM path; placement registry-driven; all static authoring deleted; `quarantined == []`; every smoke green on live; no number ever shown without lineage.
