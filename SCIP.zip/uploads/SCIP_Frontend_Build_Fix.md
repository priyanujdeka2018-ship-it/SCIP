# SCIP Frontend Build Fix

_Source converted from `SCIP Frontend Build Fix.txt` for Claude Project Knowledge._

---

Below is a **gapless continuation handoff** for the next conversation or for resuming UAT from here.

---

# SCIP UAT Continuation Handoff — Current State

Project: **SCIP — Sobha Collections Intelligence Platform**

Current mode:

```text
SCIP Staging Product UAT
Cloudflare Pages frontend
Render backend
Google Drive R-series live-folder bootstrap
Security/SSO/JWT production validation deferred
NOT production-live
```

This must **not** be called production-live. The source-of-truth says production go-live requires real repo merge, builds, migrations, SSO/JWT, source refresh, deployment smoke, role-wise UAT, RBAC, audit, notifications, fallback, rollback, break-glass, and final signoff gates.

---

# Current URLs

```text
Frontend:
https://scip-1jy.pages.dev/

Backend:
https://scip.onrender.com

GitHub branch currently used:
release

Render runtime working directory:
go-live-rc1/Backend

Backend runtime module:
main:app

Current Render start command:
python -u bootstrap_rseries_google_drive_folder.py && uvicorn main:app --host 0.0.0.0 --port $PORT
```

Important: although earlier docs referenced `release/go-live-rc1`, the actual active GitHub branch used during this deployment is:

```text
release
```

Do not switch Cloudflare/Render to `release/go-live-rc1` unless that branch is actually created.

---

# Current Deployment Status

## Backend

Render backend deploy is successful.

Open checks:

```text
https://scip.onrender.com/health
https://scip.onrender.com/manifest
```

Known backend state from Render logs:

```text
Resolved 13/28 R-series files
Data load complete. Status=partial. Sources: 13 ok / 13 missing
GET /forecast/month-end HTTP/1.1 200 OK
OPTIONS /command-centres HTTP/1.1 200 OK
```

Interpretation:

```text
Backend is alive.
Google Drive bootstrap is working.
R-series files are being downloaded.
data_loader is reading from /tmp/scip/r-series.
Source resolution is partial but successful.
Some noncritical R-series are missing and gracefully degraded.
```

## Frontend

Cloudflare Pages frontend now loads and navigation works.

Observed behavior:

```text
Frontend hard refresh can take several minutes on first load.
After waiting, page loaded.
Navigation works.
```

Interpretation:

```text
Deployment is no longer blocked.
Current issue is UAT performance / data warmup, not static frontend failure.
```

Likely reason for slow first load:

```text
Render Free cold start
+ Google Drive folder download
+ Excel parsing
+ multiple startup API calls
```

This should be documented as a UAT performance issue, not a trust failure.

---

# Locked SCIP Rules Still in Force

SCIP must remain a trusted, role-aware, lineage-backed Liquid Glass intelligence platform. The core rules remain:

```text
No frontend business computation.
No silent fallback figures.
Frontend renders only server-provided metrics, labels, assumptions, lineage, and trust state.
Critical metrics require source file, report code, sheet, cell/range or extraction rule, snapshot date, reporting basis, validation status, confidence state, and lineage reference/hash.
Quickball must block/refuse critical answers without lineage.
```

These are locked in the project source-of-truth.

Liquid Glass rules remain locked:

```text
Arrival has only two doors:
- Live Pulse
- Narratives

No third Arrival door.
No dashboard-first home.
No sidebar at Arrival.
No Ops/Board toggle language.
Quickball is quiet/contextual, not a loud chatbot.
Live Pulse has only:
- Current Signal
- Month Movement
- Risk & Action

Narratives follows:
- Story
- Portfolio
- Dues
- Advance
- Roadmap
```

The Liquid Glass, no-third-door, no-dashboard-first, no-sidebar, and evidence-on-request rules are explicit in the source-of-truth.

Role model remains locked:

```text
Keep:
- Board/CXO
- CCO/GM/AGM
- Finance
- MIS/QCG/Admin
- Collector/RM

Remove/block:
- Entity Head
```

---

# Reporting Basis Rules

Keep these visible wherever relevant:

```text
R04 = Finance daily actuals
R02 = MDO targets / MDO actuals where available
R08 = Advance CY/FY/rebate/NPV basis
R18 = OD / overdue / ageing source
R36 = milestone cohort / forward collectible calendar
```

Finance-vs-MDO labels must remain visible wherever mixed.

Minimum source set:

```text
Core number validation:
R02, R04, R08, R18, R36

Action/account queue validation:
R09, R10, R17, R20, R30, R31, R32, R34, R38
```

These are the documented minimum production/go-live source files, and adapters must output lineaged facts, not dashboard-only values.

---

# Current Google Drive R-Series Setup

Live Google Drive folder:

```text
https://drive.google.com/drive/folders/1ptIW0bTH9QJfsvdV0e62_NN6OU0B7cw7?usp=share_link
```

Folder ID:

```text
1ptIW0bTH9QJfsvdV0e62_NN6OU0B7cw7
```

Render env vars for Google Drive source bootstrap:

```text
SCIP_RSERIES_BOOTSTRAP=true
SCIP_GOOGLE_DRIVE_FOLDER_ID=1ptIW0bTH9QJfsvdV0e62_NN6OU0B7cw7
SCIP_SOURCE_ROOT=/tmp/scip/r-series
```

The R-series files are **not** committed to GitHub. That is correct: source workbooks must stay outside the public repo; GitHub should keep only placeholders such as `data/.gitkeep`.

---

# Google Drive Bootstrap Fixes Already Applied

These issues were found and fixed:

## 1. Bootstrap file was in the wrong path

Render was running from:

```text
/opt/render/project/src/go-live-rc1/Backend
```

So this file had to live here:

```text
go-live-rc1/Backend/bootstrap_rseries_google_drive_folder.py
```

not repo root.

## 2. gdown unsupported flag removed

Failure:

```text
gdown: error: unrecognized arguments: --remaining-ok
```

Fixed by replacing:

```python
["gdown", "--folder", folder_ref, "-O", str(download_dir), "--remaining-ok"]
```

with:

```python
["gdown", "--folder", folder_ref, "-O", str(download_dir)]
```

## 3. `data_loader.py` was hardcoded to repo `/data`

Old behavior:

```python
DATA_DIR = (_HERE.parent / "data").resolve()
```

This ignored:

```text
SCIP_SOURCE_ROOT=/tmp/scip/r-series
```

Fixed by patching `go-live-rc1/Backend/data_loader.py` to use:

```python
DEFAULT_DATA_DIR = (_HERE.parent / "data").resolve()
DATA_DIR = Path(
    os.environ.get("SCIP_SOURCE_ROOT")
    or os.environ.get("DATA_DIR")
    or DEFAULT_DATA_DIR
).resolve()
PIPELINE_CONFIG_PATH = (_HERE / "pipeline_config.json").resolve()

logger.info("SCIP data source directory resolved to: %s", DATA_DIR)
```

After this patch, the loader correctly reads Google Drive-downloaded workbooks from:

```text
/tmp/scip/r-series
```

---

# R-Series Filename Requirement

The active `file_resolver.py` matches files by R-code prefix and expects a filename like:

```text
R04_Some_Name.xlsx
R18_Consolidated_Overdue.xlsx
R36_Milestone_Cohort.xlsx
```

Avoid:

```text
R04 Daily Collections.xlsx
Daily Collections R04.xlsx
R18 latest.xlsx
~$R04_Daily_Collections.xlsx
```

Important regex behavior:

```text
R04_Anything.xlsx  ✅
R04.xlsx           ✅
R04 Anything.xlsx  ❌ likely skipped
Anything_R04.xlsx  ❌ skipped
```

Use `.xlsx` where possible. The resolver supports `.xlsx` and `.xlsb`; do not rely on `.xls` for UAT unless the backend is patched.

---

# Current Render / Cloudflare Env Variables

## Render backend

Keep staging values:

```text
SCIP_ENV=staging
SCIP_LOCAL_DEV_BYPASS=true
SCIP_ALLOWED_ORIGINS=https://scip-1jy.pages.dev,https://scip.netlify.app
CORS_ALLOWED_ORIGINS=https://scip-1jy.pages.dev
FRONTEND_URL=https://scip-1jy.pages.dev
SCIP_SOURCE_ROOT=/tmp/scip/r-series
SCIP_RSERIES_BOOTSTRAP=true
SCIP_GOOGLE_DRIVE_FOLDER_ID=1ptIW0bTH9QJfsvdV0e62_NN6OU0B7cw7
```

Auth mode during UAT has been treated as staging/deferred. If browser CORS/header issues recur, check whether `SCIP_AUTH_MODE` plus CORS header logic allows the `X-SCIP-*` staging headers. For production, this must return to real JWT/SSO validation.

## Cloudflare Pages frontend

Use Production env vars:

```text
NODE_VERSION=22
VITE_BACKEND_URL=https://scip.onrender.com
VITE_SCIP_API_BASE_URL=https://scip.onrender.com
VITE_API_BASE_URL=https://scip.onrender.com
VITE_SCIP_LOCAL_DEV_BYPASS=true
```

Cloudflare env vars are build-time for Vite. After changing them:

```text
Cloudflare Pages → Redeploy
```

---

# Important Frontend Patches Already Applied

Several `src/App.jsx` hardening patches were applied during troubleshooting.

Current intended behavior:

```text
Core product endpoints remain blocking:
- /command-centres
- /forecast/month-end
- /action-queues
- /workflows

UAT-only non-blocking or degraded:
- /notifications
- /persistence/summary
- /security/me
- /identity/me
- /deployment/health
- /observability/*
- /audit/export
```

Reason:

```text
For Product UAT, optional operational/governance surfaces should not block Arrival / Live Pulse / Narratives.
For production, these must be restored and validated as go-live gates.
```

Important previous errors fixed:

```text
SCIP unavailable / Load failed
identityJson is not defined
/security/me blocking entire app
/notifications network/CORS: Load failed
/persistence/summary 500 required_demo_record_not_found
```

Current frontend behavior after patches:

```text
Arrival shell loads after backend warmup.
Navigation works.
Diagnostics show endpoint-specific errors when failures occur.
No fake fallback figures are introduced.
```

---

# Current Known UAT-Only Exceptions

Document these as **UAT-only**, not permanent:

```text
/security/me may be unavailable while SSO/JWT is deferred.
/identity/me may be unavailable while SSO/JWT is deferred.
/deployment/health may remain protected.
/observability/* may be unavailable.
/notifications may be unavailable or non-blocking.
/persistence/summary may return required_demo_record_not_found until Batch 10 persistence seed/migration is fixed.
/audit/export may require protected/download flow later.
```

Production must later restore/validate these gates. Durable persistence, RBAC, SSO/JWT, audit export, notifications, and observability are part of the production command sequence and success metrics.

---

# Performance Observation

Current issue:

```text
Initial frontend load can take a few minutes.
```

Cause:

```text
Render Free cold start
+ Google Drive source download
+ Excel workbook parsing
+ frontend waiting for required product endpoints
```

UAT workaround:

```text
1. Open https://scip.onrender.com/health first.
2. Wait until backend responds.
3. Check Render logs for data load complete.
4. Then open https://scip-1jy.pages.dev/.
5. Wait 1–3 minutes on first load if needed.
```

Permanent fixes later:

```text
Backend:
- Add in-memory source payload cache for staging.
- Cache must not break no-silent-fallback, lineage freshness, source snapshot date, or RBAC visibility.

Frontend:
- Show Arrival shell immediately.
- Load command-centres and forecast in background.
- Lazy-load action queues/workflows only when Risk & Action opens.
```

Caching is allowed only where it does not break no-silent-fallback, lineage freshness, snapshot checks, or RBAC visibility.

---

# Immediate Next Step: Continue Product UAT

Because frontend now loads and navigation works, continue with **number validation and product UAT**.

## Step 1 — Warm backend

Open:

```text
https://scip.onrender.com/health
https://scip.onrender.com/manifest
```

Then check Render logs for:

```text
[SCIP bootstrap] Source root ready: /tmp/scip/r-series
SCIP data source directory resolved to: /tmp/scip/r-series
Resolved 13/28 R-series files
Data load complete. Status=partial
```

## Step 2 — Open frontend

Open:

```text
https://scip-1jy.pages.dev/
```

Wait if needed. Do not repeatedly hard-refresh during cold start.

## Step 3 — Validate numbers

Start with:

```text
Live Pulse → Month Movement
```

Check:

```text
MTD actual
May target
Current run-rate
Required run-rate
Projected landing
Projected achievement
Finance/MDO basis labels
Forecast assumptions
Evidence / lineage drawer
```

Forecast must be server-side and disclose R04/R02 basis, working days, current run-rate, required run-rate, and assumptions.

Then test:

```text
Narratives → Dues
Narratives → Advance
Risk & Action
Evidence / lineage drawer
Quickball explanation
```

## Step 4 — If numbers remain unavailable

If the UI loads but values still show `Unavailable`, the issue is now likely **adapter extraction**, not deployment.

Likely causes:

```text
Workbook found but layout differs from adapter expectation.
Sheet name differs.
Required subtotal labels differ.
Data is in another tab.
File is .xls/.xlsb when adapter expects .xlsx/openpyxl.
Filename is correct but wrong report version was uploaded.
R-code source exists but metric-specific cell/range extraction failed.
Lineage exists but metric value is null.
```

Next diagnostic in that case:

```text
Open evidence drawer for the unavailable card.
Check whether lineage exists.
If lineage missing: adapter did not produce metric lineage.
If lineage exists but value unavailable: extraction/calculation mapping failed.
```

## Step 5 — Validate locked product rules

Check:

```text
Arrival has only Live Pulse and Narratives.
No third Arrival door.
No dashboard-first clutter.
No sidebar at Arrival.
No Ops/Board toggle language.
Quickball is quiet and contextual.
No Entity Head role appears.
```

These are non-negotiable Liquid Glass / role-model rules.

---

# Product UAT Checklist

Use this as the next working checklist.

## Arrival

```text
[ ] Frontend opens at https://scip-1jy.pages.dev/
[ ] Arrival has only Live Pulse and Narratives.
[ ] No third Arrival door.
[ ] No dashboard-first KPI grid.
[ ] No sidebar at Arrival.
[ ] No raw section tree at Arrival.
[ ] No Ops/Board toggle language.
[ ] Quickball appears only as quiet command capsule.
```

## Live Pulse

```text
[ ] Current Signal opens.
[ ] Month Movement opens.
[ ] Risk & Action opens.
[ ] Month Movement shows forecast panel.
[ ] Forecast values are populated or clearly unavailable with no fallback.
[ ] R04 Finance and R02 MDO labels visible.
[ ] Forecast assumptions visible.
[ ] Evidence drawer opens.
[ ] No frontend-computed figures appear.
```

## Narratives

```text
[ ] Story opens.
[ ] Portfolio opens.
[ ] Dues opens.
[ ] Advance opens.
[ ] Roadmap opens.
[ ] Narrative flow feels like guided briefing, not dashboard menu.
[ ] Evidence appears only on request.
[ ] Solid surfaces used for financial truth.
[ ] Glass used for movement/context/reveal.
```

## Roles

```text
[ ] Board/CXO visible.
[ ] CCO/GM/AGM visible.
[ ] Finance visible.
[ ] MIS/QCG/Admin visible.
[ ] Collector/RM visible.
[ ] Entity Head absent.
```

## Actions / Workflows

```text
[ ] Risk & Action loads.
[ ] Action queues show only lineaged/gated actions.
[ ] Collector/account detail does not leak to Board/CXO.
[ ] Workflow drawer opens if action is accessible.
[ ] No unlineaged account action is trusted.
```

## Quickball

```text
[ ] Ask about a number.
[ ] Quickball explains source basis/formula/lineage.
[ ] Quickball blocks if lineage unavailable.
[ ] Quickball does not hallucinate or invent.
```

---

# Defect Logging Format

Use this for every issue:

```text
Area:
Role:
Path:
Expected:
Actual:
Source file/R-code involved:
Lineage present? yes/no:
Screenshot/error:
Severity:
UAT-only acceptable? yes/no:
Production blocker? yes/no:
```

---

# Important Production Blockers Still Open

Do not solve these during Product UAT unless they block product flow:

```text
Real SSO/JWT issuer/audience/JWKS/claims not configured.
Production use of local-dev bypass must be removed.
RBAC row-level tests pending.
Batch 10 persistence migration/seed pending.
persistence/summary required_demo_record_not_found still needs real backend fix.
Notification dedupe must be validated.
Audit export must be validated.
Observability correlation IDs must be validated.
Latest source refresh/smoke tests must pass.
Role-wise UAT signoff pending.
Rollback and break-glass owners pending.
```

The go-live sequence requires migrations, source refresh, smoke tests, identity/RBAC/audit/notification/observability verification, role-wise UAT, rollback/break-glass, and final production signoff.

---

# Continuation Prompt for New Conversation

Use this exact prompt to continue:

```text
Use this handoff as the current SCIP source of truth.

Current state:
- SCIP is staging Product UAT only, not production-live.
- Frontend is Cloudflare Pages: https://scip-1jy.pages.dev/
- Backend is Render: https://scip.onrender.com
- GitHub branch in use is release.
- Render backend runs from go-live-rc1/Backend using:
  python -u bootstrap_rseries_google_drive_folder.py && uvicorn main:app --host 0.0.0.0 --port $PORT
- Google Drive R-series folder bootstrap is working.
- Drive folder ID is 1ptIW0bTH9QJfsvdV0e62_NN6OU0B7cw7.
- SCIP_SOURCE_ROOT is /tmp/scip/r-series.
- data_loader.py has been patched to read SCIP_SOURCE_ROOT.
- Render logs showed Resolved 13/28 R-series files and data load complete with status partial.
- Frontend loads and navigation works after waiting through cold start.
- Current next task is Product UAT and number validation.
- Do not reopen SSO/JWT/JWKS unless product routes are blocked.
- Do not call SCIP production-live.
- Preserve no-silent-fallback, no frontend computation, and lineage trust rules.
- Optional UAT surfaces like notifications, persistence summary, identity/security/deployment/observability may be non-blocking, but production must restore them.

Help continue UAT from Live Pulse → Month Movement number validation, then Narratives, Risk & Action, Evidence/Lineage, role lenses, Quickball, and defect logging. If numbers are unavailable, diagnose adapter extraction/sheet/layout/lineage issues rather than deployment.
```
