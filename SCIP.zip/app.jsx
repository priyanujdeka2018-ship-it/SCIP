/* SCIP — main App shell
 * Wires arrival → live pulse / narratives, role switch, drawers, quickball, tweaks
 */
/* eslint-disable react/prop-types */

const SCIP_TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "navy",
  "accent": "gold",
  "forecastLayout": "default",
  "autoLineage": false,
  "defaultRole": "cco_gm_agm"
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweak] = useTweaks(SCIP_TWEAK_DEFAULTS);

  const [route, setRoute] = useState("arrival");
  const [role, setRole] = useState(tweaks.defaultRole || "cco_gm_agm");
  const [focus, setFocus] = useState("current_signal");
  const [entity, setEntity] = useState("group");
  const [present, setPresent] = useState(false);
  const [lineage, setLineage] = useState({ open: false, key: null, title: "" });
  const [workflow, setWorkflow] = useState({ open: false, action: null });

  // Apply accent + theme to root
  const accentClass = `accent-${tweaks.accent || "gold"}`;
  const themeClass = `theme-${tweaks.theme || "navy"}`;

  // Mirror theme + accent classes on <body> so the page background swaps too.
  useEffect(() => {
    document.body.className = `${themeClass} ${accentClass}`;
    return () => { document.body.className = ""; };
  }, [themeClass, accentClass]);

  const openLineage = useCallback((key, title) => setLineage({ open: true, key, title }), []);
  const closeLineage = useCallback(() => setLineage({ open: false, key: null, title: "" }), []);
  const openWorkflow = useCallback((action) => setWorkflow({ open: true, action }), []);
  const closeWorkflow = useCallback(() => setWorkflow({ open: false, action: null }), []);

  const enterWorld = useCallback((next) => {
    setRoute(next);
    setFocus(next === "narratives" ? "story" : "current_signal");
  }, []);

  // ⌘K to open quickball is handled inside Quickball.
  // Esc to step back from a world.
  useEffect(() => {
    function onKey(e) {
      if (e.key === "Escape" && route !== "arrival" && !lineage.open && !workflow.open) {
        // small escape: go back to arrival
      }
    }
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [route, lineage.open, workflow.open]);

  // Trigger Quickball from screens via custom event.
  const askQuickball = useCallback((q) => {
    window.dispatchEvent(new CustomEvent("scip:quickball:ask", { detail: q }));
  }, []);

  // Navigation bus — Quickball (and future surfaces) dispatch nav intents here.
  useEffect(() => {
    function onNav(e) {
      const d = e.detail || {};
      if (d.present) { setPresent(true); return; }
      if (d.entity) setEntity(d.entity);
      if (d.route) {
        setRoute(d.route);
        if (d.focus) setFocus(d.focus);
        else setFocus(d.route === "narratives" ? "story" : "current_signal");
      } else if (d.focus) {
        setFocus(d.focus);
      }
    }
    window.addEventListener("scip:nav", onNav);
    return () => window.removeEventListener("scip:nav", onNav);
  }, []);

  // route specific screen markers for the comment system
  const screenLabel = useMemo(() => {
    if (route === "arrival") return "01 Arrival";
    if (route === "live_pulse") {
      const map = { current_signal: "02 Live Pulse · Current Signal", month_movement: "03 Live Pulse · Month Movement", risk_action: "04 Live Pulse · Risk & Action" };
      return map[focus] || "02 Live Pulse";
    }
    const map = { story: "05 Narratives · Story", portfolio: "06 Narratives · Portfolio", dues: "07 Narratives · Dues", advance: "08 Narratives · Advance", roadmap: "09 Narratives · Roadmap" };
    return map[focus] || "05 Narratives";
  }, [route, focus]);

  return (
    <div className={`scip-root ${themeClass} ${accentClass}`} data-screen-label={screenLabel}>
      {route === "arrival" ? (
        <Arrival onEnter={enterWorld} dataDate={window.SCIP.TRUST.snapshot_date} />
      ) : (
        <main className="page">
          <Chrome route={route} setRoute={(r) => { if (r === "arrival") setRoute("arrival"); else enterWorld(r); }} role={role} setRole={setRole} entity={entity} setEntity={setEntity} dataDate={window.SCIP.TRUST.snapshot_date} />
          <ContextStrip route={route} focus={focus} role={role} entity={entity} setEntity={setEntity} />

          {/* World home */}
          {route === "live_pulse"
            ? <LivePulseHome focus={focus} setFocus={setFocus} role={role} />
            : <NarrativesHome focus={focus} setFocus={setFocus} onPresent={() => setPresent(true)} />
          }

          {/* Focus screen */}
          <FocusScreen
            route={route}
            focus={focus}
            role={role}
            entity={entity}
            onOpenLineage={openLineage}
            onAskQuickball={askQuickball}
            setFocus={setFocus}
            forecastLayout={tweaks.forecastLayout}
            autoLineage={tweaks.autoLineage}
          />

          {/* Runway panel only on Month Movement */}
          {route === "live_pulse" && focus === "month_movement" && (
            <RunwayPanel onOpenLineage={openLineage} layout={tweaks.forecastLayout || "default"} />
          )}

          {/* Lineaged command tiles */}
          {route === "live_pulse" && (
            <section aria-label="Lineaged command tiles" style={{ marginTop: 4 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 14 }}>
                <div>
                  <span className="eyebrow">Lineaged tiles · {window.SCIP.ROLES[role].label}</span>
                  <h3 className="display h3" style={{ marginTop: 6 }}>The four numbers that earn their place.</h3>
                </div>
                <span className="chip">Tap a tile for evidence</span>
              </div>
              <div className="tiles">
                {(window.SCIP.TILES[role] || []).map((tile) => (
                  <Tile key={tile.id} tile={tile} onOpenLineage={openLineage} autoLineage={tweaks.autoLineage} />
                ))}
              </div>
            </section>
          )}

          {/* Action queues only on Risk & Action and in narratives Roadmap */}
          {((route === "live_pulse" && focus === "risk_action") || (route === "narratives" && focus === "roadmap")) && (
            <ActionQueues role={role} onOpenLineage={openLineage} onOpenWorkflow={openWorkflow} />
          )}

          <TrustRail />
        </main>
      )}

      <LineageDrawer
        open={lineage.open}
        lineageKey={lineage.key}
        title={lineage.title}
        onClose={closeLineage}
      />
      <WorkflowDrawer
        open={workflow.open}
        action={workflow.action}
        onClose={closeWorkflow}
        onOpenLineage={openLineage}
      />
      <PresentMode open={present} onClose={() => setPresent(false)} />
      {/* persistent quickball when not on arrival (arrival has its own) */}
      {route !== "arrival" && <Quickball visible={true} />}

      {/* Tweaks panel */}
      <TweaksPanel title="Tweaks · SCIP">
        <TweakSection label="Theme">
          <TweakRow label="Base">
            <div className="twk-chips" role="radiogroup" aria-label="Theme">
              {[
                { value: "navy",       color: "#0a1020", outer: "#c9a55b" },
                { value: "midnight",   color: "#04060d", outer: "#5fb3a8" },
                { value: "mahogany",   color: "#1a0e0c", outer: "#c8705e" },
                { value: "porcelain",  color: "#efe8d8", outer: "#7a623c" },
              ].map((s) => {
                const on = tweaks.theme === s.value;
                return (
                  <button
                    key={s.value}
                    type="button"
                    role="radio"
                    aria-checked={on}
                    data-on={on ? "1" : "0"}
                    className="twk-chip"
                    aria-label={s.value}
                    title={s.value}
                    style={{ background: s.color, boxShadow: on ? `0 0 0 2px ${s.outer}` : `inset 0 0 0 1px ${s.outer}66` }}
                    onClick={() => setTweak("theme", s.value)}
                  />
                );
              })}
            </div>
          </TweakRow>
        </TweakSection>
        <TweakSection label="Audience lens">
          <TweakSelect
            label="Default role"
            value={tweaks.defaultRole}
            onChange={(v) => { setTweak("defaultRole", v); setRole(v); }}
            options={window.SCIP.ROLE_KEYS.map((k) => ({ value: k, label: window.SCIP.ROLES[k].label }))}
          />
        </TweakSection>
        <TweakSection label="Accent palette">
          <TweakRow label="Accent">
            <div className="twk-chips" role="radiogroup" aria-label="Accent palette">
              {[
                { value: "gold",  color: "#c9a55b" },
                { value: "pearl", color: "#e7dcc4" },
                { value: "steel", color: "#7ba6c7" },
                { value: "teal",  color: "#5fb3a8" },
              ].map((s) => {
                const on = tweaks.accent === s.value;
                return (
                  <button
                    key={s.value}
                    type="button"
                    role="radio"
                    aria-checked={on}
                    data-on={on ? "1" : "0"}
                    className="twk-chip"
                    aria-label={s.value}
                    title={s.value}
                    style={{ background: s.color }}
                    onClick={() => setTweak("accent", s.value)}
                  />
                );
              })}
            </div>
          </TweakRow>
        </TweakSection>
        <TweakSection label="Forecast layout">
          <TweakRadio
            label="Runway"
            value={tweaks.forecastLayout}
            onChange={(v) => setTweak("forecastLayout", v)}
            options={[
              { value: "default", label: "Default" },
              { value: "split",   label: "Split" },
              { value: "stacked", label: "Tall" },
            ]}
          />
        </TweakSection>
        <TweakSection label="Lineage behaviour">
          <TweakToggle
            label="Auto-show lineage on tile tap"
            value={tweaks.autoLineage}
            onChange={(v) => setTweak("autoLineage", v)}
            description="When off, tile tap opens evidence drawer. When on, the drawer opens immediately on hover for 0.4s and dismisses on outside click."
          />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
