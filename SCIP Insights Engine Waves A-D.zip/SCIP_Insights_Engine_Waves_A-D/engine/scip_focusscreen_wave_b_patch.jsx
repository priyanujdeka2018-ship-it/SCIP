/* ============================================================================
 * SCIP Wave B - FocusScreen frontend patch (Live Pulse deterministic frames)
 * ----------------------------------------------------------------------------
 * Surgical, reversible. Live Pulse focus screens render the backend's resolved
 * insights instead of frontend-selected static cards. Narratives is unchanged
 * (still static until Wave C). If no live insights are present (cutover off, or
 * rollback), it falls back to the existing pickCardsForFocus static path.
 *
 * This removes the frontend keyword-scoring selection (pickCardsForFocus) for
 * Live Pulse only - placement now comes from the backend surface_placement,
 * which is a step toward the Wave D Placement Binder. No business number is
 * computed on the client: the frontend renders backend-provided value_display,
 * headline, severity, lineage, and trust state only.
 *
 * LOCKED-RULE COMPLIANCE
 *   - Glass = movement/context  -> the framed headline sits on a glass surface.
 *   - Solid = financial truth    -> the governed number renders on a solid card.
 *   - Blocked state shows the frame + "Unavailable", never a number.
 *   - Reuses existing classes (glass-surface, solid-evidence-card, curiosity-
 *     chip, kicker, severity-pill). Introduces NO new aesthetic.
 *
 * INTEGRATION (3 small edits in App.jsx)
 *   1. Where AppShell renders FocusScreen, pass two props:
 *        <FocusScreen
 *          route={route} focus={focus} role={role} roleLabel={roleLabel}
 *          cards={cards}
 *          resolvedInsights={payload?.resolved_insights}   // <-- add
 *          forecast={forecast || payload?.forecast}
 *          onOpenLineage={openLineage}
 *          onExplain={(metric) => askQuickball(metric, role)}
 *          setFocus={setFocus} />
 *   2. Replace the existing FocusScreen function with the one below.
 *   3. Keep pickCardsForFocus and getPrimaryCopy in the file - they remain the
 *      fallback path (and the rollback target). Do NOT delete them in Wave B.
 *
 * ROLLBACK
 *   Set SCIP_INSIGHT_CUTOVER=shadow on the backend (no live insights are flagged
 *   render_mode="live", so this component falls back to the static path), or
 *   revert this function to the original. No data migration involved.
 * ========================================================================== */

function liveInsightsForFocus(resolvedInsights, role, route, focus) {
  if (route !== "live_pulse" || !resolvedInsights || !resolvedInsights.roles) return [];
  const all = resolvedInsights.roles[role] || [];
  return all.filter(
    (i) => i.render_mode === "live" && i.surface_placement && i.surface_placement.focus === focus
  );
}

function SeverityPill({ severity }) {
  // maps to existing token classes; "blocked" reuses the risk/trust styling
  const cls =
    severity === "risk" || severity === "blocked"
      ? "severity-pill severity-risk"
      : severity === "strategic"
      ? "severity-pill severity-strategic"
      : "severity-pill severity-monitor";
  const label = severity === "blocked" ? "unavailable" : severity;
  return <span className={cls}>{label}</span>;
}

function LiveInsightCard({ insight, onOpenLineage, onExplain }) {
  const blocked = insight.status === "blocked_untrusted_metric";
  const metricKey =
    (insight.lineage_refs && insight.lineage_refs[0] && insight.lineage_refs[0].metric_key) || null;
  return (
    <article className="insight-card glass-surface" aria-label={insight.title}>
      <div className="insight-head">
        <span className="kicker">{insight.reporting_basis}</span>
        <SeverityPill severity={insight.severity} />
      </div>

      {/* Framed headline = context (glass). A pure function of current data state. */}
      <p className="insight-headline">{insight.headline}</p>

      {/* Financial truth = solid surface. Blocked => no number, just the trust state. */}
      {blocked ? (
        <div className="solid-evidence-card insight-blocked" role="status">
          <span className="insight-value insight-value-unavailable">Unavailable</span>
          <span className="insight-blocked-reason">{insight.blocked_reason}</span>
        </div>
      ) : (
        <div className="solid-evidence-card">
          <span className="insight-value">{insight.value_display}</span>
        </div>
      )}

      <div className="curiosity-row" aria-label="Curiosity paths">
        <button
          className="curiosity-chip"
          onClick={() => onOpenLineage(insight.lineage_refs || [], insight.title)}
        >
          Show evidence
        </button>
        {metricKey && !blocked && (
          <button className="curiosity-chip" onClick={() => onExplain(metricKey)}>
            Ask about this number
          </button>
        )}
      </div>
    </article>
  );
}

function FocusScreen({
  route,
  focus,
  role,
  roleLabel,
  cards,
  resolvedInsights,
  forecast,
  onOpenLineage,
  onExplain,
  setFocus,
}) {
  const live = liveInsightsForFocus(resolvedInsights, role, route, focus);

  // ---- Live Pulse, cut over (Wave B): render backend resolved insights ----
  if (live.length > 0) {
    const question =
      (LIVE_PULSE_CHOICES.find((item) => item.key === focus)?.question) || "Are we okay today?";
    return (
      <section className="focus-screen glass-surface" aria-label="Focus screen">
        <p className="screen-question">{question}</p>
        <div className="insight-grid">
          {live.map((insight) => (
            <LiveInsightCard
              key={insight.card_id}
              insight={insight}
              onOpenLineage={onOpenLineage}
              onExplain={onExplain}
            />
          ))}
        </div>
        {route === "live_pulse" && focus === "month_movement" && (
          <div className="curiosity-row">
            <button className="curiosity-chip" onClick={() => setFocus("target_track")}>
              Open Target Track/YTD lens
            </button>
          </div>
        )}
      </section>
    );
  }

  // ---- Fallback: original static path (Narratives, or cutover off / rollback) ----
  const selectedCards = pickCardsForFocus(cards, route, focus);
  const copy = getPrimaryCopy(route, focus, roleLabel);
  const primaryCard = selectedCards[0];
  const question =
    route === "narratives"
      ? NARRATIVE_STEPS.find((item) => item.key === focus)?.question || "What is the board-level story?"
      : LIVE_PULSE_CHOICES.find((item) => item.key === focus)?.question || "Are we okay today?";

  return (
    <section className="focus-screen glass-surface" aria-label="Focus screen">
      <div className="focus-layout">
        <div>
          <p className="screen-question">{question}</p>
          <h2 className="primary-answer">{copy.answer}</h2>
          <p className="answer-copy">
            {copy.copy} {copy.roleHint}
          </p>
          <div className="curiosity-row" aria-label="Curiosity paths">
            <button
              className="curiosity-chip"
              onClick={() =>
                onOpenLineage(
                  primaryCard?.lineage_display || primaryCard?.lineage_refs || [],
                  primaryCard?.title || "Evidence"
                )
              }
            >
              Show evidence
            </button>
            <button
              className="curiosity-chip"
              onClick={() =>
                onExplain(
                  primaryCard?.lineage_refs?.[0]?.metric_key ||
                    primaryCard?.lineage_display?.[0]?.metric_key ||
                    "OD_TODAY"
                )
              }
            >
              Ask about this number
            </button>
            {route === "live_pulse" && focus === "month_movement" ? (
              <button className="curiosity-chip" onClick={() => setFocus("target_track")}>
                Open Target Track/YTD lens
              </button>
            ) : (
              <button
                className="curiosity-chip"
                onClick={() => setFocus(route === "narratives" ? "portfolio" : "risk_action")}
              >
                Next
              </button>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
