# SCIP Insights Engine — HANDOFF

Read this first if you are continuing this work in a new conversation.

## What this is
SCIP renders board-grade collections insights. Historically the insight *language* and *placement* were authored three ways — static card strings in `command_centres.py`, role-note branches and an `explain_metric` template in `quickball.py`, hardcoded `kpis`/`used_in` placement in `FINAL_section_mapping.json`/`FINAL_metrics.json`, and "grew 22×"-style derived strings baked into narratives. These go stale the moment the underlying numbers move. This programme replaces that with a single engine where every headline and editorial phrase is generated live from governed, lineage-bound values, placed automatically by role and surface, and degrades to *blocked/unavailable* rather than ever inventing a number.

The full design is in `SCIP_Insights_Engine_Surgical_Replacement_Plan.md` (8 sections). It was built in 5 reversible waves (A, B, C, D-1, D-2), each shadow-first.

## Current state (as of this handoff)
- SCIP is in **Product UAT**, not production. Frontend `scip-1jy.pages.dev` (Cloudflare Pages, `release`, root `go-live-rc1/`), backend `scip.onrender.com` (Render, working dir `go-live-rc1/Backend`). Google Drive R-series bootstrap working; `SCIP_SOURCE_ROOT=/tmp/scip/r-series`.
- **13 of 28 R-series files resolve** (`status: partial`). This is the live number-validation blocker and is *separate from* this engine work — the engine is designed so unresolved sources render blocked, not wrong.
- The engine (Waves A–D-2) is **built and passing all local smokes**, but **nothing is live**: every cutover is behind an env flag that defaults OFF, and the one irreversible step (deleting the static builders) has not been applied.

## What each wave delivered (all local-green)
- **A** — Insight registry + compiler in *shadow*; reproduces the 15 command-centre cards byte-for-byte (value, display, basis, severity, lineage, order). Non-destructive.
- **B** — Live Pulse criticals (Current Signal, Month Movement, Risk & Action) on deterministic data-state frames; degrade to *blocked* (no number) when the lineage gate fails; the `"risk" if ach<50` ternary replaced by a `threshold_cross` predicate. Env: `SCIP_INSIGHT_CUTOVER` (default `shadow`).
- **C** — Narratives editorial on a constrained-LLM path behind the provider gate, with a **post-LLM token-whitelist validator** that discards any model output containing a number not in the verified fact set (the "grew 22×" guarantee). Withheld chapters never call the model. Env: `SCIP_LLM_PROVIDER` (default `mock`).
- **D-1** — Placement Binder + enforcement of the kept `FINAL_section_mapping.json` rules (R1 no third door, R2 submodule exists, R3 containment e.g. CIV→S01 not S04, R4 single-source constants, R5 no duplicate slot); *shadow*. Env: `SCIP_PLACEMENT_SHADOW` (default on).
- **D-2** — Crosswalk (metric_key↔M-code, fabrication-guarded), migration of all `kpis`/`used_in` into registry-shaped `section_placement.json` (121 entries, 0 dropped), and binder-as-render-source cutover. Env: `SCIP_PLACEMENT_RENDER` (default `static`). Plus a gated deletion manifest.

## Locked rules that constrain ALL future work (do not drift)
- No frontend business computation; no silent fallback figures. Frontend renders only server-provided metrics/labels/lineage/trust state.
- Critical metrics require full lineage (source file, report code, sheet, cell/range, snapshot date, reporting basis, validation status, confidence state, lineage hash). Quickball blocks critical answers without lineage.
- Numbers originate only from governed values; **language never originates a number**. Critical surfaces use the deterministic path; the LLM editorial path is optional, Narratives-only, and structurally incapable of introducing a figure.
- Liquid Glass two-door Arrival (Live Pulse, Narratives) — no third door, no dashboard-first home, no sidebar at Arrival. Glass = movement/context; solid = financial truth/evidence.
- Role model: Board/CXO, CCO/GM/AGM, Finance, MIS/QCG/Admin, Collector/RM. Entity Head removed.
- Reporting basis labels (R04 Finance, R02 MDO, R08 Advance, R18 OD, R36 Milestone) visible wherever mixed.
- Production must use verified JWT/SSO; no trusted X-SCIP headers in prod. (Not reopened by this work; remains a production gate.)

## The one real finding to action
The D-2 migration surfaced and quarantined a single stale binding: **`M037` (npv_rebate_rate_pct) is bound to `S05_SM4` in `FINAL_metrics.json` `used_in`**, which `boundary_rules` forbid ("NPV lives in S01, not S05 — no re-display of numbers"). It is flagged `rejected_boundary` in `section_placement.json`. Fix M037's `used_in` (remove `S05_SM4`, or confirm advisory-only with no number) before retiring the `used_in` field.

## Env flags and safe default state
| Flag | Default | Flip to | Effect when flipped |
|---|---|---|---|
| `SCIP_INSIGHT_SHADOW` | on | off | disable Wave A–C shadow attach |
| `SCIP_INSIGHT_CUTOVER` | `shadow` | `live_pulse` | Live Pulse renders frames + blocked degrade (Wave B) |
| `SCIP_LLM_PROVIDER` | `mock` | real provider | constrained editorial uses a real model (Wave C) |
| `SCIP_PLACEMENT_SHADOW` | on | off | disable Wave D-1 binder shadow attach |
| `SCIP_PLACEMENT_RENDER` | `static` | `binder` | binder becomes render source for role cards (Wave D-2) |

All default-OFF: dropping the files into the repo changes nothing until flipped.

## How to verify locally
`cd engine && bash run_all_smokes.sh` → regenerates the D-2 artifacts and runs all five wave smokes (expect "ALL WAVE SMOKES PASS"). Python 3.10+, no third-party deps.

Note: local green is against synthetic fixtures and a transcribed copy of the static builders. The authoritative checks run on the live Render payload (see ACTION_PLAN.md).

## Files (see PACKAGE_MANIFEST.md for the full map)
- `engine/` — flat, runnable: backend modules, frontend patch + CSS, smokes, the two generated artifacts, reference copies of `FINAL_section_mapping.json`/`FINAL_metrics.json` (repo versions are canonical — do not overwrite the repo with these).
- `docs/` — per-wave READMEs + the D-2 deletion manifest.
- `archive/` — Wave A registry/compiler kept for rollback reference.

## How a new conversation should continue
This work is **design-complete and gated**; the remaining work is operational rollout, not authoring. Start from ACTION_PLAN.md. Default to the Product-UAT/number-validation track as the parent context: the engine is ready, and what gates going live is (a) the live shadow-parity confirmations, (b) resolving the remaining 15 R-series files so more cards resolve instead of blocking, and (c) the ordered env flips + gated deletion. Do not reopen SSO/JWT unless product routes are blocked. Do not introduce new product scope. Keep the shadow-first, prove-on-live-then-cut discipline.
