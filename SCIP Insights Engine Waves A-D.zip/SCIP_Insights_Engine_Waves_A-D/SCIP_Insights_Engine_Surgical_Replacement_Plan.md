# SCIP Insights Engine — Surgical Replacement Plan

**Status:** Planning artifact (no code changes in this pass)
**Scope:** Replace the static-verbiage + hardcoded-placement insight layer with a live, lineage-bound insights engine built on the Batch 18 substrate.
**Locked-rule posture:** Every section below is subordinate to the locked SCIP rules. Where any suggestion here would conflict with a locked rule, the locked rule wins and the suggestion is wrong.

Substrate confirmed from the build before planning:
- **Static authoring lives in three places**, exactly as the problem statement says — `command_centres.py` card factory + role card lists; `quickball.py` `_role_interpretation()` and the `explain_metric()` f-string; inline threshold tags (`"risk" if ach < 50`). A fourth site exists that the original prompt did not name: the **frontend** `getPrimaryCopy()` / `focusCopy` editorial object and `pickCardsForFocus()` keyword scoring in `App.jsx`.
- **Placement bindings** live in `FINAL_section_mapping.json` (`submodules[].kpis`, `boundary_rules`, `cross_section_feeds`) and in the hardcoded per-role card lists.
- **The dynamic substrate already exists**: `AnalyticsTransformationEngine` (profiler → `SemanticFactBuilder` → `MetricCompiler` → `MetricLinker` → `MetricSuggestionEngine` → `ChartSpecFactory` → `AnalyticsValidationEngine`) returns an `EngineRunResult` of lineaged `FactRecord`s, governed `MetricValue`s, links, candidates, chart specs, and validations. The new engine **consumes** this; it never re-parses workbooks.

---

## SECTION 1 — TEARDOWN INVENTORY

Each row: site → what it emits → classification → replacement. Classifications: **REMOVE**, **REPLACE_WITH_DYNAMIC** (RWD), **KEEP_AS_FALLBACK_FRAME** (KFF).

### 1A — `command_centres.py` (backend, role command centres)

| Site | Currently emits | Class | Replaced by |
|---|---|---|---|
| `_card()` factory — `title` arg | Hardcoded card title string ("Current OD exposure", "MTD total collections", "2026 advance mix", "Forward collectible calendar", "Sobha OD", "UAQ OD", "MTD new-sales collections", "OD follow-up pool", etc.) | RWD | Insight spec `headline_frame` selected by data state, numbers bound from governed `MetricValue` |
| `_card()` factory — interpretation/action arg | Hardcoded editorial note ("Review Sobha/UAQ split before executive action review.", "Compare with May MDO target only with basis label visible.", "Use as the 2026-onwards active forward collectible base.", "Break into Sobha Dubai and Sobha AUH recovery actions.", etc.) | RWD | Insight spec `editorial_frame` (deterministic) keyed to predicate outcome |
| `_board_cards()` / `_ops_cards()` / `_finance_cards()` / `_mis_cards()` / `_collector_cards()` — the card **lists** | Hardcoded per-role ordered set of cards (placement + which metric goes where) | RWD | Placement Binder resolves cards from the registry by `role_visibility` + `surface_binding` + `priority` |
| `_ops_cards()` severity — `"risk" if ach is not None and ach < 50 else "monitor"` | Inline threshold tag | RWD | Predicate `threshold_cross` in the registry spec; severity becomes a compiled output |
| `build_command_centres()` — `roles[*].purpose` strings | Hardcoded role purpose copy ("Decision clarity, source trust…", "Daily operating review…") | KFF | Static role descriptor (not data-bound, no number) — moved to a role-descriptor constant, kept as a frame |
| `guardrails` dict (`no_silent_fallback`, `critical_cards_require_lineage_refs`, `finance_vs_mdo_label_required`, `entity_head_removed`) | Guardrail flags | KEEP (unchanged) | Carried through unchanged onto resolved payload |
| `_metric_ref()` / `lineage_display` / `trust_state` assembly | Lineage block builder | KEEP / generalize | Becomes the shared `lineage_contract` attach step in the compiler |

### 1B — `quickball.py` (backend, explain-this-number + role notes)

| Site | Currently emits | Class | Replaced by |
|---|---|---|---|
| `_role_interpretation()` — role × `source_code` branches | Hardcoded editorial per (role, R-code): "Board view: treat this as the current cash-risk exposure…", "Collector/RM view: use the OD exposure to prioritise overdue follow-up…", and the generic fallback line | RWD | Deterministic role-frame table in the registry keyed by (role, basis, predicate); editorial chapters route to constrained-LLM |
| `explain_metric()` — the answer f-string | Template: `"{label} is {value}. Reporting basis: {basis}. Source: {file}/sheet/cell. Validation: {status}; confidence: {state}. Definition: {def} {role_note}"` | RWD (frame) / KEEP (lineage spine) | Deterministic frame for the trust spine (basis/source/validation/confidence stay verbatim from lineage); the *interpretive* sentence becomes a frame/LLM phrase |
| `_answer_blocked()` — blocked f-string | "I cannot explain {label} because the trusted lineage gate failed. Reason: {reason}…" | KFF | This **is** the degrade-to-blocked frame — kept and generalized as the canonical unavailable state for every dynamic insight |
| `METRIC_CATALOG` (`MetricSpec` map) + `ALIASES` | Metric → lineage bucket/key/basis mapping; NL aliases | KEEP | Used by the compiler to resolve `metric_key`; not verbiage |
| `ROLE_MODES` (5 roles, focus arrays) | Role model + focus keyword arrays | KEEP | Feeds role visibility + predicate vocabulary |
| `sample_answers` static metric/role list | Demo seed | REMOVE (from prod path) | Replaced by registry-driven candidates; demo seed retained only for smoke |

### 1C — `FINAL_section_mapping.json` (placement / used_in bindings)

| Site | Currently emits | Class | Replaced by |
|---|---|---|---|
| `submodules[].kpis` (M-code → submodule) e.g. `S01_SM1.kpis = [M010, M011, M009, M058]` | Hand-authored binding of metric to submodule/slot | RWD | Registry `surface_binding` (route/focus/submodule/slot) resolved by Placement Binder |
| `submodules[].charts` (chart IDs per submodule) | Hand-authored chart placement | RWD (where data-driven) / KEEP (where structural) | `ChartSpecFactory` output bound by registry surface |
| `boundary_rules[]` | Containment statements ("Nationality & CIV lives in S01, not S04", "NPV KPIs live in S01, advisory-only in S05") | KEEP (enforced) | Binder enforces these as hard placement constraints; nothing removed |
| `cross_section_feeds[]` | Single-constant reuse rules (`OD_TODAY` single global, `CY_ADV_MIX_YTD` computed once referenced 3×) | KEEP (enforced) | Binder enforces single-source reuse; no duplication |
| `global_component_rules` (`od_today` "never hardcode", deprecated etog IDs) | Anti-hardcode rules | KEEP | Reinforced — registry can never emit a hardcoded `OD_TODAY` |

### 1D — Frontend `App.jsx` (static editorial + placement logic) — *not in the original prompt, but it is a real verbiage/placement site*

| Site | Currently emits | Class | Replaced by |
|---|---|---|---|
| `getPrimaryCopy()` / `focusCopy{}` | Hardcoded per-focus answer + copy ("Start with the signal, then ask for evidence only when needed.", "The month view stays forecast-led and basis-labelled.", "Risk is treated as a prompt for action…") | KFF (scaffolding) / RWD (data-bound parts) | Pure scaffolding stays as a constant frame; any phrase implying a data state moves to a resolved insight |
| `pickCardsForFocus()` keyword-scoring `rules{}` | Frontend selects which cards render per focus by keyword match | RWD → backend | Placement Binder decides card-to-surface on the server; frontend renders the resolved set. (Removes presentational selection logic that drifts toward frontend business logic.) |

### 1E — Legacy "time bomb" derived strings (the originating problem)

From `Sobha_Platform_SystemMap_v1.docx` §4.2/§4.3 — these are the hardcoded derived figures that go stale the moment sources move:

| Site | Emits | Class | Replaced by |
|---|---|---|---|
| "15× growth" / "97% CAGR" / "LP 22× growth" headline strings | Static derived multiples/CAGR baked into narrative text | REMOVE | Compiled metrics `da_growth_multiple (M011)`, `da_cagr (M010)`, `lp_growth_multiple (M058)` rendered through a frame |
| `OD total (1.65B)` hardcoded in S02/S04/S08 | Static OD figure ("will be stale immediately post-18-Mar") | REMOVE (already flagged removed in `global_component_rules.od_today`) | `OD_TODAY` single global constant from R18 only |
| Forward pipeline "43.5B / 37.8B / ~40B" three different numbers | Inconsistent static denominators | REMOVE / RWD | `PIPELINE_GROSS` (R36) + `PIPELINE_ADV_DENOM` named constants, one definition each |

### Removal Manifest (what the migration deletes)

The following are **deleted** (not parallel-kept) once their dynamic replacement is shipped and parity-verified:

1. All hardcoded `title` string literals passed into `_card()` across `_board_cards`, `_ops_cards`, `_finance_cards`, `_mis_cards`, `_collector_cards`.
2. All hardcoded interpretation/action string literals passed into `_card()` (same five functions).
3. The five hardcoded card-list functions themselves as *placement* authorities (functions may remain as thin adapters during Wave A, deleted at Wave D).
4. The inline severity ternary `"risk" if ach < 50 else "monitor"` in `_ops_cards()`.
5. `quickball._role_interpretation()` body (all role × source branches and the generic fallback line).
6. The interpretive segment of the `explain_metric()` answer f-string (the trust spine survives as a frame).
7. `submodules[].kpis` M-code placement bindings in `FINAL_section_mapping.json` (migrated into registry `surface_binding`; boundary_rules and cross_section_feeds are **kept**).
8. Frontend `pickCardsForFocus()` selection rules and the data-bound entries of `getPrimaryCopy()`.
9. Legacy derived strings: "15×", "97% CAGR", "22×", hardcoded "1.65B", and the duplicate pipeline denominators.

**Kept as fallback frames (KFF), never deleted:** `_answer_blocked()` template; role `purpose` descriptors; pure UI scaffolding copy in `getPrimaryCopy()`.

---

## SECTION 2 — TARGET ENGINE ARCHITECTURE

The engine sits **after** `data_loader.py` and the Batch 18 `AnalyticsTransformationEngine`, and **before** `command_centres`/`quickball`/the frontend payload. It introduces five named components, each with one responsibility.

```
data_loader.load_all() ──► AnalyticsTransformationEngine.run() ──► EngineRunResult
                                                                    (facts, metrics,
                                                                     links, candidates,
                                                                     charts, validations)
                                                                          │
                                                          ┌───────────────┴───────────────┐
                                                          ▼                                 ▼
                                              InsightDefinitionRegistry            (governed MetricValue map)
                                                          │                                 │
                                                          └──────────► InsightCompiler ◄─────┘
                                                                          │
                                       ┌──────────────────────────────────┼───────────────────────────────┐
                                       ▼                                   ▼                               ▼
                                 LanguageLayer                      PlacementBinder              FreshnessAndCache
                            (deterministic frame |                (registry-driven, enforces      (snapshot_date +
                             constrained editorial)                boundary/containment/feeds)     lineage_hash keyed)
                                       │                                   │                               │
                                       └───────────────► ResolvedInsightSet (per role × surface) ◄────────┘
                                                                          │
                                          command_centres / quickball / frontend render ONLY this
```

### 2.1 Insight Definition Registry

- **Responsibility:** Declarative store of *what an insight is*. Replaces hardcoded card lists, `kpis` bindings, and `_role_interpretation` branches.
- **Each spec contains:** `insight_id`, `metric_keys[]` it reads, `data_state` (trigger + suppress predicates), `language_strategy` (`deterministic_frame` | `editorial_llm`), `frames{}` (frame text keyed by predicate outcome), `surface_binding` (route/focus/submodule/slot), `role_visibility[]`, `priority`, `criticality`, `lineage_requirement`, `governance_state` (`candidate` | `governed`).
- **Inputs:** none at runtime (config). **Outputs:** spec set to the compiler.
- **Position:** config, loaded once; hot-reloadable on source refresh.
- **Failure under missing/stale data:** N/A (it is a definition store); a malformed spec is rejected at load and logged, never silently dropped.

### 2.2 Insight Compiler

- **Responsibility:** At **data-load time** (not per click), evaluate every registry spec against the freshly compiled governed `MetricValue`s + lineage from Batch 18, and emit resolved insights.
- **Inputs:** registry spec set + `EngineRunResult`. **Outputs:** `ResolvedInsightSet` — each insight carries `text`, `value`, `lineage_contract`, `confidence_state`, `surface_placement`, `severity`, `governance_state`.
- **Position:** wraps Batch 18 output; runs inside the data-load / cache-build path that `data_loader` already triggers.
- **No silent fallback:** if a spec's required lineage is missing/failed, the insight is emitted in **blocked/unavailable** state (reusing the `_answer_blocked` frame), never with an invented number. The number slot stays empty; the frame says why.
- **Failure under missing/stale data:** per-insight blocked state; the set still compiles (one bad metric never blanks the page).

### 2.3 Language Layer (two modes)

**(a) Deterministic frame-binding** — fast, always-on, **mandatory** for critical surfaces (Live Pulse, Board cards, Quickball critical answers).
- A frame is a sentence template chosen by data state; numbers are bound from governed values; no model in the loop.
- Example frame set for an OD insight: `rising → "OD exposure has risen to {value}…"`, `falling → "OD exposure eased to {value}…"`, `flat → "OD exposure holds at {value}…"`, `blocked → _answer_blocked frame`.
- **Inputs:** predicate outcome + bound value + lineage. **Outputs:** final string. **Failure:** falls to `blocked` frame.

**(b) Constrained editorial (optional, Narrative chapters only)** — an LLM renders a crisp phrase over a **verified fact set** passed to it. Runs **behind the existing `quickball_provider_gate`** (`should_block_quickball_answer`) and the LLM provider switch.
- **Guardrail contract that makes hallucinated figures structurally impossible:**
  1. The LLM **never** receives raw workbooks, the metric registry, or tools. Its only input is a frozen `verified_fact_set`: an array of `{phrase_slot, value_token, lineage_hash}` where every number is already a string token the model must echo verbatim.
  2. System contract: *"Rephrase only. You may reorder and connect the provided phrases. You may not introduce, infer, compute, compare, or round any number, percentage, multiple, or claim not present as a `value_token`."*
  3. **Output validation (deterministic, post-LLM):** extract every numeric/percentage/multiple token from the LLM output via regex; assert each appears in the input `value_token` set. Any token not in the set → **reject**, emit the deterministic frame instead, log the rejection. This is the structural guarantee, not the prompt.
  4. Editorial output never carries `criticality: critical`; critical surfaces use path (a) only.
- **Position:** between compiler and the Narratives payload; lazy, per-chapter.

### 2.4 Freshness & Speed model (G1)

- Insights are **precomputed at data-load** and cached keyed by `snapshot_date + lineage_hash + role + surface`.
- **Arrival shell renders before insights resolve:** the two-door L0 shell and the `GlassSurface` scaffolding are static and ship instantly; resolved insights hydrate the L1/L2 cards as they arrive.
- **Warm payload** = the cached `ResolvedInsightSet`; the page renders from cache, never by recomputing on the client.
- **Cache invalidation** is driven by `lineage_hash` change (source refresh changes the hash → cache miss → recompute). A stale `snapshot_date` is surfaced as a `confidence_state`, not hidden.
- **Heavy narrative editorial is lazy-loaded** only when a chapter opens (path (b) runs then, behind the provider gate).
- Must not break: no-silent-fallback (blocked insights are cached as blocked), lineage freshness (hash-keyed), snapshot checks (date carried), RBAC visibility (role in the cache key).

### 2.5 Placement Binder

- **Responsibility:** Turn `surface_binding` into role+data-driven placement, replacing hardcoded card lists and `kpis` bindings — while enforcing the **kept** `boundary_rules`, containment, and `cross_section_feeds`.
- Enforces: single-constant reuse (`OD_TODAY` once, `CY_ADV_MIX_YTD` computed once), no duplication across S0X, no third Arrival door, evidence-on-request, Finance-vs-MDO label presence on mixed surfaces.
- **Inputs:** resolved insights + role + boundary/feed rules. **Outputs:** ordered per-(role, surface) insight placement. **Failure:** a spec that targets a forbidden surface (e.g. CIV analysis into S04) is **rejected at bind time**, logged, not placed.

### 2.6 State / Trigger model (G2)

- **Predicate vocabulary:** `threshold_cross(metric, op, value)`, `delta_sign(metric, window)`, `delta_magnitude(metric, window, min)`, `basis_divergence(finance_metric, mdo_metric, tol)`, `snapshot_staleness(metric, max_days)`, `validation_failure(metric)`, `rank_change(metric, dim)`.
- **Suppress vocabulary (prevents noise):** `suppress_if_below(metric, floor)`, `suppress_if_unchanged(metric, eps)`, `suppress_if_stale(metric)`, `suppress_duplicate_of(insight_id)`, `cooldown(insight_id, snapshots)`.
- A phrase is a **pure function of current state**: `frame = frames[ evaluate(data_state, MetricValue) ]`. No stored sentence about a past value ever survives.

---

## SECTION 3 — TRUST & GOVERNANCE PRESERVATION

**3.1 Every dynamic phrase carries the full lineage contract.** Each resolved insight attaches a `lineage_contract` with the complete field set already produced by Batch 18 `FactRecord`/`MetricValue` and `command_centres._metric_ref`: `source_code, source_file, sheet, cell_or_range, snapshot_date, extraction_method, reporting_basis, validation_status, confidence_state, lineage_hash`. Attachment happens in the **compiler** (2.2), copied from the governed `MetricValue.lineage_refs`, before any language is applied. Language can never strip it.

**3.2 Critical insight degrades to blocked, never invents.** The compiler runs the same gate `quickball` already uses (`_lineage_is_usable` + `validation_status ∈ {passed, disclosed, warning}` + `confidence_state ∈ {live_validated, live_warning, disclosed}`). On failure the insight is emitted with `status: blocked_untrusted_metric`, an empty value slot, and the `_answer_blocked` frame. Quickball continues to **block critical answers without lineage** unchanged.

**3.3 Constrained-LLM cannot emit unverified content.** Input contract = frozen `verified_fact_set` (numbers pre-tokenized). Output validation = numeric-token whitelist check (2.3b.3). Rejection path = fall back to deterministic frame + log. The model has no path to a number that wasn't handed to it.

**3.4 Candidate vs governed.** New auto-generated specs (and Batch 18 `MetricSuggestionEngine` candidates) carry `governance_state: candidate` and are visible **only** to MIS/QCG/Admin and Finance review surfaces. Only `governed` specs reach Board/CXO and Quickball critical answers. Promotion candidate→governed is an explicit Finance/MIS/QCG action, logged.

**3.5 Finance-vs-MDO labels.** Any insight whose `metric_keys` mix R04 (Finance) and R02 (MDO) bases carries a mandatory `basis_label` and the Binder refuses to place it on a mixed surface without the label visible — preserving the existing `finance_vs_mdo_label_required` guardrail.

---

## SECTION 4 — SCHEMA & CONTRACTS (machine-readable)

### 4a — Insight Definition Registry schema + worked examples

```json
{
  "$schema": "scip.insight_registry.v1",
  "insight": {
    "insight_id": "string (unique)",
    "metric_keys": ["string (resolves to governed MetricValue.metric_id)"],
    "criticality": "critical | standard",
    "governance_state": "candidate | governed",
    "language_strategy": "deterministic_frame | editorial_llm",
    "data_state": {
      "trigger": [ { "predicate": "threshold_cross|delta_sign|delta_magnitude|basis_divergence|snapshot_staleness|validation_failure|rank_change", "args": {} } ],
      "suppress": [ { "predicate": "suppress_if_below|suppress_if_unchanged|suppress_if_stale|suppress_duplicate_of|cooldown", "args": {} } ]
    },
    "frames": { "<outcome_key>": "frame string with {value} {basis} {entity} slots", "blocked": "frame string" },
    "surface_binding": { "route": "live_pulse|narratives", "focus": "current_signal|month_movement|risk_action|story|portfolio|dues|advance|roadmap", "submodule": "S0X_SMy|null", "slot": "int", "priority": "int" },
    "role_visibility": ["board_cxo","cco_gm_agm","finance","mis_qcg_admin","collector_rm"],
    "lineage_requirement": "required | optional"
  }
}
```

**Example 1 — Critical Live Pulse headline (deterministic):**
```json
{ "insight_id": "lp_od_current_signal", "metric_keys": ["OD_TODAY"], "criticality": "critical",
  "governance_state": "governed", "language_strategy": "deterministic_frame",
  "data_state": { "trigger": [{ "predicate": "delta_sign", "args": { "window": "1_snapshot" } }],
                  "suppress": [{ "predicate": "suppress_if_stale", "args": { "max_days": 3 } }] },
  "frames": { "rising": "Current OD exposure has risen to {value} ({basis}).",
              "falling": "Current OD exposure eased to {value} ({basis}).",
              "flat": "Current OD exposure holds at {value} ({basis}).",
              "blocked": "OD exposure unavailable: trusted lineage gate failed for R18. No fallback published." },
  "surface_binding": { "route": "live_pulse", "focus": "current_signal", "submodule": null, "slot": 0, "priority": 100 },
  "role_visibility": ["board_cxo","cco_gm_agm","finance","mis_qcg_admin","collector_rm"], "lineage_requirement": "required" }
```

**Example 2 — Narratives editorial phrase (constrained-LLM):**
```json
{ "insight_id": "nar_advance_story", "metric_keys": ["CY_ADV_MIX_YTD","FY_ADV_MIX_YTD","ADVANCE_2026_TOTAL"],
  "criticality": "standard", "governance_state": "governed", "language_strategy": "editorial_llm",
  "data_state": { "trigger": [{ "predicate": "delta_magnitude", "args": { "metric": "CY_ADV_MIX_YTD", "window": "ytd", "min": 1.0 } }],
                  "suppress": [{ "predicate": "suppress_if_unchanged", "args": { "eps": 0.5 } }] },
  "frames": { "blocked": "Advance narrative withheld: advance mix lineage not validated." },
  "surface_binding": { "route": "narratives", "focus": "advance", "submodule": "S05_SM2", "slot": 1, "priority": 60 },
  "role_visibility": ["board_cxo","cco_gm_agm","finance"], "lineage_requirement": "required" }
```

**Example 3 — Risk & Action flag (deterministic, threshold):**
```json
{ "insight_id": "lp_pacing_risk", "metric_keys": ["MTD_TOTAL_COLLECTIONS","MAY_TOTAL_COLLECTIONS_TARGET"],
  "criticality": "critical", "governance_state": "governed", "language_strategy": "deterministic_frame",
  "data_state": { "trigger": [{ "predicate": "threshold_cross", "args": { "expr": "mtd/target*100", "op": "lt", "value": 50 } }],
                  "suppress": [] },
  "frames": { "breach": "Pacing risk: MTD at {value}% of May MDO target (Finance actual vs MDO target).",
              "ok": "Pacing on track at {value}% of May MDO target.",
              "blocked": "Pacing signal unavailable: target or actual lineage missing." },
  "surface_binding": { "route": "live_pulse", "focus": "risk_action", "submodule": null, "slot": 0, "priority": 90 },
  "role_visibility": ["board_cxo","cco_gm_agm"], "lineage_requirement": "required" }
```

### 4b — Resolved Insight payload schema (compiler → frontend)

Aligned to `MetricValue` + the `uiState` contract (route/focus/depth/drawer/evidencePanel).
```json
{ "insight_id": "lp_od_current_signal", "status": "resolved | blocked_untrusted_metric",
  "text": "Current OD exposure has risen to AED 1.650B (R18 overdue).",
  "value": 1650000000, "display_value": "AED 1.650B", "unit": "AED",
  "severity": "risk | monitor | strategic | ok", "criticality": "critical", "governance_state": "governed",
  "basis_label": "R18 overdue", "language_strategy": "deterministic_frame",
  "lineage_contract": { "source_code": "R18", "source_file": "...", "sheet": "...", "cell_or_range": "...",
                        "snapshot_date": "2026-03-18", "extraction_method": "...", "reporting_basis": "R18 overdue",
                        "validation_status": "passed", "confidence_state": "live_validated", "lineage_hash": "..." },
  "surface_placement": { "route": "live_pulse", "focus": "current_signal", "submodule": null, "slot": 0 },
  "evidence_ref": { "evidencePanel": "entity_split | full_trend | formula | null", "drawer": "why | risk | action | null" } }
```

### 4c — Constrained-LLM contract

```json
{ "input": { "system": "Rephrase only. Numbers are pre-tokenized; echo verbatim. Introduce no number, %, multiple, comparison, or claim absent from value_tokens.",
             "verified_fact_set": [ { "phrase_slot": "advance_mix_cy", "value_token": "61.4%", "lineage_hash": "..." } ],
             "max_tokens": 1000 },
  "output_valid": { "phrase": "string", "tokens_used": ["61.4%"] },
  "output_rejected": { "rejected": true, "reason": "unverified_token:73%", "fallback": "deterministic_frame" } }
```
Post-LLM validator: `set(numeric_tokens(phrase)) ⊆ set(value_tokens)` else reject.

### 4d — Cache key + invalidation contract

```json
{ "cache_key": "insight::{snapshot_date}::{lineage_hash}::{role}::{surface}",
  "value": "ResolvedInsightSet",
  "invalidate_on": ["lineage_hash_change", "registry_version_change"],
  "stale_signal": "if snapshot_date older than max_days → confidence_state downgraded, NOT hidden",
  "rbac": "role is part of the key; a role never reads another role's cached set" }
```

---

## SECTION 5 — MIGRATION SEQUENCE (surgical, reversible)

| Wave | Action | Files touched | Deleted | Smoke / parity test | Rollback |
|---|---|---|---|---|---|
| **A — Shadow** | Stand up registry + compiler; emit `ResolvedInsightSet` **alongside** existing static cards, not rendered | new `insight_registry.json`, `insight_compiler.py`; read-only hook in `command_centres.build_command_centres` | nothing | Diff dynamic vs static card text/value/lineage for every role; assert value+lineage parity | Remove the read-only hook (one import) |
| **B — Live Pulse critical** | Cut Current Signal / Month Movement / Risk & Action to the **deterministic frame path** | `command_centres` board/ops card emit; frontend `FocusScreen` reads resolved insights | hardcoded titles/notes for those cards; severity ternary | Live Pulse renders identical numbers + lineage; blocked-state shows frame, no number | Re-point those surfaces to the retained static functions |
| **C — Narratives editorial** | Cut Narratives chapters to **constrained-LLM** behind the provider gate; retire `quickball._role_interpretation` | `quickball.py`, `llm_providers`, `quickball_provider_gate` | `_role_interpretation` body; interpretive segment of `explain_metric` | Token-whitelist validator rejects any injected number; gate blocks no-lineage critical asks | `SCIP_LLM_PROVIDER` env flip; re-enable `_role_interpretation` |
| **D — Placement** | Replace hardcoded placement with the **Placement Binder**; migrate `kpis` bindings into registry | `command_centres` (delete card-list functions as authorities), `FINAL_section_mapping.json` (`kpis`→registry) | `_board/_ops/_finance/_mis/_collector_cards` as placement authorities; `submodules[].kpis` | Binder reproduces prior placement; boundary_rules + cross_section_feeds still enforced (CIV stays S01, OD_TODAY single source) | Restore card-list functions; registry binder off |
| **E — Speed** | Enable precompute + cache keyed by snapshot+hash+role+surface; verify cold start | `data_loader` cache build, compiler cache layer | nothing | Cold-start Arrival first paint + Live Pulse TTI within targets (Section 6); cache hit ratio measured | Disable cache flag; compile per request |

Each wave is independently shippable; A and E are non-destructive; B/C/D each delete only artifacts already parity-verified in the prior wave.

---

## SECTION 6 — SPEED VALIDATION PLAN (G1)

| Metric | Target | How to test |
|---|---|---|
| Arrival (L0) first paint | < 1.0s, **independent of backend** (static shell) | Lighthouse/FCP on `scip-1jy.pages.dev` with backend cold |
| Live Pulse L1 time-to-interactive, **warm** backend | < 1.5s | Synthetic timer from route enter → resolved cards rendered |
| Live Pulse TTI, **cold** backend (Render cold + Drive download + parse) | shell interactive < 1.0s; numbers hydrate < cold-start-bound, with explicit "warming" state (never a fake number) | Cold-start run; assert shell renders before payload |
| Insight-set compile time at data-load | < 500ms over the governed metric set (compile is O(specs), not O(workbooks)) | Timer around `InsightCompiler.run`; assert it does not re-parse Excel |
| Cache hit ratio (steady state, unchanged sources) | > 95% | Counter on cache_key hits/misses across a session |
| Narrative editorial lazy-load | runs only on chapter open; not on Arrival or Live Pulse | Assert no LLM call until `route=narratives & focus=<chapter>` |

"Fast loading" = **shell never waits on data**, **data renders from warm cache**, **cold start shows an honest warming state**, and **no number ever appears before its lineage**. Speed is achieved by precompute+cache only — never by moving computation to the frontend, never by silent fallback.

---

## SECTION 7 — RISKS, ASSUMPTIONS, NON-GOALS

**Risks & guards**
- *Stale phrase despite live data:* a frame fires on an old `snapshot_date`. Guard: `suppress_if_stale` + snapshot carried into `confidence_state`; stale → downgraded, not shown as fresh.
- *Snapshot misalignment across files feeding one editorial phrase* (e.g. R04 actual + R02 target on different dates): Guard: reuse Batch 18 `B18_CROSS_REPORT_DATE_ALIGNMENT` diagnostic; mixed-date editorial carries a date caveat and cannot claim a clean comparison.
- *LLM drift:* covered structurally by the token-whitelist validator (4c); a drift produces a rejection + deterministic fallback, never a published wrong number.
- *Registry rot:* specs that reference a retired metric_key → compiler emits blocked + logs; binder rejects forbidden surfaces. A bad spec degrades one insight, never the page.

**Assumptions about Batch 18 output**
- `EngineRunResult.metrics` carries complete `lineage_refs`, `validation_status`, `confidence_state` per `MetricValue` (confirmed in `analytics_engine._metric`).
- Only the R-series currently resolving feed governed metrics; the **13/28 partial-load** state means specs whose `metric_keys` depend on the missing 15 files will correctly emit **blocked**, not invented values — which is the desired UAT behavior, not a regression.

**Non-goals (explicit):** no new Arrival door; no dashboard-first home; no Entity Head; no frontend business computation; no LLM-authored numbers; no unlineaged Quickball answers; no caching that ignores snapshot/lineage/RBAC/fallback state.

---

## SECTION 8 — HARD CONSTRAINTS (must hold in the final design)

1. **Numbers originate only from governed `MetricValue` + lineage; language never originates a number.** The compiler binds values before language runs; the LLM only echoes pre-tokenized values.
2. **Critical surfaces use the deterministic path.** The editorial LLM path is optional, bounded to Narratives, gated by `quickball_provider_gate`, and structurally incapable of introducing unverified content.
3. **Placement is registry-driven and enforces existing boundary/containment/cross-feed rules.** No duplication, single-constant reuse, no third door, evidence on request.
4. **The page renders fast by precompute + cache** keyed by snapshot+lineage+role+surface — never by frontend computation, never by silent fallback.
5. **Every removed static artifact in Section 1 is accounted for** by a dynamic replacement or an explicit kept-fallback frame (see Removal Manifest).

**End-state contract:** one coherent engine where every headline and editorial phrase is generated live from current data, placed automatically by role and surface, carries full lineage, degrades to blocked/unavailable instead of inventing figures, and renders fast from a warm precomputed cache — with a reversible wave-by-wave migration off the static system and zero violation of the locked SCIP rules.

---

### The two boundaries to pressure-test before accepting the rest
1. **Section 1 removal manifest** — confirm each of the nine deletions has a live replacement *before* deleting, and that the KFF set (blocked frame, role purpose, UI scaffolding) is genuinely number-free.
2. **Section 2.3 deterministic-vs-LLM split** — the token-whitelist validator in 2.3(b)/4c is the single point where this design either stays trustworthy or drifts into hallucinated numbers. It must be deterministic, post-LLM, and fail closed to the deterministic frame.
