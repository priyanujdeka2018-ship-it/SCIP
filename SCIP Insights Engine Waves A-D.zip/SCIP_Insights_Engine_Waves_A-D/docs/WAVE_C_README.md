# SCIP Insights Engine — Wave C (constrained-LLM Narratives editorial)

**Scope:** Narratives editorial chapters only (Story, Portfolio, Dues, Advance, Roadmap).
**Status:** built; all Wave C checks pass; Waves A and B still green.
**Risk posture:** this is the path that could hallucinate a number, so the guarantee is structural, not prompt-based — the token-whitelist validator discards any model output containing a figure not in the verified fact set.

## How it works
```
chapter open (lazy)  -> narrative_fact_builder.build_chapter_fact_set(chapter, role, compiled)
                          (facts come ONLY from gate-passing governed insights;
                           withheld if none resolved -> LLM never called)
                     -> constrained_editorial.render_chapter_editorial(fact_set, role)
                          -> provider gate (should_block_quickball_answer)
                          -> get_llm_provider().complete(build_llm_request(...))  [behind SCIP_LLM_PROVIDER]
                          -> editorial_token_validator.validate_editorial(text, value_tokens)
                               pass -> publish editorial + provider metadata + lineage
                               fail -> discard model text, publish deterministic phrase, log offending token
```
Every number reaches the model only as a pre-tokenized `value_token` it must echo. The model has no tool, no workbook, and no metric registry. A number it did not receive cannot pass the post-call whitelist, so it cannot be shown.

## Retirement manifest (Wave C)
Retired as the live source for Narratives interpretive language (kept in code as the rollback fallback; full deletion is Wave D):
1. `quickball._role_interpretation()` — the hardcoded role × R-code editorial branches. Narratives role notes now come from the constrained editorial path; Quickball critical *answers* remain on the deterministic trust spine (unchanged).
2. The interpretive segment of `quickball.explain_metric()` — the editorial sentence is retired; the trust spine (value, basis, source/sheet/cell, validation, confidence, definition) is **kept verbatim** as the deterministic frame.
3. Frontend `getPrimaryCopy` data-bound Narratives copy — replaced by the rendered editorial; pure scaffolding copy stays as a frame.

**Not touched:** Live Pulse (Wave B), Quickball critical-answer blocking and lineage gate, RBAC scope, `/quickball` response contract.

## Quickball integration (Backend/quickball.py)
Following the LLM Provider Switch Pack apply order, after the provider abstraction and gate are in place:
1. Keep the existing critical-answer flow (deterministic trust spine + `should_block_quickball_answer`) exactly as is.
2. For Narratives chapter rendering, call `render_chapter_editorial(fact_set, role)` instead of `_role_interpretation(...)`. Leave `_role_interpretation` defined as the rollback fallback.
3. Persist editorial provider metadata (`provider`, `model`, `prompt_policy_version`, `response_hash`, `latency_ms`, `correlation_id`) to `quickball_interactions` alongside the existing fields — reuse migration `008_quickball_provider_audit.sql`.
4. Lazy-load: render editorial only when a Narratives chapter is opened, never on Arrival or Live Pulse (keeps cold-start paint fast — plan G1).

## Frontend
Narratives chapter opens → fetch/read the chapter's editorial result and render `editorial` on a **glass** surface (context), with verified numbers still shown on **solid** surfaces. `status` drives display: `ok` → editorial; `withheld`/`blocked`/`unavailable`/`rejected_unverified_token` → the deterministic phrase (still correct and lineaged, just less crisp). No client computation.

## Smoke results (local)
`python smoke_editorial_wave_c.py` → all pass:
- compliant model → editorial published, numbers verified, lineage + provider metadata attached;
- **rogue model injecting "22x" → rejected, model text discarded, verified deterministic phrase shown, offending token logged** (the headline guarantee);
- withheld chapter → provider never called;
- provider error → safe fallback, status `unavailable`, no stack trace;
- validator: AED/%/×/year tokens extracted; source codes (R18, S05_SM2, M032) never mistaken for numbers; rounding 70.0%→70% rejected;
- editorial is always `standard` criticality (can never be used for a critical surface).

## Files
- `editorial_token_validator.py` — the structural guarantee (post-LLM whitelist).
- `narrative_fact_builder.py` — builds the frozen verified fact set; withholds unlineaged chapters.
- `constrained_editorial.py` — gate → LLM → validate → deterministic fallback.
- `_wave_c_shim.py` — local-only fallback for the real `quickball_provider_gate`/`llm_providers`; real modules take precedence on deploy.
- `smoke_editorial_wave_c.py` — the behavior gate.

## Rollback
- Provider-level: set `SCIP_LLM_PROVIDER=mock` (or the prior provider) — environment-only, instant, per the provider switch pack.
- Feature-level: re-point Narratives rendering to `_role_interpretation` (retained). No data migration; the audit columns are additive.

## Note on the originating problem
The "grew 22×" time bomb that started this work is now structurally impossible: any such phrase is either (a) built from a verified `da_growth_multiple` token and therefore lineage-bound, or (b) absent from the fact set and therefore stripped by the validator before it can reach a user.
